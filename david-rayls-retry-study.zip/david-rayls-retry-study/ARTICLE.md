# Should You Retry or Resubmit a Cross-Chain Message? A Local Rayls Study

Retrying a failed message and submitting the request again can produce different outcomes. A retry keeps the existing message identity. Another source submission can create a new identity for the same business instruction.

I tested that distinction using pinned Rayls contracts. Two submissions of the same 7-unit request produced a total of **14** in a deliberately unguarded application. An application with its own request-ID check stayed at **7**, even though both message IDs were marked executed at the local destination.

**Scope:** these are local contract experiments with synthetic counter units. The added application tests use two separate Ganache EVMs, with authorized manual message delivery. They do not run the institutional network, live relayer, Hub or encrypted transport, and they do not describe a customer payment incident.

## Why a failed message is not the same as a new request

Rayls' [cross-chain transaction guide](https://docs.rayls.com/docs/how-a-cross-chain-transaction-works) says that a destination execution revert in the standard teleport flow needs manual retry. That is the documented workflow; this study tests a narrower implementation question beneath it.

What remains executable after failure? What prevents another successful execution after recovery? And if an application submits its request again at the source, is the resulting message still the same one?

Those questions concern different records. The message ID identifies a protocol instruction. A business request ID identifies the operation an application wants performed. A receipt records the outcome of one transaction. Application state shows what actually changed.

## The source and the experiment

The contracts are pinned to `raylsnetwork/rayls-sovereign-contracts` commit **`ed8863885c8ed5d5d317d47a34c063907192687a`**. Its package metadata reports `2.6.3-nightly.2`. This identifies a public source snapshot, not the version running in an institutional production deployment.

The harness deploys the actual Endpoint, MessageSender, MessageReceiver, ResourceManager, MessageExecutor and AccessManager implementations, with their linked libraries and proxies where required. The original suite also exercises BatchMessageSender. The contracts and study fixtures are compiled with solc-js 0.8.24, optimizer runs 50 and the Paris EVM target.

The original suite uses one physical local EVM and logical endpoint chain IDs. Its four preserved complete runs each contain 33 focused cases, three 60-operation sequences, storage/opcode checks and a separate-process database restart.

I added a separate application experiment on **two unforked EVMs, chain IDs 10101 and 20202**, running in one Node process. The receiving applications have code only on the destination EVM. These controls were executed twice from fresh providers, with matching case records. Each run contains 16 cases, 14 source messages, 19 destination delivery attempts and 90 local transactions, including setup and seven intentional reverts.

The added fixtures are authored test applications. Source participant/token validation is permissive, and a locally authorized account delivers the source-emitted messages. These choices isolate execution semantics; they do not test transport authenticity or live membership controls. The units below are not tokens, deposits or money.

## Two successful message IDs, one repeated business request

The first comparison deliberately holds the request ID and amount constant within each application.

The unguarded application accepts a request to add 7. A second source transaction submits the same request ID and amount to the same application. The source nonce advances, the emitted message ID changes, and the second delivery also succeeds. The application total becomes **14**, with two recorded effects.

That is expected for this fixture: it has no business-request deduplication. It is not evidence that a Rayls financial application would process a duplicate payment.

The guarded application adds a different rule. It checks the expected executor and source context, then records a business request ID and its amount. If a later message carries that same request and amount, it returns successfully without applying the amount again. Reusing the request ID with a different amount is rejected.

Its first 7-unit request succeeds. A second source submission creates another source-emitted protocol ID, but the application emits `DuplicateIgnored` and stays at **7**.

| After two source submissions of the same request | Unguarded fixture | Request-ID fixture |
|---|---:|---:|
| Successfully consumed message IDs | 2 | 2 |
| Applied business effects | 2 | 1 |
| Counter total | 14 | 7 |

The distinction survives a useful control: a genuinely different 8-unit request is accepted by the guarded fixture, raising its total from 7 to **15**. The guard is distinguishing requests, rather than suppressing every subsequent call.

The conflicting-amount control also matters. A request ID cannot safely mean both “add 7” and “add 8” without an application-defined policy. Here, the latter reverts and its protocol ID remains unconsumed. This is a small illustrative design, not a complete banking idempotency scheme.

The practical implication is that two successful message IDs need not mean two business operations. Conversely, two different valid IDs can carry the same intended operation. An interface should retain both identities.

## A failed attempt can leave the same message retryable

For the recovery control, I enabled a deliberate failure in another guarded application and delivered a source-generated 5-unit request.

The destination transaction reverted. Its counter stayed at **0**, its business request marker remained false and `executed[messageId]` remained false.

After clearing the failure condition, I delivered the **same message ID and payload**. The counter became **5**, and both markers committed. A further replay was rejected with `MessageIdAlreadyExecuted`, leaving the counter at 5.

The source explains why. The executor writes its execution marker before calling the application. If the application fails, `MessageLib` propagates a revert, and EVM rollback removes the tentative marker along with other state changes. In the added fixture, that rollback also removes the business marker written before the deliberate failure.

The original suite separately preserves an opcode/storage comparison showing a tentative execution-slot write during a reverted call and an unchanged post-transaction slot. This distinguishes an attempted write from committed state.

Retryability is therefore a state condition, not a delivery promise. A message can remain unconsumed while the condition that prevents its execution persists. These manual controls do not establish automatic recovery by a running relayer.

## Message identity does not determine delivery order

Addition alone hides an ordering problem: adding 1 and then 2 gives the same sum as adding 2 and then 1. I therefore used a second application that appends decimal digits.

Delivering “append 1” and then “append 2” produces **12**. Reversing their delivery produces **21**. Both source-emitted messages execute in either order in the unsequenced fixtures.

In the pinned source, both MessageSender and BatchMessageSender construct messages with `ignoresNonce = true`. The receiver's nonce-enforcement branch is conditional on that flag being false. In the added controls, the receiver's inbound nonce for source 10101 remains **0**.

The harness deliberately chose delivery order. This does not establish that a live Rayls relayer normally reorders messages, or that every production route uses the same policy.

A sequence-enforcing fixture provides the causal control. Delivering step 2 before step 1 reverts and leaves step 2's ID unconsumed. After step 1 succeeds, retrying the **same step-2 ID** produces 12 and advances the application's next expected sequence to 3.

The original suite also tests the receiver's strict-nonce branch with manually constructed `ignoresNonce = false` inputs. Those are separate controls, not the pinned senders' unchanged default output. Protocol nonce enforcement and application sequencing need to be evaluated in their actual configurations.

## What the records establish

The evidence retains source events, complete transaction inputs, raw receipts, exact RPC requests/replies, and state readings at recorded local blocks. A separate checker reconstructs source message IDs and compares reported outcomes with those raw records.

For each added run, it binds all 90 transactions to their RPC records, reconstructs 14 source IDs, checks 19 delivery inputs, and reconciles 12 committed IDs with application events and state. It also verifies that the new transactions explicitly use valid EIP-1559 fee-cap ordering. Copied-record mutations are rejected by the checker.

The four original runs and two added runs repeat deterministic experiments. Their transaction counts and individual assertions are evidence coverage, not independent real-world observations, live user counts or performance measurements.

A separate supplement executes components from pinned official relayer code. Its preserved records include source-EVM re-execution, destination-calldata comparisons and transaction-proof checks. A legacy transaction proof verifies; a valid-fee type-2 Ganache control encounters a transaction-root mismatch. The included checker reconstructs the encoding difference.

That component result remains separate from the application tests. No Axyl node, successful Hub proof submission, CTS transport or initialized relayer daemon was demonstrated. The full local CLI startup stopped at its Docker check in the review environment. No production deployment mapping was established. Those gaps are retained in the package rather than presented as completed integration tests.

## What an application should record before retrying

The useful record connects the business request ID to the source transaction, emitted message ID, destination outcome and resulting application state.

After failure, first determine whether that existing ID remains executable. Before submitting again at the source, determine whether the business operation has already been accepted and how another message would be handled. When operations depend on order, inspect the receiver configuration and the application's sequencing rule.

[ERC-5164](https://eips.ethereum.org/EIPS/eip-5164) provides a useful reference: it requires protection against multiple successful executions, permits retry following failure and makes no ordering guarantee. The local Rayls results make those distinctions concrete without establishing whole-system compliance or production behavior.

The question is therefore precise: **am I retrying this message, or creating another message for the same business request—and what state will prove the intended outcome?**

## Evidence and reproduction

The [evidence repository](https://github.com/davidvnvn276/david-rayls-retry-study) is the publication location for the study. For this revision, use release **`david-retry-reviewed-20261021`**, identified by `RELEASE.json` inside the reviewed ZIP. Its English README separates saved-record verification, new local execution and optional official-component checks. No real assets or mainnet transaction are required.

## Primary sources

- [ERC-5164: Cross-Chain Execution](https://eips.ethereum.org/EIPS/eip-5164)
- [Rayls: how a cross-chain transaction works](https://docs.rayls.com/docs/how-a-cross-chain-transaction-works)
- [Pinned Rayls contracts](https://github.com/raylsnetwork/rayls-sovereign-contracts/tree/ed8863885c8ed5d5d317d47a34c063907192687a)
- [MessageSender](https://github.com/raylsnetwork/rayls-sovereign-contracts/blob/ed8863885c8ed5d5d317d47a34c063907192687a/src/rayls-protocol/modules/MessageSender.sol) and [BatchMessageSender](https://github.com/raylsnetwork/rayls-sovereign-contracts/blob/ed8863885c8ed5d5d317d47a34c063907192687a/src/rayls-protocol/modules/BatchMessageSender.sol)
- [MessageReceiver](https://github.com/raylsnetwork/rayls-sovereign-contracts/blob/ed8863885c8ed5d5d317d47a34c063907192687a/src/rayls-protocol/modules/MessageReceiver.sol)
- [MessageExecutor](https://github.com/raylsnetwork/rayls-sovereign-contracts/blob/ed8863885c8ed5d5d317d47a34c063907192687a/src/rayls-protocol/RaylsMessageExecutor/RaylsMessageExecutorV1.sol) and [MessageLib](https://github.com/raylsnetwork/rayls-sovereign-contracts/blob/ed8863885c8ed5d5d317d47a34c063907192687a/src/rayls-protocol-sdk/libraries/MessageLib.sol)
- [Pinned official relayer](https://github.com/raylsnetwork/rayls-sovereign-relayer/tree/b01b427de4cfc2ac66e75eba0d5070b73a3b137c)

@RaylsLabs
