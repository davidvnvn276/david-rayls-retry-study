# Can a Cross-Chain Message Be Retried Safely? Testing Rayls’ Message ID Boundary

**Study scope:** pinned public source, one local EVM, synthetic application effects and manually delivered messages.

The same message ID remained retryable after a reverted execution in this local study of Rayls’ public contract code. After success, replaying that ID was rejected. Resubmitting the same application payload at the source created a different ID and another counter effect.

Rayls’ [cross-chain transaction guide](https://docs.rayls.com/docs/how-a-cross-chain-transaction-works) describes a standard teleport destination revert as requiring manual retry. I tested a narrower contract question beneath that workflow: what remains retryable after an application failure, and what changes if the source submits again? The broader teleport workflow was not run.

That still leaves two separate questions: must messages execute in their original order, and what happens if an application submits the same instruction as a new source transaction?

The source-generated payloads also executed when delivered out of nonce order in the harness. Their metadata selected a different receiver path from the manually constructed strict-order controls.

The tested boundary is **one committed execution per message ID at the same executor**, rather than a blanket promise of exactly-once business processing. Here, retry means delivering an existing message again; a new source transaction is a separate submission.

## What this study actually ran

The experiment pins `raylsnetwork/rayls-sovereign-contracts` to commit **`ed8863885c8ed5d5d317d47a34c063907192687a`**. Its package metadata reports `2.6.3-nightly.2`. This is a public source snapshot, not a verified mapping to any live deployment.

I deployed the actual `EndpointV1`, `MessageSender`, `BatchMessageSender`, `MessageReceiver`, `ResourceManager`, `RaylsMessageExecutorV1` and `RaylsAccessManagerV1` implementations, including their required libraries. Proxy-based components used ERC-1967 proxies. Solidity 0.8.24 compiled the selected contracts and their dependencies with the optimizer enabled for 50 runs and the Paris EVM target. The compilation resolved 66 source files, including the study fixtures and OpenZeppelin dependencies; 383 vendored files were checked separately against their pinned Git blob identities.

Everything executed on **one local Ganache chain, ID 31337**. The source and destination endpoint settings used logical IDs 10101 and 20202 inside that same VM. Source events were passed manually to an authorized local destination caller. This was not a two-chain network, live relayer or Private Network Hub test.

The application was a synthetic counter. Calling it with 7 units increased its recorded total by 7. These units were not tokens, deposits or money. A permissive test fixture replaced participant and token validation; membership, token eligibility, cryptographic proofs and encrypted transport were outside the experiment. Resource resolution used direct addresses or an existing mapping, without automatic factory deployment.

The package preserves three original complete runs and a fourth execution performed during review after a clean dependency installation. Each started from a fresh local database and ran **33 focused cases**, three fresh contract fixtures with **60 seeded operations each**, and a restart in a separate Node process. Each recorded **579 local transactions**, including deployment, configuration, deliberately rejected calls and recovery actions. These repeat the same deterministic experiment; they are not 579 independent protocol findings or a throughput benchmark.

## A failed attempt remained retryable; a success did not

The first source-generated instruction added 7 units to application A. Its destination transaction succeeded, A’s total became 7 and `executed[messageId]` became `true`.

Delivering that exact message again reverted with `MessageIdAlreadyExecuted`. A’s total stayed at 7.

A later instruction was designed to add 17 units to application B. Before delivery, I enabled a controlled failure in B. The destination call reverted with `MessageFailure`, containing the application’s `ControlledTargetFailure`. B’s total stayed at its earlier value of 13, and the message’s execution flag remained `false`.

After removing the controlled failure, delivery of the **same payload and message ID** succeeded. B’s total rose from 13 to 30, exactly 17 units. A further replay was rejected and left the total at 30.

The execution flag’s placement explains this behavior. `RaylsMessageExecutorV1` writes the flag before making the application call. `MessageLib` propagates an application failure by reverting. EVM rollback therefore removes the tentative flag write along with the failed call’s state changes. When execution succeeds, the flag remains committed.

Opcode traces confirmed that distinction: the failed 17-unit attempt contained an `SSTORE` writing 1 to the computed execution-flag slot, while the slot’s value at that transaction’s block was still zero. The successful control committed 1. This checked the tentative write and the final state separately.

The failed attempt was retryable because the whole destination execution reverted. That does not mean the system guarantees an eventual successful delivery: a destination that remains unavailable or invalid can keep failing.

## A new source submission is a new message

Next I submitted the same 7-unit application payload to the same destination again through the source Endpoint.

The application call data was identical, but the source sender’s nonce advanced from 1 to 2. The emitted message IDs differed. Delivering the second message succeeded and raised A’s total from 7 to 14.

In the evidence graphic, M1 labels the first full message ID and M2 the second. Replaying M1 left A at 7; executing M2 raised it to 14.

This was expected for the synthetic application, which deliberately had no business-request deduplication of its own. It demonstrates the boundary of the protocol-level identity check. It does not establish that a financial application using Rayls would accept a duplicate payment.

In this implementation, the sender computes an ID using its own contract address, the source chain and sender, the destination chain and address, and the encoded message. The encoded message includes its nonce. I independently reconstructed the emitted IDs from those fields.

There is another useful detail: `MessageSender` and `BatchMessageSender` maintain separate counters. In the test, their first messages had identical message data and nonce 1, but different IDs because the sending-module addresses differed. A bare nonce was therefore insufficient to identify a message across both modules.

An integrator deciding whether to retry should retain the emitted message ID. If the real question is whether a customer instruction has already been accepted, the application needs its own durable request identity and reconciliation rules as well.

## The nonce existed, but ordering was conditional

The pinned source has an important distinction between generating a nonce and enforcing its order at the destination.

Both `MessageSender.prepareMessage` and `BatchMessageSender.prepareBatch` set **`ignoresNonce = true`** in the messages they construct. `MessageReceiver` checks and advances its per-source inbound counter only when that flag is false.

I tested the payloads emitted by the source contracts without changing that flag. The instruction carrying nonce 4 was delivered before nonce 3. Both executed successfully. The receiver’s inbound counter for that source remained 0, while the executor recorded both message IDs as consumed.

I also left the 17-unit message in its controlled failed state and delivered a later source-generated instruction to another application. The later instruction succeeded while the earlier ID was still unconsumed. Under these tested inputs, the failed message did not impose a strict nonce queue on the later one.

This is a result for the source-emitted payloads delivered unchanged in this local harness. I did not run the transport and cannot infer every live route’s metadata policy from it.

To isolate the receiver’s other branch, I separately assembled control messages with `ignoresNonce = false`. Nonce 1 succeeded. A controlled failure at nonce 2 rolled the inbound counter back to 1. Nonce 3 was then rejected with `MessageReceiver__WrongNonce`, reporting expected 2 and received 3. Recovering nonce 2 allowed nonce 3 to proceed. A different source ID had its own counter.

Those strict-mode controls must not be presented as the pinned senders’ default output. They demonstrate that **duplicate prevention and ordered delivery are different mechanisms**, selected by different state and input conditions.

## Recovery and persistence received separate checks

The focused suite tested temporary loss of the receiver’s executor permission and a pause on the executor. Both rejected delivery without consuming a fresh ID. Restoring the role or clearing the pause allowed the same message to execute.

Additional local controls rejected an unauthorized Endpoint caller, direct access to the receiver outside its authorized Endpoint, and delivery to an address without contract code. An unresolved resource mapping also left its ID unconsumed; registering the mapping made the same controlled input executable.

I tested the executor’s batch method separately. When its middle application call failed, earlier effects in that transaction rolled back, no execution event survived and the batch ID remained unconsumed. After recovery, the batch succeeded. A successful ID could not be reused by switching between the executor’s single and batch methods.

**This executor batch is distinct from `Endpoint.sendBatch`.** The latter emits a collection of separately identified messages. The direct executor test does not establish atomic settlement across chains or across independently delivered messages.

A deliberately authorized callback reached the receive reentrancy guard and was rejected without consuming its nested ID. A storage-compatible, study-only UUPS upgrade retained a previously consumed ID and continued rejecting its replay. The test implementation only changed the reported version and added no storage; it was not an official release or evidence that arbitrary upgrades preserve safety.

Finally, the experiment process exited and a new Node process reopened the same local database. The last block hash, contract code hashes, recorded state, implementation slot and sampled consumed-ID storage slots matched. The old message was still rejected, and a fresh message succeeded. This tested local chain-state persistence, not a relayer restart or distributed failover.

## How the evidence was reconciled

The three seeded sequences mixed new submissions, pending deliveries, successful-message replays, controlled application failures, unauthorized calls, temporary role revocation and pauses. Each used a fresh contract fixture. After every operation, the harness compared target totals, call counts, execution flags and nonce readings with its expected state. Remaining valid pending messages were delivered at the end.

A separate verifier then decoded raw receipts rather than relying on the harness’s event-name summaries. Per complete run it reconciled **114 application-effect events**, **107 source-emitted messages** and **113 committed executor IDs**, including controlled cases. These counts describe different things: one executor batch can contain several application effects, and some controls do not originate from a source dispatch.

The verifier reconstructed every source-emitted message ID, checked revert bytes preserved through parent-state simulations, reconciled event totals with getters, and derived consumed-ID storage locations from the compiler’s layout. It found no second committed execution of the same ID at the same fixture executor. All four complete runs produced matching focused states, seeded results and derived reports.

An additional review bound saved transactions to their raw RPC submissions, receipts and mined inputs, including the exact caller and parent-state call used to recover revert bytes. It also matched focused before/after snapshots and seeded post-operation states to getter replies at the corresponding local blocks. These checks strengthen the connection between a reported result and its raw records; they are not additional execution experiments.

A fresh execution of the same compiler reproduced the preserved artifacts. Deployment input bytes, linked library addresses and fixed runtime bytes also matched 67 local deployments. The runtime comparison handled compiler-declared immutable fields separately, while constructor input bytes were checked in full. This connects the recorded execution to the compiled source; it does not identify a production deployment.

These checks establish repeatability and internal reconciliation of this local experiment. They are not additional empirical runs or independent authentication of production consensus.

## What an integration should track

The experiment supports keeping four records distinct: the application’s request ID, the source transaction and emitted message ID, the destination execution outcome, and the application’s resulting state.

A destination failure can leave an existing message retryable. A fresh source submission can create another valid message. A consumed-ID check can reject replay without imposing delivery order. None of those facts, alone, proves that the business operation completed exactly once across every system involved.

ERC-5164 makes the boundary explicit: it requires protection against multiple successful executions and permits retry after failure, while making no ordering guarantee. The Rayls source snapshot and local results make those distinctions inspectable in code and state.

For an institutional integration, the practical question is therefore more precise than “did the bridge transaction succeed?” It is: **which message ID executed, what application state changed, and is this a retry of that message or a new business submission?**

## Sources and reproducibility

- [ERC-5164: Cross-Chain Execution](https://eips.ethereum.org/EIPS/eip-5164)
- [Rayls: how a cross-chain transaction works](https://docs.rayls.com/docs/how-a-cross-chain-transaction-works)
- [Pinned Rayls contract repository](https://github.com/raylsnetwork/rayls-sovereign-contracts/tree/ed8863885c8ed5d5d317d47a34c063907192687a)
- [MessageSender](https://github.com/raylsnetwork/rayls-sovereign-contracts/blob/ed8863885c8ed5d5d317d47a34c063907192687a/src/rayls-protocol/modules/MessageSender.sol) and [BatchMessageSender](https://github.com/raylsnetwork/rayls-sovereign-contracts/blob/ed8863885c8ed5d5d317d47a34c063907192687a/src/rayls-protocol/modules/BatchMessageSender.sol)
- [MessageReceiver](https://github.com/raylsnetwork/rayls-sovereign-contracts/blob/ed8863885c8ed5d5d317d47a34c063907192687a/src/rayls-protocol/modules/MessageReceiver.sol)
- [RaylsMessageExecutorV1](https://github.com/raylsnetwork/rayls-sovereign-contracts/blob/ed8863885c8ed5d5d317d47a34c063907192687a/src/rayls-protocol/RaylsMessageExecutor/RaylsMessageExecutorV1.sol) and [MessageLib](https://github.com/raylsnetwork/rayls-sovereign-contracts/blob/ed8863885c8ed5d5d317d47a34c063907192687a/src/rayls-protocol-sdk/libraries/MessageLib.sol)

The accompanying **david-rayls-retry-study** package contains the complete local harness, pinned source bytes, four complete evidence runs, raw transaction and RPC records, opcode traces, separate saved-record verification, and an English README with Windows and Linux/macOS steps. No wallet, private key, real asset or mainnet transaction is required to reproduce it.

@RaylsLabs
