# Final validation record

## Executed evidence

- Three original fresh local runs, plus a fourth complete review execution after a fresh locked dependency installation in a separate project directory.
- Each: 33 focused cases, three deterministic 60-operation sequences, a separate Node process reopening the database, and three read-only opcode traces.
- Each: 579 local transactions, including 476 successful and 103 intentionally reverted transactions.
- Each: 107 source-emitted messages, 114 raw application-effect events and 113 committed executor IDs, with their distinct meanings documented.
- All four derived saved-record reports, comparable focused states and seeded final states matched; `review/four-run-comparison.json` retains the comparison.

## Code/data connection

- 383 vendored Git blobs checked against a newly fetched GitHub tree at the pinned commit, plus six freshly fetched critical files including upstream package metadata.
- Compilation resolved 66 source files with solc-js 0.8.24, original entry selection, optimizer 50 and Paris target.
- Fresh compiler executions reproduced 66 preserved contract artifacts.
- Creation input, linked library addresses and fixed runtime bytes matched 67 local deployments per run. Compiler-declared immutable ranges are explicitly handled and constructor inputs are checked in full.
- Raw receipts/events reconcile to counter getters and consumed-ID state. Revert bytes are linked to matching parent-state calls.
- Additional reviewer: all 579 transaction requests, raw receipts and mined inputs bound to RPC records; all 103 failed calls bound to exact caller/input/gas/value and parent-state simulations. The 248 recorded focused/seeded/restart snapshots were checked using 5,636 comparisons against same-block raw getter replies per run. These are comparisons, not 5,636 distinct replies or independent experiments.
- Computed mapping slots reconcile to raw storage reads and opcode SSTORE stack values. Before/after restart block hash, code hashes and selected state match.

## Verifier controls

The checker ignored a removed predecoded event summary and still used raw logs. It rejected intentionally changed raw effect data, storage words, case totals and revert selectors. These are checker controls on copied files, not extra blockchain experiments. Results are in `validation/verifier-controls.json`.

## Installation and presentation

- Clean `npm ci --ignore-scripts --no-audit --no-fund` passed after the documented optional-fsevents metadata fix.
- The untouched pre-fix generated lockfile is retained. No version, integrity value or Rayls source was changed by that fix.
- Article scope identifies the public-source snapshot, local EVM, synthetic application and manual transport early.
- Sender-emitted true-flag results are separated from manually constructed strict-mode false-flag controls.
- Dispatch batches are distinguished from direct executor batches.
- Three DAVID evidence figures were regenerated from checked data and visually inspected: banner 3200 × 1280; internal figures 3200 × 1800. They use the unchanged supplied full-colour Rayls symbol with its original black background and no wordmark. The homepage SVG is retained as an unused reference asset.
- The English reading copy embeds the figures and offers copying controls. The manuscript uses no text table that requires a social platform’s table support.

## Remaining publication steps and limits

No new GitHub repository or social post was published by this work. Upload the ZIP and landing README to a real public evidence URL and add that URL to the manuscript. The requested deliverable is a written article with file-based evidence.

The study does not establish live deployment equivalence, transport/proof authenticity, real membership/token validation, asset backing, distributed consensus/failover, arbitrary upgrade safety or exactly-once business processing. Native Windows execution was not tested. Passing this study is not a guarantee of an RP score.
