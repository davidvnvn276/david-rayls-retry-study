# Release checks

Release `david-retry-reviewed-20261021`.

- All four preserved baseline datasets passed raw receipt/state verification, the additional transaction/getter reviewer and deployment consistency checks during consolidation.
- Fresh execution of the same compiler reproduced the 66 preserved baseline contract artifacts.
- The new two-EVM application experiment was actually executed twice, with 16 matching deterministic case records per run. Each has 90 local transactions, seven deliberate reverts, 14 source messages and 19 delivery attempts.
- The separate application checker passed 90 transaction/RPC bindings, 940 getter bindings, 14 ID reconstructions and 19 receiver-input bindings per run. Intentional mutations of copied records were rejected.
- The original official-component manifest and 877 upstream blob checks passed. Its saved Node checker passed the 40 source replay bindings, 18 comparisons and retained transaction-encoding controls.
- The combined saved-observation audit passed all 19 commands. Command count is not an experiment count.
- Three current SVGs are derived from checked application cases. PNGs were fully decoded and dimensions checked: 3200 × 1280, 3200 × 1800 and 3200 × 1800. Text bounds/overlap checks and visual inspection were performed. The banner layout was adjusted after preview inspection.
- The supplied full-colour Rayls mark retains its original bytes and black background. No wordmark, account watermark or snapshot date is added.
- ARTICLE.html and SUBSTACK.html each embed the exact three current PNGs. Heading/table structure and JavaScript syntax were checked. No browser rendering or actual platform clipboard/import workflow is claimed as tested.
- The root release documents are current. Historical drafts and the original component supplement are explicitly labelled in the current guide.

The completed evidence remains local and bounded. The full official relayer/Hub/CTS service path, Axyl execution, authenticated production mapping and live financial outcomes are not established. The user's reported Windows restriction was not diagnosed without logs.

Distribution integrity and clean-extraction audit results are recorded alongside the final archive. Checksums establish byte identity, not independent authenticity of the observations. No score, exhaustive correctness or production-security guarantee follows from these checks.
