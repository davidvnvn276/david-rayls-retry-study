# Research design and source reconciliation

## Question

How can a destination execution remain retryable after failure without applying a successfully processed message twice?

## Initial probes and refinement

A preliminary local executor check established that consumed-ID state and application rollback could be exercised with the published code. This motivated a fuller fixture with real source and destination Endpoint modules and real Rayls access management.

Source inspection then identified an important qualification: both sender modules construct metadata with `ignoresNonce=true`. The final design therefore tests those actual emitted payloads first, and treats manually assembled false-flag inputs as a separate conditional branch. The study does not assume ordered delivery from the presence of a nonce field.

## Tested hypotheses

| Hypothesis | Evidence |
|---|---|
| A successful ID cannot commit a second application effect at the same executor | F01–F03, F09, seeded replays, restart replay |
| An application revert leaves the original ID retryable | F06–F08 and seeded failures/recoveries |
| A new source submission can carry the same application payload under a new ID | F04; emitted ID independently reconstructed |
| Source nonce order is necessarily destination execution order | Not supported for the emitted payloads in this harness: F05/F07; source flag true |
| Receiver strict-mode failure rolls back its tentative nonce advancement | Conditional controls F11–F16 |
| Consumed-ID state persists through the tested compatible upgrade and process restart | F31, raw mapping slots, before/after process snapshots |

The runs are a designed boundary study, not a statistical estimate of real network failure rates. The seeded sequences use three fixed seeds, 60 actions per fresh contract fixture, and a transparent independent counter/ID model. Repeating the same deterministic design checks repeatability rather than increasing the variety of deployed products observed.

## Contract route under test

The source user calls the actual source Endpoint, which calls the actual MessageSender or BatchMessageSender and emits a message. The harness captures that event. A locally authorized account passes it to the destination Endpoint, then the actual MessageReceiver, ResourceManager and MessageExecutor call the recording application.

The local injection replaces transport. It does not validate a source receipt against a remote consensus proof, encrypt/decrypt the payload or run the relayer queues. Source logical ID 10101 and destination logical ID 20202 live on the same Ganache chain. Existing mapping/direct-address resolution is tested; dynamic factory deployment is not.

## Other primary references

- ERC-5164: <https://eips.ethereum.org/EIPS/eip-5164>. It specifies unique cross-chain message identities, rejection of repeated successful execution and retry following failure, without ordering guarantees.
- Rayls’ cross-chain transaction description: <https://docs.rayls.com/docs/how-a-cross-chain-transaction-works>. It describes the broader source/hub/destination workflow and failure handling. The local experiment does not reproduce that entire workflow.
- Relayer source, pinned separately at `b01b427de4cfc2ac66e75eba0d5070b73a3b137c`: `private-relayer/dest/txgen/privatenode.go`. Its `Generate` method ABI-packs the supplied message and ID into `receivePayload`. This was source inspection only; it is not a claim that the relayer was executed or that every transport stage preserves a metadata flag under every configuration.

## What would extend this work

A further study could map a released deployment, run the actual relayer and proof path, inject transport outages, and reconcile source dispatches with destination state across separately running chains. It would also need an application with an explicit business-request identity to test that separate deduplication policy. Those are future experiments, not outcomes supplied here.
