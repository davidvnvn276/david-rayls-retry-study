# Current research map

Use ARTICLE.md, README.md, RESULTS.md and CLAIM_LEDGER.md as this release's current publication documents. The revision identifier is `david-retry-reviewed-20261021`.

The original one-EVM suite tests retry, consumed IDs, optional nonce enforcement, batch rollback, permissions and local state persistence. Its four preserved deterministic runs remain available.

The added two-EVM study isolates application request identity and ordering. It supplies a positive/negative application comparison, a distinct-request control, a conflicting-content control, source-context controls, same-ID failure recovery and noncommutative sequencing. Both executions have their own source inputs, receipts, RPC journals and pinned-state getters.

The official-component supplement retains actual Go proof/calldata execution and its narrow Ganache encoding result. It has a different dataset and its own preserved manifest. OFFICIAL_COMPONENTS.md explains how to interpret it.

The private-network service topology and production deployment identity remain outside completed execution. The user reported a Windows restriction on their attempted follow-up; no Windows error log is included, so this package does not diagnose that restriction or count it as an experiment. The observed Docker-preflight failure retained in the official supplement belongs to the original review host.

Historical publication drafts are under review/history. Their statements describe earlier scope and must not override this release's current documents. They are retained for provenance rather than silently rewritten as newly observed results.
