# Rayls message retry study — reviewed evidence

**Current reviewed release: `david-retry-reviewed-20261021`.**

This repository hosts the evidence for “Should You Retry or Resubmit a Cross-Chain Message? A Local Rayls Study.”

[Download the reviewed ZIP](./david-rayls-retry-study.zip), extract the complete `david-rayls-retry-study` folder, and confirm that `RELEASE.json` identifies the release above. The README inside the archive explains every command, expected result and limitation.

The consolidated package includes four preserved one-EVM baseline runs, two added two-EVM application runs, three exact evidence diagrams and the original official-component supplement.

The main comparison is 14 versus 7 synthetic units: two successful protocol IDs produce two effects in an unguarded fixture, but one effect in a fixture with a business request-ID check. Additional controls cover same-ID recovery, conflicting request content, trusted source context and noncommutative ordering.

## Check locally

From the extracted project root:

```bash
python verification/check_distribution.py
npm ci --ignore-scripts --no-audit --no-fund
node verification/verify_all.cjs --output runs/saved-audit-01
```

Run new local application observations:

```bash
node extensions/run.cjs --output runs/application-01
node extensions/verify.cjs runs/application-01
```

Node 24 was used for recorded Linux validation. Native Windows execution is not claimed. Docker, Go, a wallet and real assets are not required for these Node contract experiments. Fresh official Go component execution is optional and has separate instructions.

All delivery in the contract experiments is authorized and manual. The application units are synthetic. This is not a live institutional transport test, a production payment incident or an authenticated mapping to a current deployment. The full relayer/Hub/CTS path remains unverified.

Checksums identify distributed bytes; saved-record checks establish internal consistency. Neither independently authenticates production consensus. See the complete English README, CLAIM_LEDGER.md and OFFICIAL_COMPONENTS.md inside the ZIP.
