# Can a cross-chain message be retried safely?

This repository accompanies a local implementation study of Rayls’ message identity, retry and optional ordering behavior.

**Download:** [david-rayls-retry-study.zip](./david-rayls-retry-study.zip)

**Article:** [Read the English manuscript](./ARTICLE.md)

The ZIP contains a step-by-step English README, the full local harness, pinned source bytes, four complete evidence runs, raw receipts/RPC records, opcode traces, compiler/deployment checks and three DAVID evidence graphics.

Each complete run includes 33 focused cases, three 60-operation seeded sequences and a separate-process local database restart. The third original run and the fourth review execution followed separate clean dependency installations. The experiments repeat the same deterministic design; they are not observations from four live networks. The additional reviewer binds raw RPC submissions, receipts, mined inputs, getter snapshots and execution context; its checks are not extra EVM experiments.

**Scope:** public source commit `ed8863885c8ed5d5d317d47a34c063907192687a`, whose package metadata reports `2.6.3-nightly.2`; one local Ganache EVM; a synthetic counter application; permissive participant/token validation; manually delivered messages. No production deployment, live relayer, remote proof path, real payment or asset backing is established.

The main findings concern one committed execution per message ID, another ID for a new source submission, and the difference between source-emitted metadata and a conditional strict-nonce receiver branch. See the claim ledger and raw evidence before generalizing.

Official sources are linked in the article. This study is not an official Rayls release, endorsement or security certification.
