'use strict';
const assert=require('node:assert/strict');
const {ethers}=require('ethers');
const {FILES,toPlain,emptyMessage}=require('./harness.cjs');
const {write}=require('./common.cjs');
const DST=20202, SRC=10101, HUB=99999;
async function makeFixture(h,label) {
  const manager=await h.proxy(FILES.manager,'RaylsAccessManagerV1',[h.admin],label+'-manager');
  h.manager=manager;
  const executor=await h.proxy(FILES.executor,'RaylsMessageExecutorV1',[manager.address],label+'-executor');
  const endpoint=await h.proxy(FILES.endpoint,'EndpointV1',[DST,HUB,50,manager.address],label+'-destination-endpoint');
  const sourceEndpoint=await h.proxy(FILES.endpoint,'EndpointV1',[SRC,HUB,50,manager.address],label+'-source-endpoint');
  const resource=await h.deploy(FILES.resource,'ResourceManager',[ethers.ZeroAddress,h.admin,manager.address],label+'-resource-manager');
  const receiver=await h.deploy(FILES.receiver,'MessageReceiver',[resource.address,executor.address,endpoint.address,h.admin,manager.address],label+'-receiver');
  const validator=await h.deploy(FILES.fixtures,'PermissiveValidationFixture',[],label+'-permissive-validator');
  const sender=await h.deploy(FILES.sender,'MessageSender',[SRC,HUB,validator.address,validator.address,sourceEndpoint.address,h.admin,manager.address],label+'-source-message-sender');
  const batchSender=await h.deploy(FILES.batchSender,'BatchMessageSender',[HUB,validator.address,validator.address,sourceEndpoint.address,h.admin,manager.address],label+'-source-batch-sender');
  const a=await h.deploy(FILES.fixtures,'RecordingTarget',[],label+'-application-A');
  const b=await h.deploy(FILES.fixtures,'RecordingTarget',[],label+'-application-B');
  await h.send(endpoint,'configureModules',[resource.address,ethers.ZeroAddress,receiver.address,ethers.ZeroAddress],h.admin,label+'-configure-destination');
  // Only the non-local sending branch is used on sourceEndpoint. The supplied
  // receiver/resource references satisfy module wiring but are not called there.
  await h.send(sourceEndpoint,'configureModules',[resource.address,sender.address,receiver.address,batchSender.address],h.admin,label+'-configure-source');
  const deliveryRole=await h.role('LOCAL_DELIVERER',[[endpoint,['receivePayload']]],[h.deliverer]);
  const executorRole=await h.role('MESSAGE_RECEIVER',[[executor,['executeMessage','executeMessageBatch']]],[receiver.address,h.direct]);
  const resolverRole=await h.role('RESOURCE_RESOLVER',[[resource,['handleWithResourceId']]],[receiver.address]);
  const sourceRole=await h.role('LOCAL_SOURCE_USER',[[sourceEndpoint,['send(uint256,address,bytes)','sendBatch']]],[h.origin]);
  const f={label,manager,executor,endpoint,sourceEndpoint,resource,receiver,validator,sender,batchSender,a,b,roles:{deliveryRole,executorRole,resolverRole,sourceRole}};
  h.manager=manager; return f;
}
function serializeFixture(f) {
 const result={label:f.label,roles:f.roles};
 for(const [key,value] of Object.entries(f)) if(value&&value.address&&value.file) result[key]={file:value.file,name:value.name,address:value.address,implementation:value.implementation};
 return result;
}
function restoreFixture(h,info) {
 const f={label:info.label,roles:info.roles};
 for(const [key,x] of Object.entries(info)) if(x&&x.address&&x.file) f[key]=h.handle(x.file,x.name,x.address);
 h.manager=f.manager; return f;
}
function messageIdFromSource(f,from,to,message,senderAddress=f.sender.address) {
 const param=f.sourceEndpoint.interface.getEvent('MessageDispatched').inputs[4];
 const encoded=ethers.AbiCoder.defaultAbiCoder().encode([param],[message]);
 return ethers.keccak256(ethers.AbiCoder.defaultAbiCoder().encode(['address','uint256','address','uint256','address','bytes'],[senderAddress,SRC,from,DST,to,encoded]));
}
async function dispatch(h,f,units,target,label) {
 const payload=target.interface.encodeFunctionData('applyEffect',[units]);
 const rec=await h.send(f.sourceEndpoint,'send(uint256,address,bytes)',[DST,target.address,payload],h.origin,label+'-source-dispatch');
 const ev=rec.decoded_logs.find(x=>x.name==='MessageDispatched');
 assert.ok(ev,label+' missing source event');
 const m={id:ev.args.messageId,from:ev.args.from,sourceChainId:SRC,destinationChainId:DST,to:ev.args.to,message:ev.args.data,units:String(units),target:target.address,dispatch_hash:rec.receipt.transactionHash};
 assert.equal(m.message.messageMetadata.ignoresNonce,true,'Pinned MessageSender flag changed');
 assert.equal(messageIdFromSource(f,m.from,m.to,m.message),m.id,'Independent source ID reconstruction failed');
 return m;
}
async function dispatchBatch(h,f,items,label) {
 // Endpoint.sendBatch wraps its three-field DestinationPayloadRequest[] into
 // the internal SendRequest[] consumed by BatchMessageSender.
 const requests=items.map(({units,target})=>({_dstChainId:DST,_destination:target.address,_payload:target.interface.encodeFunctionData('applyEffect',[units])}));
 const rec=await h.send(f.sourceEndpoint,'sendBatch',[requests],h.origin,label+'-source-dispatch-batch');
 const ev=rec.decoded_logs.find(x=>x.name==='MessageBatchDispatched'); assert.ok(ev);
 const messages=ev.args.messages.map((x,i)=>({id:x.messageId,from:h.origin,sourceChainId:SRC,destinationChainId:DST,to:x.to,message:x.data,units:String(items[i].units),target:items[i].target.address,dispatch_hash:rec.receipt.transactionHash}));
 for(const m of messages) {
   assert.equal(m.message.messageMetadata.ignoresNonce,true);
   assert.equal(messageIdFromSource(f,m.from,m.to,m.message,f.batchSender.address),m.id);
 }
 return {batchId:ev.args.batchId,messages,requests,dispatch_hash:rec.receipt.transactionHash};
}
async function deliver(h,f,m,label,expected='success',caller=h.deliverer) {
 return h.send(f.endpoint,'receivePayload',[m.sourceChainId,m.from,m.to,m.message,m.id],caller,label,expected);
}
function synthetic(h,f,name,target,units,nonce=1,ignore=false,source=SRC) {
 const message=emptyMessage(nonce,ignore); message.payload=target.interface.encodeFunctionData('applyEffect',[units]);
 return {id:ethers.id('controlled-'+f.label+'-'+name),from:h.origin,sourceChainId:source,destinationChainId:DST,to:target.address,message,units:String(units),target:target.address,provenance:'Controlled receiver input; not emitted or authenticated by source/transport'};
}
module.exports={DST,SRC,HUB,makeFixture,serializeFixture,restoreFixture,dispatch,dispatchBatch,deliver,synthetic,messageIdFromSource};
