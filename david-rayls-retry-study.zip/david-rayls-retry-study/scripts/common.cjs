'use strict';
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const ROOT = path.resolve(__dirname, '..');
const COMMIT = 'ed8863885c8ed5d5d317d47a34c063907192687a';
const VENDOR = 'vendor/rayls-contracts/';
const FILES = {
  manager: VENDOR+'src/privateHub/AccessControl/RaylsAccessManagerV1.sol',
  executor: VENDOR+'src/rayls-protocol/RaylsMessageExecutor/RaylsMessageExecutorV1.sol',
  endpoint: VENDOR+'src/rayls-protocol/Endpoint/EndpointV1.sol',
  receiver: VENDOR+'src/rayls-protocol/modules/MessageReceiver.sol',
  resource: VENDOR+'src/rayls-protocol/modules/ResourceManager.sol',
  sender: VENDOR+'src/rayls-protocol/modules/MessageSender.sol',
  batchSender: VENDOR+'src/rayls-protocol/modules/BatchMessageSender.sol',
  proxy: '@openzeppelin/contracts/proxy/ERC1967/ERC1967Proxy.sol',
  fixtures: 'test-contracts/StudyFixtures.sol'
};
const stringify = x => JSON.stringify(x, (_,v)=>typeof v==='bigint'?v.toString():v, 2)+'\n';
function write(file, data) {fs.mkdirSync(path.dirname(file),{recursive:true}); fs.writeFileSync(file,stringify(data));}
function sha256(value) {return crypto.createHash('sha256').update(value).digest('hex');}
function gitBlob(value) {return crypto.createHash('sha1').update(Buffer.from('blob '+value.length+'\0')).update(value).digest('hex');}
function verifyVendor() {
  const provenance=JSON.parse(fs.readFileSync(path.join(ROOT,'sources/provenance.json')));
  if(provenance.commit!==COMMIT) throw Error('Unexpected source commit');
  for(const file of provenance.files) {
    const bytes=fs.readFileSync(path.join(ROOT,VENDOR,file.path));
    if(bytes.length!==file.size || gitBlob(bytes)!==file.git_blob_sha1) throw Error('Vendor identity mismatch: '+file.path);
  }
  if(provenance.upstream_package_metadata){
    const m=provenance.upstream_package_metadata,bytes=fs.readFileSync(path.join(ROOT,m.saved_path));
    if(bytes.length!==m.size||gitBlob(bytes)!==m.git_blob_sha1)throw Error('Upstream package metadata identity mismatch');
  }
  return provenance.files.length;
}
function compile(out) {
  const solc=require('solc');
  const resolved={};
  const imports=name=>{
    for(const base of [ROOT,path.join(ROOT,'node_modules')]) {
      const file=path.resolve(base,name);
      if(file.startsWith(base+path.sep) && fs.existsSync(file)) {
        const content=fs.readFileSync(file,'utf8'); resolved[name]={content}; return {contents:content};
      }
    }
    return {error:'Missing source: '+name};
  };
  const sources={};
  for(const file of Object.values(FILES)) {const r=imports(file); if(r.error)throw Error(r.error); sources[file]={content:r.contents};}
  const settings={optimizer:{enabled:true,runs:50},evmVersion:'paris',outputSelection:{'*':{'*':['abi','evm.bytecode','evm.deployedBytecode','storageLayout']}}};
  const input={language:'Solidity',sources,settings};
  const result=JSON.parse(solc.compile(JSON.stringify(input),{import:imports}));
  const errors=(result.errors||[]).filter(x=>x.severity==='error');
  write(path.join(out,'compiler-diagnostics.json'),result.errors||[]);
  if(errors.length) throw Error(errors.map(x=>x.formattedMessage).join('\n'));
  const fullInput={language:'Solidity',sources:resolved,settings};
  write(path.join(out,'solc-input.json'),fullInput);
  write(path.join(out,'compiled-contracts.json'),result.contracts);
  write(path.join(out,'build-provenance.json'),{
    compiler:solc.version(),source_commit:COMMIT,verified_vendor_files:verifyVendor(),
    evm_version:'paris',optimizer_runs:50,source_count:Object.keys(resolved).length,
    input_sha256:sha256(fs.readFileSync(path.join(out,'solc-input.json'))),
    resolved_source_sha256:Object.fromEntries(Object.entries(resolved).map(([name,x])=>[name,sha256(x.content)]))
  });
  return result.contracts;
}
module.exports={ROOT,COMMIT,FILES,stringify,write,sha256,gitBlob,verifyVendor,compile};
