'use strict';
const path=require('node:path');
const assert=require('node:assert/strict');
const {ethers}=require('ethers');
const {FILES,write}=require('./common.cjs');
const {dispatch,dispatchBatch,deliver,synthetic}=require('./fixtures.cjs');

async function focused(h,f) {
 h.manager=f.manager;
 const cases=[],messages=[];
 async function make(units,target,label) {const m=await dispatch(h,f,units,target,label);messages.push(m);return m;}
 async function test(key,title,ids,action,check,scope='source-generated payload through the destination Endpoint/Receiver/Executor') {
   const before=await h.snapshot(f,ids),start=h.records.length;
   const extra=await action();
   const after=await h.snapshot(f,ids);
   await check(before,after,extra);
   const record={key,title,status:'passed',scope,before,after,transactions:h.records.slice(start),detail:extra};
   write(path.join(h.out,'focused',key+'.json'),record);cases.push(record);
   console.log('PASS',key,title);return record;
 }
 const noEffects=(a,b)=>assert.deepEqual(b.targets,a.targets);
 const m1=await make(7,f.a,'F01');
 await test('F01','first source-generated message executes once',[m1.id],()=>deliver(h,f,m1,'F01-first-delivery'),(a,b,r)=>{
   assert.equal(BigInt(b.targets.A.total)-BigInt(a.targets.A.total),7n);assert.equal(b.executed[m1.id],true);
   const effect=r.decoded_logs.find(x=>x.name==='EffectApplied');
   assert.equal(effect.args.messageId,m1.id);assert.equal(effect.args.sourceChainId,'10101');
   assert.equal(effect.args.sourceSender.toLowerCase(),h.origin.toLowerCase());assert.equal(effect.args.immediateCaller.toLowerCase(),f.executor.address.toLowerCase());
 });
 await test('F02','exact replay is rejected by the consumed-ID guard',[m1.id],()=>deliver(h,f,m1,'F02-exact-replay','MessageIdAlreadyExecuted'),(a,b)=>{noEffects(a,b);assert.equal(b.executed[m1.id],true);});
 const redirected={...m1,to:f.b.address};
 await test('F03','same consumed ID with another target is rejected',[m1.id],()=>deliver(h,f,redirected,'F03-mutated-target','MessageIdAlreadyExecuted'),noEffects,'controlled, noncanonical receiver input; transport authentication is not tested');
 const m2=await make(7,f.a,'F04');
 assert.equal(m1.message.payload,m2.message.payload);assert.notEqual(m1.id,m2.id);
 await test('F04','a new source submission has a new ID and executes the same application payload',[m1.id,m2.id],async()=>({receipt:await deliver(h,f,m2,'F04-new-source-submission'),original:m1,second:m2}),(a,b)=>{
   assert.equal(BigInt(b.targets.A.total)-BigInt(a.targets.A.total),7n);assert.equal(b.executed[m1.id],true);assert.equal(b.executed[m2.id],true);
 });
 const earlier=await make(11,f.a,'F05-earlier');
 const later=await make(13,f.b,'F05-later');
 await test('F05','later source nonce can execute before earlier nonce when the sender flag is true',[earlier.id,later.id],async()=>({later:await deliver(h,f,later,'F05-later-first'),earlier:await deliver(h,f,earlier,'F05-earlier-second'),source_nonces:[earlier.message.messageMetadata.nonce,later.message.messageMetadata.nonce]}),(a,b)=>{
   assert.equal(b.nonces['10101'],'0');assert.equal(b.executed[earlier.id],true);assert.equal(b.executed[later.id],true);
   assert.equal(BigInt(b.targets.A.total)-BigInt(a.targets.A.total),11n);assert.equal(BigInt(b.targets.B.total)-BigInt(a.targets.B.total),13n);
 });
 const retry=await make(17,f.b,'F06');
 await h.send(f.b,'setFailure',[true],h.admin,'F06-enable-controlled-failure');
 await test('F06','application failure rolls back the consumed-ID write',[retry.id],()=>deliver(h,f,retry,'F06-failed-delivery','MessageFailure'),(a,b,r)=>{
   noEffects(a,b);assert.equal(b.executed[retry.id],false);assert.equal(r.revert.inner.name,'ControlledTargetFailure');assert.equal(r.receipt.logs.length,0);
 });
 const progress=await make(19,f.a,'F07');
 await test('F07','a later default-path message progresses while another message remains failed',[retry.id,progress.id],()=>deliver(h,f,progress,'F07-later-progress'),(a,b)=>{
   assert.equal(b.executed[retry.id],false);assert.equal(b.executed[progress.id],true);assert.equal(b.nonces['10101'],'0');
 });
 await h.send(f.b,'setFailure',[false],h.admin,'F08-remove-controlled-failure');
 await test('F08','the identical failed payload and ID succeed after recovery',[retry.id],()=>deliver(h,f,retry,'F08-retry-same-message'),(a,b)=>{
   assert.equal(b.executed[retry.id],true);assert.equal(BigInt(b.targets.B.total)-BigInt(a.targets.B.total),17n);
 });
 await test('F09','retry after recovery is rejected once success is committed',[retry.id],()=>deliver(h,f,retry,'F09-replay-recovered-message','MessageIdAlreadyExecuted'),noEffects);
 const batch=await dispatchBatch(h,f,[{units:7,target:f.a},{units:3,target:f.b}],'F10');
 messages.push(...batch.messages);
 assert.equal(batch.messages[0].message.messageMetadata.nonce,m1.message.messageMetadata.nonce);
 assert.deepEqual(batch.messages[0].message,m1.message);
 assert.notEqual(batch.messages[0].id,m1.id);
 await test('F10','single and dispatch-batch modules produce distinct IDs for identical nonce and message data',batch.messages.map(x=>x.id),async()=>({batch,second:await deliver(h,f,batch.messages[1],'F10-dispatch-batch-second-first'),first:await deliver(h,f,batch.messages[0],'F10-dispatch-batch-first-second')}),(a,b)=>{
   for(const m of batch.messages)assert.equal(b.executed[m.id],true);assert.equal(b.nonces['10101'],'0');
 });

 const strict1=synthetic(h,f,'strict-1',f.a,2,1,false);
 const strict2=synthetic(h,f,'strict-2',f.b,5,2,false);
 const strict3=synthetic(h,f,'strict-3',f.a,3,3,false);
 messages.push(strict1,strict2,strict3);
 const strictScope='conditional receiver-policy probe with manually assembled ignoresNonce=false; not the pinned senders default';
 await test('F11','explicit strict mode advances inbound nonce', [strict1.id],()=>deliver(h,f,strict1,'F11-strict-one'),(a,b)=>assert.equal(b.nonces['10101'],'1'),strictScope);
 await h.send(f.b,'setFailure',[true],h.admin,'F12-enable-failure');
 await test('F12','strict-mode target failure also rolls back inbound nonce',[strict2.id],()=>deliver(h,f,strict2,'F12-strict-failure','MessageFailure'),(a,b)=>{
   noEffects(a,b);assert.equal(b.nonces['10101'],'1');assert.equal(b.executed[strict2.id],false);
 },strictScope);
 await test('F13','strict-mode nonce gap is rejected',[strict3.id],()=>deliver(h,f,strict3,'F13-strict-gap','MessageReceiver__WrongNonce'),(a,b,r)=>{
   noEffects(a,b);assert.deepEqual(r.revert.args,['2','3']);assert.equal(b.nonces['10101'],'1');
 },strictScope);
 const other=synthetic(h,f,'strict-other-source',f.a,4,1,false,30303);messages.push(other);
 await test('F14','conditional strict-mode counters are separate per source',[other.id],()=>deliver(h,f,other,'F14-other-source'),(a,b)=>{assert.equal(b.nonces['30303'],'1');assert.equal(b.nonces['10101'],'1');},strictScope);
 await h.send(f.b,'setFailure',[false],h.admin,'F15-remove-failure');
 await test('F15','strict-mode recovery permits the waiting sequence',[strict2.id,strict3.id],async()=>({second:await deliver(h,f,strict2,'F15-strict-retry'),third:await deliver(h,f,strict3,'F15-strict-next')}),(a,b)=>assert.equal(b.nonces['10101'],'3'),strictScope);
 const newNonceOldId=synthetic(h,f,'invalid-relabel',f.a,2,4,false);newNonceOldId.id=strict1.id;
 await test('F16','consumed-ID rejection rolls back a fresh strict-mode nonce',[strict1.id],()=>deliver(h,f,newNonceOldId,'F16-consumed-id-new-nonce','MessageIdAlreadyExecuted'),(a,b)=>{noEffects(a,b);assert.equal(b.nonces['10101'],'3');},'noncanonical controlled injection; not a proof-valid cross-chain message');

 const roleMessage=await make(2,f.a,'F17');
 await h.send(f.manager,'revokeRole',[f.roles.executorRole,f.receiver.address],h.admin,'F17-revoke-executor-permission');
 await test('F17','temporary permission loss does not consume an ID',[roleMessage.id],()=>deliver(h,f,roleMessage,'F17-denied-executor','RaylsAccessManaged__Unauthorized'),(a,b)=>{noEffects(a,b);assert.equal(b.executed[roleMessage.id],false);});
 await h.send(f.manager,'grantRole',[f.roles.executorRole,f.receiver.address,0],h.admin,'F18-restore-executor-permission');
 await test('F18','same message works after permission is restored',[roleMessage.id],()=>deliver(h,f,roleMessage,'F18-retry-after-role-restored'),(a,b)=>assert.equal(b.executed[roleMessage.id],true));
 const paused=await make(3,f.b,'F19');
 await h.send(f.manager,'setContractPaused',[f.executor.address,true],h.admin,'F19-pause-executor');
 await test('F19','pause rejection leaves ID retryable',[paused.id],()=>deliver(h,f,paused,'F19-paused','RaylsAccessManaged__ContractPaused'),(a,b)=>{noEffects(a,b);assert.equal(b.executed[paused.id],false);});
 await h.send(f.manager,'setContractPaused',[f.executor.address,false],h.admin,'F20-unpause-executor');
 await test('F20','same message works after unpause',[paused.id],()=>deliver(h,f,paused,'F20-retry-after-unpause'),(a,b)=>assert.equal(b.executed[paused.id],true));
 const unauthorized=await make(5,f.a,'F21');
 await test('F21','outer Endpoint authorization rejects an outsider',[unauthorized.id],()=>deliver(h,f,unauthorized,'F21-outsider','RaylsAccessManaged__Unauthorized',h.outsider),(a,b)=>{noEffects(a,b);assert.equal(b.executed[unauthorized.id],false);});
 await deliver(h,f,unauthorized,'F21-authorized-control');
 await test('F22','direct access to the receiver bypassing its Endpoint is rejected',[],()=>h.send(f.receiver,'receivePayload',[10101,m1.from,m1.to,m1.message,m1.id],h.deliverer,'F22-bypass-endpoint','MessageReceiver__UnauthorizedEndpoint'),noEffects,'local authorization boundary probe');

 const missing=synthetic(h,f,'missing-resource',f.b,6,1,true,40404);missing.to=ethers.ZeroAddress;missing.message.messageMetadata.resourceId=ethers.id('study-resource');messages.push(missing);
 await test('F23','unresolved resource produces no target effect or consumed ID',[missing.id],()=>deliver(h,f,missing,'F23-unresolved-resource','Error'),(a,b,r)=>{noEffects(a,b);assert.equal(b.executed[missing.id],false);assert.equal(r.revert.args[0],'MessageLib/no-contract-at-to');},'controlled resource-resolution probe; automatic factory deployment is not exercised');
 await h.send(f.resource,'registerResourceId',[missing.message.messageMetadata.resourceId,f.b.address],h.admin,'F24-register-resource');
 await test('F24','same controlled message succeeds after resource registration',[missing.id],()=>deliver(h,f,missing,'F24-resource-retry'),(a,b)=>{assert.equal(b.executed[missing.id],true);assert.equal(BigInt(b.targets.B.total)-BigInt(a.targets.B.total),6n);},'controlled resource-resolution probe');

 const atomicId=ethers.id('study-atomic-executor-batch');
 const atomicMessages=[{to:f.a.address,data:f.a.interface.encodeFunctionData('applyEffect',[2])},{to:f.b.address,data:f.b.interface.encodeFunctionData('applyEffect',[3])},{to:f.a.address,data:f.a.interface.encodeFunctionData('applyEffect',[5])}];
 const batchScope='direct executeMessageBatch probe; distinct from Endpoint sendBatch and not a cross-chain atomic-settlement test';
 await h.send(f.b,'setFailure',[true],h.admin,'F25-enable-middle-batch-failure');
 await test('F25','an executor batch failure rolls back earlier subcall effects',[atomicId],()=>h.send(f.executor,'executeMessageBatch',[atomicMessages,atomicId,10101,h.origin],h.direct,'F25-executor-batch-failure','MessageBatchFailure'),(a,b,r)=>{
   noEffects(a,b);assert.equal(b.executed[atomicId],false);assert.equal(r.revert.args[1],'1');assert.equal(r.revert.inner.name,'ControlledTargetFailure');assert.equal(r.receipt.logs.length,0);
 },batchScope);
 await h.send(f.b,'setFailure',[false],h.admin,'F26-remove-middle-batch-failure');
 await test('F26','same executor batch ID succeeds after recovery',[atomicId],()=>h.send(f.executor,'executeMessageBatch',[atomicMessages,atomicId,10101,h.origin],h.direct,'F26-executor-batch-retry'),(a,b,r)=>{
   assert.equal(BigInt(b.targets.A.total)-BigInt(a.targets.A.total),7n);assert.equal(BigInt(b.targets.B.total)-BigInt(a.targets.B.total),3n);assert.equal(r.decoded_logs.filter(x=>x.name==='EffectApplied').length,3);assert.equal(b.executed[atomicId],true);
 },batchScope);
 await test('F27','single execution cannot reuse a successful executor-batch ID',[atomicId],()=>h.send(f.executor,'executeMessage',[f.a.address,f.a.interface.encodeFunctionData('applyEffect',[1]),atomicId,10101,h.origin],h.direct,'F27-batch-to-single','MessageIdAlreadyExecuted'),noEffects,batchScope);
 await test('F28','executor batch cannot reuse a successful single-message ID',[m1.id],()=>h.send(f.executor,'executeMessageBatch',[atomicMessages,m1.id,10101,h.origin],h.direct,'F28-single-to-batch','MessageIdAlreadyExecuted'),noEffects,batchScope);

 const reentry=await h.deploy(FILES.fixtures,'ReentryTarget',[],'reentry-target');
 await h.send(f.manager,'grantRole',[f.roles.executorRole,reentry.address,0],h.admin,'F29-authorize-reentry-target-to-isolate-guard');
 const innerId=ethers.id('study-nested-id'),outerId=ethers.id('study-outer-id');
 const nested=f.executor.interface.encodeFunctionData('executeMessage',[f.a.address,f.a.interface.encodeFunctionData('applyEffect',[10]),innerId,10101,h.origin]);
 await h.send(reentry,'configure',[f.executor.address,nested],h.admin,'F29-configure-nested-call');
 await test('F29','receive reentrancy guard rejects a nested authorized attempt',[innerId,outerId],()=>h.send(f.executor,'executeMessage',[reentry.address,reentry.interface.encodeFunctionData('trigger'),outerId,10101,h.origin],h.direct,'F29-reentrancy-control'),(a,b,r)=>{
   noEffects(a,b);assert.equal(b.executed[innerId],false);assert.equal(b.executed[outerId],true);
   const ev=r.decoded_logs.find(x=>x.name==='NestedAttempt');assert.equal(ev.args.succeeded,false);assert.equal(h.decodeError(ev.args.returnedData).args[0],'Rayls: no receive reentrancy');
 },'synthetic reentry callback with a deliberately granted executor role; not an exploit on a live deployment');

 const v2=await h.deploy(FILES.fixtures,'StudyExecutorV2',[],'study-only-storage-compatible-executor-v2');
 await test('F30','unauthorized UUPS upgrade is rejected',[m1.id],()=>h.send(f.executor,'upgradeToAndCall',[v2.address,'0x'],h.outsider,'F30-unauthorized-upgrade','RaylsAccessManaged__Unauthorized'),(a,b)=>assert.equal(b.executed[m1.id],true),'local UUPS permission check');
 await test('F31','compatible test upgrade preserves the consumed-ID boundary',[m1.id],async()=>{
   const old=await h.read(f.executor,'contractVersion');assert.equal(old,1n);
   const up=await h.send(f.executor,'upgradeToAndCall',[v2.address,'0x'],h.admin,'F31-compatible-test-upgrade');
   assert.equal(await h.read(f.executor,'contractVersion'),2n);
   const duplicate=await deliver(h,f,m1,'F31-replay-after-upgrade','MessageIdAlreadyExecuted');return {upgrade:up,replay:duplicate,new_implementation:v2.address};
 },(a,b)=>{noEffects(a,b);assert.equal(b.executed[m1.id],true);},'test-only V2 changes contractVersion and adds no storage; arbitrary upgrades and production migrations are not certified');
 const postUpgrade=await make(5,f.a,'F32');
 await test('F32','fresh source-generated message works after the compatible test upgrade',[postUpgrade.id],()=>deliver(h,f,postUpgrade,'F32-fresh-after-upgrade'),(a,b)=>assert.equal(b.executed[postUpgrade.id],true));
 const bad=await make(1,{...f.a,address:h.outsider},'F33');
 await test('F33','code-less destination fails without consuming its ID',[bad.id],()=>deliver(h,f,bad,'F33-no-contract','Error'),(a,b,r)=>{noEffects(a,b);assert.equal(b.executed[bad.id],false);assert.equal(r.revert.args[0],'MessageLib/no-contract-at-to');});
 write(path.join(h.out,'focused-index.json'),cases.map(({key,title,status,scope})=>({key,title,status,scope,file:'focused/'+key+'.json'})));
 write(path.join(h.out,'source-and-controlled-messages.json'),messages);
 return {cases,messages,restart_message:m1,unconsumed_message:bad,upgrade:v2.address,tracked_ids:[m1.id,retry.id,atomicId,bad.id]};
}
module.exports={focused};
