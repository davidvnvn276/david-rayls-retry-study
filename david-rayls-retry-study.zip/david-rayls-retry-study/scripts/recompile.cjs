'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const {ROOT,FILES,write,sha256}=require('./common.cjs');
const args=process.argv.slice(2);if(args.length!==1)throw Error('Usage: node scripts/recompile.cjs evidence/run-01');
const out=path.resolve(ROOT,args[0]),solc=require('solc');
const input=fs.readFileSync(path.join(out,'solc-input.json'),'utf8');
const expected=JSON.parse(fs.readFileSync(path.join(out,'compiled-contracts.json')));
// solc-input.json preserves the expanded import closure. Keep the original
// entry-point set instead of promoting every imported file to a new root.
const closure=JSON.parse(input);
const entryPaths=Object.values(FILES);
const entries={...closure,sources:Object.fromEntries(entryPaths.map(p=>[p,closure.sources[p]]))};
const compiled=JSON.parse(solc.compile(JSON.stringify(entries),{import:name=>closure.sources[name]?{contents:closure.sources[name].content}:{error:'Missing preserved import '+name}}));
const errors=(compiled.errors||[]).filter(x=>x.severity==='error');assert.equal(errors.length,0,JSON.stringify(errors));
assert.deepEqual(compiled.contracts,expected,'Recompiled contract artifacts differ');
const count=Object.values(compiled.contracts).reduce((n,x)=>n+Object.keys(x).length,0);
write(path.join(out,'recompile-verification.json'),{status:'passed',compiler:solc.version(),expanded_source_input_sha256:sha256(input),entry_source_paths:entryPaths,contracts_compared:count,all_abi_bytecode_link_references_and_storage_layouts_match:true,scope:'A fresh execution of the same solc-js compiler using the original entry files and preserved source closure. Not an independent compiler implementation or proof of a production deployment.'});
console.log('PASS fresh compiler execution:',count,'contract artifacts match the preserved output');
