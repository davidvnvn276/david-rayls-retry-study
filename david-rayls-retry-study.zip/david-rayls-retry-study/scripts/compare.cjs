'use strict';
const fs=require('node:fs');
const path=require('node:path');
const assert=require('node:assert/strict');
const {ROOT,write}=require('./common.cjs');
const args=process.argv.slice(2);
if(args.length<2)throw Error('Usage: node scripts/compare.cjs evidence/run-01 evidence/run-02 [evidence/run-03]');
const dirs=args.map(x=>path.resolve(ROOT,x));
const read=(i,file)=>JSON.parse(fs.readFileSync(path.join(dirs[i],file)));
const reports=dirs.map((_,i)=>read(i,'saved-record-verification.json'));
for(let i=1;i<dirs.length;i++)assert.deepEqual(reports[0],reports[i],'Derived saved-record results differ');
for(const item of read(0,'focused-index.json')) {
 const a=read(0,item.file);
 for(let i=1;i<dirs.length;i++){const b=read(i,item.file);for(const field of ['key','title','scope','before','after'])assert.deepEqual(a[field],b[field],item.key+' '+field);}
}
for(const seed of [1701,2909,4177]) {
 const a=read(0,'seeded/seed-'+seed+'/summary.json');
 for(let i=1;i<dirs.length;i++){const b=read(i,'seeded/seed-'+seed+'/summary.json');for(const field of ['seed','operations','actions','issued_messages','delivered_unique_messages','final_state','drained_ids','steps'])assert.deepEqual(a[field],b[field],'Seed '+seed+' '+field);}
}
const result={status:'passed',scope:'Repeatability across fresh local-chain runs of the same deterministic fixtures; not independent production observations.',runs:args,focused_cases_per_run:33,seeded_sequences_per_run:3,seeded_operations_per_run:180,transactions_per_run:reports[0].transactions,source_generated_messages_per_run:reports[0].source_generated_messages,raw_effect_events_per_run:reports[0].raw_effect_events,all_comparable_focused_states_equal:true,all_seeded_action_sequences_and_final_states_equal:true,all_derived_record_reports_equal:true};
write(path.join(ROOT,'evidence/repeatability-comparison.json'),result);
console.log('PASS',dirs.length,'fresh-chain runs have matching scenario states, seeded sequences and derived evidence.');
