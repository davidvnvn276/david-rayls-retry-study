'use strict';
// Quality check of the saved-record verifier, not another blockchain experiment.
const fs=require('node:fs'),path=require('node:path'),os=require('node:os'),cp=require('node:child_process');
const assert=require('node:assert/strict');
const {ethers}=require('ethers');
const {ROOT,FILES,write}=require('./common.cjs');
const args=process.argv.slice(2);
if(args.length!==1)throw Error('Usage: node scripts/tamper_check.cjs evidence/run-01');
const source=path.resolve(ROOT,args[0]),temp=fs.mkdtempSync(path.join(os.tmpdir(),'david-record-check-'));
const index=JSON.parse(fs.readFileSync(path.join(source,'transaction-index-experiment.json')));
const first=index.find(x=>x.label==='F01-first-delivery').file;
const effectTopic=ethers.id('EffectApplied(bytes32,uint256,address,uint256,uint256,uint256,address)');
const coder=ethers.AbiCoder.defaultAbiCoder();
const tests=[];
function alter(file,fn){const x=JSON.parse(fs.readFileSync(file));fn(x);fs.writeFileSync(file,JSON.stringify(x,null,2)+'\n');}
function check(name,expectedSuccess,mutate){
 const dir=path.join(temp,name);fs.cpSync(source,dir,{recursive:true,filter:p=>!p.split(path.sep).includes('local-chain-db')});
 mutate(dir);
 const result=cp.spawnSync(process.execPath,[path.join(ROOT,'scripts/verify.cjs'),dir],{cwd:ROOT,encoding:'utf8'});
 assert.equal(result.status===0,expectedSuccess,name+' unexpected checker outcome');
 tests.push({name,status:'passed',expected_verifier_success:expectedSuccess,actual_exit_code:result.status,stdout:result.stdout,stderr:result.stderr});
 console.log('PASS checker control',name);
}
try{
 check('predecoded-summary-ignored',true,dir=>alter(path.join(dir,first),x=>{x.decoded_logs=[];}));
 check('altered-raw-effect-rejected',false,dir=>alter(path.join(dir,first),x=>{
   const log=x.receipt.logs.find(l=>l.topics[0]===effectTopic);
   const values=Array.from(coder.decode(['uint256','address','uint256','uint256','uint256','address'],log.data));values[2]+=1n;
   log.data=coder.encode(['uint256','address','uint256','uint256','uint256','address'],values);
 }));
 check('altered-storage-word-rejected',false,dir=>{
   for(const name of ['before-process-restart.json','after-process-restart.json'])alter(path.join(dir,name),x=>{
     const id=Object.keys(x.consumed_storage).find(id=>x.state.executed[id]);x.consumed_storage[id].value='0x';
   });
 });
 check('altered-case-total-rejected',false,dir=>alter(path.join(dir,'focused/F04.json'),x=>{x.after.targets.A.total='15';}));
 check('altered-revert-selector-rejected',false,dir=>{
   const file=index.find(x=>x.label==='F02-exact-replay').file;
   alter(path.join(dir,file),x=>{x.revert.raw='0x00000000'+x.revert.raw.slice(10);});
 });
 write(path.join(ROOT,'validation/verifier-controls.json'),{status:'passed',scope:'Verifier integrity controls. Intentionally altered copies are not experiment observations.',source_run:args[0],controls:tests});
}finally{fs.rmSync(temp,{recursive:true,force:true});}
