'use strict';
const fs=require('node:fs');
const path=require('node:path');
const cp=require('node:child_process');
const {ROOT,COMMIT,write,compile,verifyVendor}=require('./common.cjs');
let output;
const args=process.argv.slice(2);
if(args.length===2&&args[0]==='--output')output=args[1];
else if(args.length===0)output='runs/my-check-01';
else throw Error('Usage: node scripts/run.cjs --output runs/my-check-01');
const out=path.resolve(ROOT,output);
if(fs.existsSync(out))throw Error('Output already exists. Preserve it and choose a new directory.');
fs.mkdirSync(out,{recursive:true});
const start=new Date().toISOString();
console.log('Source pin:',COMMIT);
console.log('Source identity:',verifyVendor(),'Git blobs match');
console.log('Compiling pinned sources and test fixtures locally...');
compile(out);
for(const phase of ['experiment','restart','trace']) {
 console.log('Starting',phase,'in a separate Node process');
 const stdout=fs.openSync(path.join(out,phase+'-stdout.txt'),'w');
 const stderr=fs.openSync(path.join(out,phase+'-stderr.txt'),'w');
 let result;
 const command=phase==='trace'?[path.join(__dirname,'capture_traces.cjs'),out]:[path.join(__dirname,'worker.cjs'),phase,out];
 try{result=cp.spawnSync(process.execPath,command,{cwd:ROOT,stdio:['ignore',stdout,stderr]});}
 finally{fs.closeSync(stdout);fs.closeSync(stderr);}
 process.stdout.write(fs.readFileSync(path.join(out,phase+'-stdout.txt'),'utf8'));
 if(result.error||result.status!==0) {
   process.stderr.write(fs.readFileSync(path.join(out,phase+'-stderr.txt'),'utf8'));
   throw result.error||Error(phase+' failed; preserve this output directory');
 }
}
const experiment=JSON.parse(fs.readFileSync(path.join(out,'experiment-summary.json')));
const restart=JSON.parse(fs.readFileSync(path.join(out,'restart-summary.json')));
write(path.join(out,'run-summary.json'),{status:'passed',started_at_utc:start,finished_at_utc:new Date().toISOString(),node:process.version,platform:process.platform,arch:process.arch,source_commit:COMMIT,network_mode:'No fork or live network. Ganache only; fetch disabled in both execution workers.',experiment,restart});
console.log('PASS complete study:',experiment.focused_cases,'focused cases,',experiment.seeded_operations,'seeded operations, and separate-process restart.');
console.log('Output:',path.relative(ROOT,out));
