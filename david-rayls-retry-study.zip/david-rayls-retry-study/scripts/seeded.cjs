'use strict';
const assert=require('node:assert/strict');
const path=require('node:path');
const {write}=require('./common.cjs');
const {makeFixture,serializeFixture,dispatch,deliver}=require('./fixtures.cjs');

function random32(seed) {
 let state=seed>>>0;
 return ()=>{state=(Math.imul(1664525,state)+1013904223)>>>0;return state;};
}
async function seeded(h,seed,operations=60) {
 const next=random32(seed), label='seed-'+seed;
 const f=await makeFixture(h,label);h.manager=f.manager;
 const model={A:{total:0n,calls:0n},B:{total:0n,calls:0n}};
 const issued=[],steps=[];let expectedOutbound=0;
 const countByAction={};
 const choose=items=>items[next()%items.length];
 const pending=()=>issued.filter(x=>!x.delivered);
 const done=()=>issued.filter(x=>x.delivered);
 async function create(name,forcedTarget) {
   const key=forcedTarget||((next()&1)?'A':'B'),units=1+(next()%19);
   const m=await dispatch(h,f,units,key==='A'?f.a:f.b,name);
   expectedOutbound++;assert.equal(m.message.messageMetadata.nonce,String(expectedOutbound));
   assert.ok(!issued.some(x=>x.message.id===m.id),'Duplicate generated ID in one sequence');
   const item={message:m,key,units:BigInt(units),delivered:false};issued.push(item);return item;
 }
 async function commit(item,name) {
   const rec=await deliver(h,f,item.message,name);
   assert.equal(rec.receipt.status,'0x1');
   if(item.delivered)throw Error('Oracle attempted a second successful delivery');
   item.delivered=true;model[item.key].total+=item.units;model[item.key].calls++;
 }
 async function stateMatches(name) {
   const state=await h.snapshot(f,issued.map(x=>x.message.id));
   for(const key of ['A','B']) {
     assert.equal(state.targets[key].total,model[key].total.toString(),name+' target total');
     assert.equal(state.targets[key].calls,model[key].calls.toString(),name+' target call count');
     assert.equal(state.targets[key].fails,false);
   }
   for(const item of issued)assert.equal(state.executed[item.message.id],item.delivered,name+' consumed-ID mismatch');
   assert.equal(state.nonces['10101'],'0',name+' unexpected ordering counter movement');
   assert.equal(state.outbound.single,String(expectedOutbound));
   return state;
 }
 for(let i=0;i<operations;i++) {
   let kind=next()%10;
   if(kind===4&&!done().length)kind=0;
   const op='S'+seed+'-'+String(i+1).padStart(3,'0');
   const start=h.records.length;
   let item,action;
   if(kind===0||kind===1) {
     action='new-source-submission-and-delivery';item=await create(op);await commit(item,op+'-deliver');
   } else if(kind===2) {
     action='new-source-submission-left-pending';item=await create(op);
   } else if(kind===3||kind===9) {
     action='deliver-a-pending-message';item=pending().length?choose(pending()):await create(op);await commit(item,op+'-deliver-pending');
   } else if(kind===4) {
     action='replay-successful-id';item=choose(done());await deliver(h,f,item.message,op+'-replay','MessageIdAlreadyExecuted');
   } else if(kind===5) {
     action='controlled-target-failure';item=await create(op,'B');
     await h.send(f.b,'setFailure',[true],h.admin,op+'-enable-failure');
     const rec=await deliver(h,f,item.message,op+'-failed','MessageFailure');assert.equal(rec.revert.inner.name,'ControlledTargetFailure');
     await h.send(f.b,'setFailure',[false],h.admin,op+'-remove-failure');
   } else if(kind===6) {
     action='unauthorized-delivery';item=pending().length?choose(pending()):await create(op);
     await deliver(h,f,item.message,op+'-unauthorized','RaylsAccessManaged__Unauthorized',h.outsider);
   } else if(kind===7) {
     action='temporary-executor-role-revocation';item=pending().length?choose(pending()):await create(op);
     await h.send(f.manager,'revokeRole',[f.roles.executorRole,f.receiver.address],h.admin,op+'-revoke');
     await deliver(h,f,item.message,op+'-role-denied','RaylsAccessManaged__Unauthorized');
     await h.send(f.manager,'grantRole',[f.roles.executorRole,f.receiver.address,0],h.admin,op+'-restore');
   } else if(kind===8) {
     action='temporary-executor-pause';item=pending().length?choose(pending()):await create(op);
     await h.send(f.manager,'setContractPaused',[f.executor.address,true],h.admin,op+'-pause');
     await deliver(h,f,item.message,op+'-paused','RaylsAccessManaged__ContractPaused');
     await h.send(f.manager,'setContractPaused',[f.executor.address,false],h.admin,op+'-unpause');
   }
   countByAction[action]=(countByAction[action]||0)+1;
   const state=await stateMatches(op);
   const record={operation:i+1,action,message_id:item.message.id,status:'passed',state,transactions:h.records.slice(start)};
   write(path.join(h.out,'seeded',label,op+'.json'),record);steps.push({operation:i+1,action,message_id:item.message.id,status:'passed'});
 }
 const drain=[];
 for(const item of pending()) {await commit(item,label+'-drain-'+item.message.message.messageMetadata.nonce);drain.push(item.message.id);}
 const finalState=await stateMatches(label+'-final');
 const summary={seed,operations,status:'passed',fixture:serializeFixture(f),actions:countByAction,issued_messages:issued.length,delivered_unique_messages:issued.filter(x=>x.delivered).length,final_state:finalState,drained_ids:drain,steps,messages:issued.map(x=>({message:x.message,key:x.key,units:x.units.toString(),delivered:x.delivered})),scope:'One fresh local contract fixture and deterministic action sequence; synthetic application and permissive registry fixtures; no live transport.'};
 write(path.join(h.out,'seeded',label,'summary.json'),summary);
 console.log('PASS seeded sequence',seed,operations,'operations',issued.length,'unique source messages');
 return summary;
}
module.exports={seeded};
