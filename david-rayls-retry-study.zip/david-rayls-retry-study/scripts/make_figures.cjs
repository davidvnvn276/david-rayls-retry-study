'use strict';
// Optional DAVID artwork regeneration. Evidence execution does not need Python,
// Pillow, Nimbus fonts or sharp; supplied PNG/SVG files can be inspected directly.
const path = require('node:path');
const cp = require('node:child_process');
const root = path.resolve(__dirname, '..');
const python = process.env.PYTHON || (process.platform === 'win32' ? 'python' : 'python3');
for (const [command, args] of [[python, [path.join(root, 'review/build_david_figures.py')]], [process.execPath, [path.join(root, 'review/render_figures.cjs')]]]) {
  const result = cp.spawnSync(command, args, { cwd: root, stdio: 'inherit' });
  if (result.error || result.status !== 0) throw result.error || Error('Optional artwork export failed; see README section 9.');
}
