'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const {ethers}=require('ethers');
const {ROOT,write}=require('./common.cjs');
const args=process.argv.slice(2);if(args.length!==1)throw Error('Usage: node scripts/verify_deployments.cjs evidence/run-01');
const out=path.resolve(ROOT,args[0]);
const read=f=>JSON.parse(fs.readFileSync(path.join(out,f)));
const compiled=read('compiled-contracts.json');
const deployments=read('deployments-experiment.json');
const byKey=new Map(deployments.map(d=>[d.file+':'+d.name,d]));
const records=new Map(read('transaction-index-experiment.json').map(x=>[x.hash,read(x.file)]));
const runtimeReads=new Map();
for(const line of fs.readFileSync(path.join(out,'rpc-experiment.jsonl'),'utf8').split('\n'))if(line){
 const x=JSON.parse(line);
 if(x.method==='eth_getCode'&&typeof x.result==='string'&&x.result!=='0x'&&!runtimeReads.has(x.params[0].toLowerCase()))runtimeReads.set(x.params[0].toLowerCase(),x.result);
}
function link(code,references){
 for(const [file,libs] of Object.entries(references||{}))for(const [name,refs] of Object.entries(libs)){
   const d=byKey.get(file+':'+name);assert.ok(d,'Missing linked library deployment');
   for(const ref of refs)code=code.slice(0,ref.start*2)+d.address.slice(2)+code.slice((ref.start+ref.length)*2);
 }
 return code.toLowerCase();
}
const checks=[];
for(const d of deployments){
 const a=compiled[d.file][d.name],r=records.get(d.transaction);assert.ok(r);
 const creation=link(a.evm.bytecode.object,a.evm.bytecode.linkReferences);
 const args=new ethers.Interface(a.abi).encodeDeploy(d.constructor_args);
 assert.equal(r.input.data.toLowerCase(),'0x'+creation+args.slice(2).toLowerCase(),d.label+' creation input mismatch');
 assert.equal(r.receipt.contractAddress.toLowerCase(),d.address.toLowerCase());
 const runtime=runtimeReads.get(d.address.toLowerCase());assert.ok(runtime);
 assert.equal(ethers.keccak256(runtime),d.runtime_keccak256);assert.equal((runtime.length-2)/2,d.runtime_bytes);
 let expected=link(a.evm.deployedBytecode.object,a.evm.deployedBytecode.linkReferences),actual=runtime.slice(2).toLowerCase();
 assert.equal(actual.length,expected.length,d.label+' runtime length');
 let librarySelfGuard=false;
 if(expected.startsWith('73'+'0'.repeat(40))){
   assert.equal(actual.slice(2,42),d.address.slice(2).toLowerCase(),d.label+' library self guard');
   expected=expected.slice(0,2)+d.address.slice(2).toLowerCase()+expected.slice(42);librarySelfGuard=true;
 }
 const immutableRanges=Object.values(a.evm.deployedBytecode.immutableReferences||{}).flat();
 for(const ref of immutableRanges){
   expected=expected.slice(0,ref.start*2)+'0'.repeat(ref.length*2)+expected.slice((ref.start+ref.length)*2);
   actual=actual.slice(0,ref.start*2)+'0'.repeat(ref.length*2)+actual.slice((ref.start+ref.length)*2);
 }
 assert.equal(actual,expected,d.label+' fixed runtime bytes mismatch');
 checks.push({label:d.label,address:d.address,file:d.file,name:d.name,creation_input_matches:true,fixed_runtime_bytes_match:true,declared_immutable_ranges_masked:immutableRanges,library_self_address_guard_verified:librarySelfGuard});
}
write(path.join(out,'deployment-verification.json'),{status:'passed',deployments_checked:checks.length,scope:'Deployment input bytes and recorded local runtime reads matched against this compiler output. Only compiler-declared runtime immutable ranges are masked; constructor bytes and linked library addresses are checked. Not a production bytecode mapping or independent compiler implementation.',checks});
console.log('PASS deployment creation inputs, library addresses and fixed runtime bytes:',checks.length,'deployments');
