'use strict';
const fs=require('node:fs');
const path=require('node:path');
const assert=require('node:assert/strict');
const {ROOT,sha256,verifyVendor}=require('./common.cjs');
const lines=fs.readFileSync(path.join(ROOT,'SHA256SUMS.txt'),'utf8').trim().split('\n');
let checked=0;
for(const line of lines){
 const match=/^([0-9a-f]{64})  (.+)$/.exec(line);assert.ok(match,'Invalid manifest line');
 const file=path.resolve(ROOT,match[2]);assert.ok(file.startsWith(ROOT+path.sep),'Unsafe manifest path');
 assert.equal(sha256(fs.readFileSync(file)),match[1],'Manifest mismatch: '+match[2]);checked++;
}
console.log('PASS',checked,'distributed files match SHA-256 manifest');
console.log('PASS',verifyVendor(),'vendored Git blob identities match the pinned source inventory');
console.log('Scope: distributed-byte identity, not independent authentication of experiment results or a live chain.');
