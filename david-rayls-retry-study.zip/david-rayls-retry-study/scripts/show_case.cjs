'use strict';
const fs=require('node:fs');
const path=require('node:path');
const {ROOT}=require('./common.cjs');
const args=process.argv.slice(2);
if(args.length!==2)throw Error('Usage: node scripts/show_case.cjs evidence/run-01 F06 (or restart)');
const out=path.resolve(ROOT,args[0]);
const read=name=>JSON.parse(fs.readFileSync(path.join(out,name)));
if(args[1]==='restart') {
 const a=read('before-process-restart.json'),b=read('after-process-restart.json'),r=read('restart-summary.json');
 console.log('LOCAL DATABASE REOPENED IN A SEPARATE NODE PROCESS');
 console.log('Same last block:',a.block_hash===b.block_hash,a.block_hash);
 console.log('Same captured state:',JSON.stringify(a.state)===JSON.stringify(b.state));
 console.log('Same code hashes:',JSON.stringify(a.code)===JSON.stringify(b.code));
 console.log('Duplicate rejected:',r.duplicate_rejected);
 console.log('Fresh message succeeded:',r.fresh_message_succeeded);
 console.log('Scope:',r.scope);
 process.exit(0);
}
if(!/^F\d{2}$/.test(args[1]))throw Error('Choose a focused case F01 through F33');
const c=read('focused/'+args[1]+'.json');
console.log(c.key+': '+c.title);
console.log('SCOPE: '+c.scope);
console.log('APPLICATION COUNTERS (synthetic units, not money)');
for(const k of ['A','B'])console.log(k,'total',c.before.targets[k].total,'->',c.after.targets[k].total,'calls',c.before.targets[k].calls,'->',c.after.targets[k].calls);
console.log('Inbound nonce 10101:',c.before.nonces['10101'],'->',c.after.nonces['10101']);
const messages=read('source-and-controlled-messages.json');
for(const [id,after] of Object.entries(c.after.executed)) {
 console.log('ID:',id);console.log('executed:',c.before.executed[id],'->',after);
 const m=messages.find(x=>x.id===id);
 if(m)console.log('payload nonce:',m.message.messageMetadata.nonce,'ignoresNonce:',m.message.messageMetadata.ignoresNonce,'source:',m.provenance||'emitted by the source contract');
}
for(const tx of c.transactions) {
 const r=read(tx.file);
 console.log('TX:',r.label,r.receipt.transactionHash,'status',r.receipt.status,'raw logs',r.receipt.logs.length);
 if(r.revert)console.log('REVERT:',r.revert.name,r.revert.signature,r.revert.inner?'inner='+r.revert.inner.name:'');
}
const traceFile=path.join(out,'trace-summary.json');
if(fs.existsSync(traceFile)){
 const t=JSON.parse(fs.readFileSync(traceFile)).cases.find(x=>x.case===c.key);
 if(t){
   console.log('LOCAL OPCODE TRACE:',t.opcode_steps,'steps');
   console.log('Computed mapping slot:',t.computed_mapping_slot);
   console.log('Tentative SSTORE value(s):',t.tentative_consumed_writes.map(x=>BigInt(x.value).toString()).join(', '));
   console.log('Historical post-transaction consumed flag:',t.post_transaction_consumed);
   console.log('Raw trace file:',t.raw_trace);
 }
}
console.log('This is a readback of preserved executed records. It does not submit a new transaction.');
