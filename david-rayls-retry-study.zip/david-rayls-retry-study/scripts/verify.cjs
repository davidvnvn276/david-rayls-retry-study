'use strict';
// Separate reconciliation of saved raw records. It does not re-run the EVM or
// independently authenticate a chain, provider, compiler or source publisher.
const fs=require('node:fs');
const path=require('node:path');
const assert=require('node:assert/strict');
const {ethers}=require('ethers');
const {ROOT,COMMIT,FILES,write,sha256,verifyVendor}=require('./common.cjs');
const {toPlain}=require('./harness.cjs');
const zlib=require('node:zlib');
const args=process.argv.slice(2);
if(args.length!==1)throw Error('Usage: node scripts/verify.cjs evidence/run-01');
const out=path.resolve(ROOT,args[0]);
const read=file=>JSON.parse(fs.readFileSync(path.join(out,file)));
const summary=read('run-summary.json');assert.equal(summary.status,'passed');assert.equal(summary.source_commit,COMMIT);
const sourceFiles=verifyVendor();
const build=read('build-provenance.json'),input=read('solc-input.json'),contracts=read('compiled-contracts.json');
assert.equal(sha256(fs.readFileSync(path.join(out,'solc-input.json'))),build.input_sha256);
for(const [name,source] of Object.entries(input.sources))assert.equal(sha256(source.content),build.resolved_source_sha256[name]);
const endpointInterface=new ethers.Interface(contracts[FILES.endpoint].EndpointV1.abi);
const messageParam=endpointInterface.getEvent('MessageDispatched').inputs[4];
const coder=ethers.AbiCoder.defaultAbiCoder();
const effectTopic=ethers.id('EffectApplied(bytes32,uint256,address,uint256,uint256,uint256,address)');
const executedTopic=ethers.id('MessageIdExecuted(uint256,bytes32)');
const dispatchTopic=endpointInterface.getEvent('MessageDispatched').topicHash;
const batchTopic=endpointInterface.getEvent('MessageBatchDispatched').topicHash;
const fixtures=[summary.experiment.focused_fixture];
for(const x of summary.experiment.seeded)fixtures.push(read('seeded/seed-'+x.seed+'/summary.json').fixture);
const fixtureByEndpoint=new Map(fixtures.map(f=>[f.sourceEndpoint.address.toLowerCase(),f]));
const targetAddresses=new Set(fixtures.flatMap(f=>[f.a.address.toLowerCase(),f.b.address.toLowerCase()]));
const executors=new Set(fixtures.map(f=>f.executor.address.toLowerCase()));
const txRecords=[];
for(const phase of ['experiment','restart'])for(const entry of read('transaction-index-'+phase+'.json')) {
 const record=read(entry.file);assert.equal(record.label,entry.label);assert.equal(record.receipt.transactionHash,entry.hash);
 assert.equal(record.receipt.status,entry.status);assert.equal(record.mined.hash,entry.hash);
 assert.equal(record.mined.input,record.input.data);assert.equal(record.mined.from.toLowerCase(),record.input.from.toLowerCase());
 if(record.input.to)assert.equal(record.mined.to.toLowerCase(),record.input.to.toLowerCase());
 record.phase=phase;txRecords.push(record);
}
txRecords.sort((a,b)=>Number(BigInt(a.receipt.blockNumber)-BigInt(b.receipt.blockNumber))||Number(BigInt(a.receipt.transactionIndex)-BigInt(b.receipt.transactionIndex)));
const seenHashes=new Set();
const ledger=new Map(),consumed=new Map(),sourceMessages=new Map(),rawEffects=[];
let failedTransactions=0,successfulTransactions=0,defaultSenderMessages=0;
const failuresByName={};
function target(address) {address=address.toLowerCase();if(!ledger.has(address))ledger.set(address,{total:0n,calls:0n});return ledger.get(address);}
function addSource(f,from,to,data,id,moduleAddress,txHash) {
 const encoded=coder.encode([messageParam],[data]);
 const computed=ethers.keccak256(coder.encode(['address','uint256','address','uint256','address','bytes'],[moduleAddress,10101,from,20202,to,encoded]));
 assert.equal(computed,id,'Source ID recomputation mismatch');
 assert.equal(data.messageMetadata.ignoresNonce,true,'Unexpected sender flag');
 assert.ok(!sourceMessages.has(id),'Repeated per-message source ID in one run');
 sourceMessages.set(id,{id,from,to,data,source_module:moduleAddress,source_endpoint:f.sourceEndpoint.address,executor:f.executor.address,transaction_hash:txHash});defaultSenderMessages++;
}
function rawErrorCheck(record) {
 const r=record.revert;assert.ok(r&&/^0x[0-9a-f]+$/i.test(r.raw),'No raw revert bytes');
 const signatures={MessageIdAlreadyExecuted:'MessageIdAlreadyExecuted(bytes32)',MessageFailure:'MessageFailure(bytes32,bytes)',MessageBatchFailure:'MessageBatchFailure(bytes32,uint256,bytes)',MessageReceiver__WrongNonce:'MessageReceiver__WrongNonce(uint256,uint256)',MessageReceiver__UnauthorizedEndpoint:'MessageReceiver__UnauthorizedEndpoint(address)',RaylsAccessManaged__Unauthorized:'RaylsAccessManaged__Unauthorized(address)',RaylsAccessManaged__ContractPaused:'RaylsAccessManaged__ContractPaused()',Error:'Error(string)'};
 assert.ok(signatures[r.name],'Unknown failure category '+r.name);
 assert.equal(r.raw.slice(0,10),ethers.id(signatures[r.name]).slice(0,10));
 if(r.name==='MessageFailure') {
   const [id,inner]=coder.decode(['bytes32','bytes'],'0x'+r.raw.slice(10));assert.equal(id,r.args[0]);assert.equal(inner,r.args[1]);
   assert.equal(inner.slice(0,10),ethers.id('ControlledTargetFailure(uint256)').slice(0,10));
 }
 if(r.name==='MessageBatchFailure') {
   const [id,index,inner]=coder.decode(['bytes32','uint256','bytes'],'0x'+r.raw.slice(10));assert.equal(id,r.args[0]);assert.equal(index.toString(),r.args[1]);assert.equal(inner,r.args[2]);
 }
 failuresByName[r.name]=(failuresByName[r.name]||0)+1;
}
const phaseLedgers={};
for(const record of txRecords) {
 const receipt=record.receipt;assert.ok(!seenHashes.has(receipt.transactionHash),'Duplicate receipt');seenHashes.add(receipt.transactionHash);
 if(receipt.status==='0x0') {failedTransactions++;assert.equal(receipt.logs.length,0);rawErrorCheck(record);}
 else {successfulTransactions++;
   for(const log of receipt.logs) {
     assert.equal(log.transactionHash,receipt.transactionHash);assert.equal(log.blockHash,receipt.blockHash);
     const address=log.address.toLowerCase();
     if(log.topics[0]===effectTopic) {
       assert.ok(targetAddresses.has(address),'Effect from an unexpected application address');assert.equal(log.topics.length,2);
       const [chain,from,units,totalAfter,callsAfter,caller]=coder.decode(['uint256','address','uint256','uint256','uint256','address'],log.data);
       const s=target(address);s.total+=units;s.calls++;
       assert.equal(s.total,totalAfter,'Raw event total does not reconcile');assert.equal(s.calls,callsAfter,'Raw event calls do not reconcile');
       assert.ok(executors.has(caller.toLowerCase()),'Effect caller was not a fixture executor');
       rawEffects.push({message_id:log.topics[1],address,source_chain:chain.toString(),source_sender:from,units:units.toString(),total_after:totalAfter.toString(),calls_after:callsAfter.toString(),caller,transaction:receipt.transactionHash});
     } else if(log.topics[0]===executedTopic) {
       assert.ok(executors.has(address),'Execution event from unexpected address');assert.equal(log.topics.length,3);
       const key=address+':'+log.topics[2];assert.ok(!consumed.has(key),'Same executor successfully committed an ID twice');
       consumed.set(key,{message_id:log.topics[2],executor:address,source_chain:BigInt(log.topics[1]).toString(),transaction:receipt.transactionHash});
     } else if(log.topics[0]===dispatchTopic) {
       const f=fixtureByEndpoint.get(address);assert.ok(f,'Unexpected source endpoint');
       const event=endpointInterface.parseLog(log);
       const data=toPlain(messageParam,event.args.data);
       addSource(f,event.args.from,event.args.to,data,event.args.messageId,f.sender.address,receipt.transactionHash);
     } else if(log.topics[0]===batchTopic) {
       const f=fixtureByEndpoint.get(address);assert.ok(f);
       const event=endpointInterface.parseLog(log);
       const param=event.fragment.inputs[2];
       const messages=toPlain(param,event.args.messages);
       for(const m of messages)addSource(f,event.args.from,m.to,m.data,m.messageId,f.batchSender.address,receipt.transactionHash);
     }
   }
 }
 if(record.phase==='experiment')phaseLedgers.experiment=Object.fromEntries([...ledger].map(([a,s])=>[a,{total:s.total.toString(),calls:s.calls.toString()}]));
}
function compareTargets(f,state,book) {
 for(const key of ['A','B']) {
   const address=f[key.toLowerCase()].address.toLowerCase();const s=book[address]||{total:'0',calls:'0'};
   assert.equal(state.targets[key].total,s.total);assert.equal(state.targets[key].calls,s.calls);
 }
 for(const [id,value] of Object.entries(state.executed)) {
   // Restart capture is before the only new phase-2 message; the shared IDs are
   // unchanged by that new execution, so the final consumed set is valid here.
   assert.equal(consumed.has(f.executor.address.toLowerCase()+':'+id),value);
 }
}
const before=read('before-process-restart.json'),after=read('after-process-restart.json');
for(const field of ['block_number','block_hash','local_chain_id','state','code','executor_implementation_slot','consumed_storage'])assert.deepEqual(before[field],after[field]);
compareTargets(fixtures[0],before.state,phaseLedgers.experiment);
const finalLedger=Object.fromEntries([...ledger].map(([a,s])=>[a,{total:s.total.toString(),calls:s.calls.toString()}]));
compareTargets(fixtures[0],summary.restart.final_state,finalLedger);
for(const seed of summary.experiment.seeded) {
 const result=read('seeded/seed-'+seed.seed+'/summary.json');assert.equal(result.status,'passed');assert.equal(result.operations,60);
 compareTargets(result.fixture,result.final_state,phaseLedgers.experiment);
 assert.equal(result.final_state.nonces['10101'],'0');
 for(const item of result.messages) {
   assert.equal(item.delivered,true);assert.ok(sourceMessages.has(item.message.id));
   assert.ok(consumed.has(result.fixture.executor.address.toLowerCase()+':'+item.message.id));
 }
}
const layout=contracts[FILES.executor].RaylsMessageExecutorV1.storageLayout;
const base=layout.storage.find(x=>x.label==='executed').slot;
for(const [id,x] of Object.entries(before.consumed_storage)) {
 assert.equal(x.mapping_base_slot,base);
 assert.equal(x.slot,ethers.keccak256(coder.encode(['bytes32','uint256'],[id,base])));
 // Ganache can represent an all-zero storage word as the empty data string 0x.
 assert.equal(BigInt(!x.value||x.value==='0x'?'0x0':x.value)!==0n,before.state.executed[id]);
}
const focused=read('focused-index.json');assert.equal(focused.length,33);
for(const index of focused) {
 const c=read(index.file);assert.equal(c.status,'passed');
 const transactions=c.transactions.map(t=>read(t.file));
 const effects=transactions.flatMap(t=>t.receipt.logs).filter(l=>l.topics[0]===effectTopic);
 const deltas={};
 for(const log of effects) {
   const [,,units]=coder.decode(['uint256','address','uint256','uint256','uint256','address'],log.data);
   const address=log.address.toLowerCase();deltas[address]||(deltas[address]={units:0n,calls:0n});deltas[address].units+=units;deltas[address].calls++;
 }
 for(const key of ['A','B']) {
   const address=fixtures[0][key.toLowerCase()].address.toLowerCase(),d=deltas[address]||{units:0n,calls:0n};
   assert.equal(BigInt(c.after.targets[key].total)-BigInt(c.before.targets[key].total),d.units,index.key+' raw-log units');
   assert.equal(BigInt(c.after.targets[key].calls)-BigInt(c.before.targets[key].calls),d.calls,index.key+' raw-log calls');
 }
}
const traceSummary=read('trace-summary.json');assert.equal(traceSummary.status,'passed');assert.equal(traceSummary.last_block_unchanged,true);
const traceChecks=[];
for(const traceCase of traceSummary.cases){
 const saved=JSON.parse(zlib.gunzipSync(fs.readFileSync(path.join(out,traceCase.raw_trace))));
 assert.equal(saved.method,'debug_traceTransaction');assert.equal(saved.params[0],traceCase.transaction_hash);
 const rows=saved.result.structLogs;assert.equal(rows.length,traceCase.opcode_steps);
 const c=read('focused/'+traceCase.case+'.json');
 assert.equal(c.after.executed[traceCase.message_id],traceCase.post_transaction_consumed);
 assert.equal(traceCase.computed_mapping_slot,ethers.keccak256(coder.encode(['bytes32','uint256'],[traceCase.message_id,base])));
 assert.ok(traceCase.tentative_consumed_writes.length);
 for(const w of traceCase.tentative_consumed_writes){
   const row=rows[w.step];assert.equal(row.op,'SSTORE');assert.equal(row.pc,w.pc);assert.equal(row.depth,w.depth);
   assert.equal('0x'+row.stack.at(-1).replace(/^0x/,''),traceCase.computed_mapping_slot);
   assert.equal(BigInt('0x'+row.stack.at(-2).replace(/^0x/,'')),1n);
 }
 assert.equal(rows.filter(x=>x.op==='REVERT').length,traceCase.revert_opcodes.length);
 assert.equal(rows.filter(x=>/^LOG[0-4]$/.test(x.op)).length,traceCase.log_opcodes.length);
 assert.equal(BigInt(traceCase.post_transaction_storage_word==='0x'?'0x0':traceCase.post_transaction_storage_word)!==0n,traceCase.post_transaction_consumed);
 const record=txRecords.find(x=>x.receipt.transactionHash===traceCase.transaction_hash);assert.ok(record);assert.equal(record.receipt.status,traceCase.receipt_status);assert.equal(record.receipt.logs.length,traceCase.receipt_logs);
 traceChecks.push({case:traceCase.case,opcode_steps:rows.length,tentative_write_one_verified:true,post_transaction_consumed:traceCase.post_transaction_consumed,log_opcodes:traceCase.log_opcodes.length,receipt_logs:record.receipt.logs.length});
}
assert.equal(traceChecks.length,3);
const rpcReverts=[];
for(const phase of ['experiment','restart']) {
 for(const line of fs.readFileSync(path.join(out,'rpc-'+phase+'.jsonl'),'utf8').split('\n'))if(line) {
   const row=JSON.parse(line);
   if(row.method==='eth_call'&&row.error)rpcReverts.push(row);
   assert.ok(!['eth_sendRawTransaction'].includes(row.method),'Unexpected external transaction submission method');
 }
}
for(const record of txRecords.filter(x=>x.receipt.status==='0x0')) {
 const parent=ethers.toQuantity(BigInt(record.receipt.blockNumber)-1n);
 assert.ok(rpcReverts.some(x=>x.params[1]===parent&&x.params[0].data===record.input.data&&x.params[0].to?.toLowerCase()===record.input.to?.toLowerCase()&&(typeof x.error.data==='string'?x.error.data:x.error.data?.result)===record.revert.raw),'No matching preserved parent-state simulation for revert bytes');
}
const core={
 first:read('focused/F01.json').after.targets.A,
 after_same_id_replay:read('focused/F02.json').after.targets.A,
 after_new_source_submission:read('focused/F04.json').after.targets.A,
 out_of_order_source_nonces:read('focused/F05.json').detail.source_nonces,
 inbound_nonce_after_out_of_order:read('focused/F05.json').after.nonces['10101'],
 failed_id_consumed:read('focused/F06.json').after.executed,
 later_message_progress:read('focused/F07.json').after,
 recovered:read('focused/F08.json').after.targets.B
};
const report={status:'passed',scope:'Separate raw-record reconciliation, not another EVM experiment or independent consensus authentication.',source_commit:COMMIT,source_git_blobs_checked:sourceFiles,transactions:txRecords.length,successful_transactions:successfulTransactions,failed_transactions:failedTransactions,failure_categories:failuresByName,raw_effect_events:rawEffects.length,unique_committed_executor_ids:consumed.size,source_generated_messages:defaultSenderMessages,all_source_ids_recomputed:true,all_source_emitted_flags_true:true,raw_effects_reconcile_to_getters:true,no_duplicate_commit_per_executor_id:true,focused_cases:focused.length,seeded_sequences:summary.experiment.seeded_sequences,seeded_operations:summary.experiment.seeded_operations,separate_process_restart_reconciled:true,mapping_storage_slots_reconciled:true,opcode_trace_checks:traceChecks,core};
write(path.join(out,'saved-record-verification.json'),report);
write(path.join(out,'derived-source-messages.json'),[...sourceMessages.values()]);
write(path.join(out,'derived-effects.json'),rawEffects);
console.log('PASS raw receipts, event totals, source IDs, revert bytes, storage slots and process-restart state.');
console.log(JSON.stringify({transactions:report.transactions,effects:report.raw_effect_events,source_messages:report.source_generated_messages,committed_ids:report.unique_committed_executor_ids,focused_cases:report.focused_cases,seeded_operations:report.seeded_operations}));
