"""Render the authored Markdown into a self-contained reading/copying document.
Standard library only. This is not a new experiment or generated screenshot.
"""
from pathlib import Path
import base64
import html
import re

ROOT = Path(__file__).resolve().parents[1]
source = (ROOT / 'ARTICLE.md').read_text(encoding='utf-8')

def inline(text):
    text = html.escape(text)
    text = re.sub(r'`([^`]+)`', r'<code>\1</code>', text)
    text = re.sub(r'\*\*([^*]+)\*\*', r'<strong>\1</strong>', text)
    text = re.sub(r'\[([^\]]+)\]\(([^)]+)\)', r'<a href="\2">\1</a>', text)
    return text

def figure(name, caption):
    data = base64.b64encode((ROOT / 'figures' / name).read_bytes()).decode()
    return f'<figure><img src="data:image/png;base64,{data}" alt="{html.escape(caption)}"><figcaption>{html.escape(caption)}</figcaption></figure>'

lines = source.splitlines()
blocks = []
i = 0
while i < len(lines):
    line = lines[i]
    if not line.strip():
        i += 1
        continue
    heading = re.match(r'^(#{1,6}) (.+)$', line)
    if heading:
        level, text = len(heading[1]), heading[2]
        if text == 'The nonce existed, but ordering was conditional':
            blocks.append(figure('02-measured-outcomes.png', 'Measured receipt, counter and consumed-ID outcomes from the focused local sequence.'))
        if text == 'Recovery and persistence received separate checks':
            blocks.append(figure('03-ordering-policy.png', 'Source-emitted metadata and conditional strict-mode controls are separate evidence.'))
        ident = re.sub(r'[^a-z0-9]+', '-', text.lower()).strip('-')
        blocks.append(f'<h{level} id="{ident}">{inline(text)}</h{level}>')
        if level == 1:
            blocks.append(figure('01-retry-banner.png', 'Local public-code study: message identity, recovery and replay.'))
        i += 1
    elif line.startswith('|'):
        rows = []
        while i < len(lines) and lines[i].startswith('|'):
            cells = [c.strip() for c in lines[i].strip('|').split('|')]
            if not all(re.fullmatch(r':?-+:?', c) for c in cells):
                rows.append(cells)
            i += 1
        header = '<tr>' + ''.join('<th>' + inline(x) + '</th>' for x in rows[0]) + '</tr>'
        body = ''.join('<tr>' + ''.join('<td>' + inline(x) + '</td>' for x in row) + '</tr>' for row in rows[1:])
        blocks.append('<div class="table-wrap"><table><thead>' + header + '</thead><tbody>' + body + '</tbody></table></div>')
    elif line.startswith('- '):
        items = []
        while i < len(lines) and lines[i].startswith('- '):
            items.append('<li>' + inline(lines[i][2:]) + '</li>')
            i += 1
        blocks.append('<ul>' + ''.join(items) + '</ul>')
    else:
        paragraph = [line]
        i += 1
        while i < len(lines) and lines[i].strip() and not re.match(r'^(#|\||- )', lines[i]):
            paragraph.append(lines[i])
            i += 1
        blocks.append('<p>' + inline(' '.join(paragraph)) + '</p>')

body = '\n'.join(blocks)
raw = base64.b64encode(source.encode()).decode()
document = '''<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Can a Cross-Chain Message Be Retried Safely? | DAVID</title>
<meta name="description" content="A reproducible local study of Rayls message IDs, retry, optional ordering and execution-state persistence.">
<style>
:root{color-scheme:light;--ink:#14243b;--muted:#536378;--line:#dde3ea}
*{box-sizing:border-box}body{margin:0;background:#f1f4f7;color:var(--ink);font:18px/1.65 system-ui,-apple-system,Segoe UI,sans-serif}
.toolbar{max-width:1080px;margin:24px auto;padding:0 32px;display:flex;gap:10px;align-items:center;flex-wrap:wrap}.toolbar span{margin-right:auto;color:var(--muted);font-size:14px}
button{border:1px solid var(--ink);background:white;color:var(--ink);padding:10px 16px;border-radius:8px;font:600 14px system-ui;cursor:pointer}button:first-of-type{background:var(--ink);color:white}
.notice{max-width:1016px;margin:0 auto 22px;padding:15px 20px;border-left:4px solid #d3e853;background:white;font-size:14px;color:var(--muted)}
article{max-width:1080px;margin:0 auto 50px;background:white;padding:56px 64px 64px;border:1px solid var(--line);border-radius:14px}
h1{font-size:42px;line-height:1.18;letter-spacing:-1.1px;margin:0 0 28px}h2{font-size:28px;line-height:1.25;margin:40px 0 18px;letter-spacing:-.4px}p{margin:0 0 18px}a{color:#205a97;text-decoration-thickness:1px;text-underline-offset:3px}
code{font:85% ui-monospace,SFMono-Regular,Consolas,monospace;background:#eef2f6;border-radius:4px;padding:2px 5px;overflow-wrap:anywhere}strong{font-weight:680}
figure{margin:28px -20px 32px}figure img{width:100%;height:auto;display:block;border:1px solid var(--line);border-radius:8px}figcaption{font-size:13px;color:var(--muted);margin:8px 2px 0}
.table-wrap{overflow-x:auto;margin:24px 0}table{border-collapse:collapse;width:100%;font-size:16px}th,td{border-bottom:1px solid var(--line);padding:12px 15px;text-align:left}th{background:#edf1f6}ul{padding-left:24px}li{margin:8px 0}
#status{font-size:13px;color:#176c5b;min-height:24px;max-width:1016px;margin:0 auto 8px}
@media(max-width:700px){body{font-size:17px}article{padding:28px 22px;border-radius:0}h1{font-size:31px}h2{font-size:24px}figure{margin:24px -10px}.notice{margin:0 15px 20px}.toolbar{padding:0 18px}}
@media print{body{background:white}.toolbar,.notice,#status{display:none}article{padding:0;border:0;margin:0;max-width:none}h1{font-size:30px}h2{font-size:22px}figure,table{break-inside:avoid}a{color:inherit}}
</style></head><body>
<div class="toolbar"><span>DAVID · English reading copy</span><button onclick="copyFormatted()">Copy formatted text</button><button onclick="copyMarkdown()">Copy Markdown</button><button onclick="window.print()">Print / PDF</button></div>
<div class="notice">Before publication: upload the accompanying evidence package to a real public URL and add that link to the final reproducibility paragraph. Images are supplied separately for your platform editor.</div><div id="status" role="status"></div>
<article id="article">''' + body + '''</article>
<script>
const markdown=new TextDecoder().decode(Uint8Array.from(atob("''' + raw + '''"),c=>c.charCodeAt(0)));
async function copyMarkdown(){try{await navigator.clipboard.writeText(markdown);document.getElementById('status').textContent='Markdown copied.';}catch{fallback(markdown);}}
async function copyFormatted(){
 const clone=document.getElementById('article').cloneNode(true);clone.querySelectorAll('figure').forEach(x=>x.remove());
 const html='<html><body>'+clone.innerHTML+'</body></html>';
 try{await navigator.clipboard.write([new ClipboardItem({'text/html':new Blob([html],{type:'text/html'}),'text/plain':new Blob([clone.textContent],{type:'text/plain'})})]);document.getElementById('status').textContent='Formatted article text copied. Insert images separately.';}
 catch{
 const holder=document.createElement('div');holder.innerHTML=clone.innerHTML;
 holder.style.cssText='position:fixed;left:-10000px;top:0;width:900px;background:white;color:black';document.body.appendChild(holder);
 const range=document.createRange();range.selectNodeContents(holder);const sel=window.getSelection();sel.removeAllRanges();sel.addRange(range);
 let copied=false;try{copied=document.execCommand('copy');}catch{}
 holder.remove();sel.removeAllRanges();
 if(copied)document.getElementById('status').textContent='Formatted article text copied. Insert images separately.';else fallback(markdown);
}
}
function fallback(text){const el=document.createElement('textarea');el.value=text;document.body.appendChild(el);el.select();document.execCommand('copy');el.remove();document.getElementById('status').textContent='Markdown copied.';}
</script></body></html>'''
(ROOT / 'ARTICLE.html').write_text(document, encoding='utf-8')
print('Created self-contained ARTICLE.html with the three measured-data figures.')
