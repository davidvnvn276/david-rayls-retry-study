'use strict';
const fs=require('node:fs');
const path=require('node:path');
const assert=require('node:assert/strict');
const {ethers}=require('ethers');
const {FILES,write,stringify,sha256}=require('./common.cjs');
const GAS='0x1c9c380';
const IMPLEMENTATION_SLOT='0x360894a13ba1a3210667c828492db98dca3e2076cc3735a920a3ca505d382bbc';
function toPlain(param,value) {
  if(param.baseType==='array') return Array.from(value,x=>toPlain(param.arrayChildren,x));
  if(param.baseType==='tuple') return Object.fromEntries(param.components.map((x,i)=>[x.name||String(i),toPlain(x,value[i])]));
  return typeof value==='bigint'?value.toString():value;
}
function eventPlain(parsed) {
 return {name:parsed.name,signature:parsed.signature,args:Object.fromEntries(parsed.fragment.inputs.map((p,i)=>[p.name||String(i),toPlain(p,parsed.args[i])]))};
}
function errorPlain(parsed,raw) {
 return {name:parsed.name,signature:parsed.signature,args:Array.from(parsed.args,x=>typeof x==='bigint'?x.toString():x),raw};
}
class Harness {
 constructor(provider,contracts,out,phase) {
   this.provider=provider; this.contracts=contracts; this.out=out; this.phase=phase;
   this.txIndex=0; this.records=[]; this.libraries=new Map(); this.deployments=[];
   this.addresses=new Map(); this.interfaces=[]; this.rpcCounts={};
   this.journal=path.join(out,'rpc-'+phase+'.jsonl');
   this.standardError=new ethers.Interface(['error Error(string)','error Panic(uint256)']);
 }
 async rpc(method,params=[]) {
   this.rpcCounts[method]=(this.rpcCounts[method]||0)+1;
   try {const result=await this.provider.request({method,params});
     fs.appendFileSync(this.journal,JSON.stringify({method,params,result})+'\n'); return result;
   } catch(error) {
     fs.appendFileSync(this.journal,JSON.stringify({method,params,error:{message:error.message,code:error.code,data:error.data}})+'\n'); throw error;
   }
 }
 handle(file,name,address) {
   const abi=this.contracts[file][name].abi;
   const handle={file,name,address,interface:new ethers.Interface(abi)};
   this.addresses.set(address.toLowerCase(),handle); this.interfaces.push(handle.interface); return handle;
 }
 decodeError(raw) {
   if(typeof raw!=='string'||!raw.startsWith('0x')) return {name:'Unavailable',raw};
   for(const iface of [...this.interfaces,this.standardError]) {
     try {const decoded=iface.parseError(raw); if(decoded) {
       const result=errorPlain(decoded,raw);
       if(['MessageFailure','MessageBatchFailure'].includes(result.name)) result.inner=this.decodeError(result.args[result.args.length-1]);
       return result;
     }}catch{}
   }
   return {name:'Unknown',raw};
 }
 decodeLogs(receipt) {
   return receipt.logs.map(log=>{
     const h=this.addresses.get(log.address.toLowerCase());
     const ifaces=h?[h.interface]:this.interfaces;
     for(const iface of ifaces) {try {const p=iface.parseLog(log); if(p)return {...eventPlain(p),address:log.address,logIndex:log.logIndex};}catch{}}
     return {name:'Undecoded',address:log.address,topics:log.topics,data:log.data,logIndex:log.logIndex};
   });
 }
 async tx(label,request,expected='success') {
   const input={gas:GAS,value:'0x0',...request};
   const hash=await this.rpc('eth_sendTransaction',[input]);
   const receipt=await this.rpc('eth_getTransactionReceipt',[hash]);
   assert.ok(receipt,'Missing mined receipt');
   const mined=await this.rpc('eth_getTransactionByHash',[hash]);
   const record={index:++this.txIndex,label,input,receipt,mined,decoded_logs:this.decodeLogs(receipt)};
   if(receipt.status==='0x0') {
     const parent=ethers.toQuantity(BigInt(receipt.blockNumber)-1n);
     try {await this.rpc('eth_call',[input,parent]); throw Error('Failed mined transaction unexpectedly simulated successfully');}
     catch(error) {
       const raw=typeof error.data==='string'?error.data:error.data?.result;
       record.revert=this.decodeError(raw);
       if(record.revert.name==='Unavailable') throw Error('Could not preserve revert bytes: '+label+' '+error.message);
     }
   }
   const file=String(this.txIndex).padStart(5,'0')+'-'+label.replace(/[^a-zA-Z0-9-]+/g,'-').slice(0,90)+'.json';
   write(path.join(this.out,'transactions-'+this.phase,file),record);
   this.records.push({file:'transactions-'+this.phase+'/'+file,label,status:receipt.status,revert:record.revert?.name,hash});
   if(expected==='success') assert.equal(receipt.status,'0x1',label+' reverted: '+JSON.stringify(record.revert));
   else {assert.equal(receipt.status,'0x0',label+' should revert'); assert.equal(record.revert.name,expected,label+' wrong revert');}
   return record;
 }
 async send(handle,fn,args,from,label,expected='success') {
   return this.tx(label,{from,to:handle.address,data:handle.interface.encodeFunctionData(fn,args)},expected);
 }
 async read(handle,fn,args=[],block='latest') {
   const raw=await this.rpc('eth_call',[{to:handle.address,data:handle.interface.encodeFunctionData(fn,args)},block]);
   const result=handle.interface.decodeFunctionResult(fn,raw); return result.length===1?result[0]:result;
 }
 async deploy(file,name,args=[],label=name) {
   const artifact=this.contracts[file][name];
   let bytecode=artifact.evm.bytecode.object;
   for(const [libFile,libs] of Object.entries(artifact.evm.bytecode.linkReferences||{})) for(const [libName,refs] of Object.entries(libs)) {
     const key=libFile+':'+libName;
     if(!this.libraries.has(key)) this.libraries.set(key,await this.deploy(libFile,libName));
     const address=this.libraries.get(key).address.slice(2);
     for(const ref of refs) bytecode=bytecode.slice(0,ref.start*2)+address+bytecode.slice((ref.start+ref.length)*2);
   }
   const factory=new ethers.ContractFactory(artifact.abi,bytecode);
   const request=await factory.getDeployTransaction(...args);
   const rec=await this.tx('deploy-'+label,{from:this.admin,data:request.data});
   const h=this.handle(file,name,rec.receipt.contractAddress);
   const runtime=await this.rpc('eth_getCode',[h.address,'latest']);
   this.deployments.push({label,file,name,address:h.address,constructor_args:args,runtime_keccak256:ethers.keccak256(runtime),runtime_bytes:(runtime.length-2)/2,transaction:rec.receipt.transactionHash});
   return h;
 }
 async proxy(file,name,args,label) {
   const impl=await this.deploy(file,name,[],label+'-implementation');
   const initializer=name==='RaylsMessageExecutorV1'?'initialize(address)':'initialize';
   const data=impl.interface.encodeFunctionData(initializer,args);
   const proxy=await this.deploy(FILES.proxy,'ERC1967Proxy',[impl.address,data],label+'-proxy');
   const handle=this.handle(file,name,proxy.address); handle.implementation=impl.address; return handle;
 }
 async role(name,targets,accounts) {
   const rec=await this.send(this.manager,'registerRole',[name],this.admin,'register-role-'+name);
   const role=rec.decoded_logs.find(x=>x.name==='RoleRegistered').args.roleId;
   for(const [target,functions] of targets) {
     const selectors=functions.map(fn=>target.interface.getFunction(fn).selector);
     await this.send(this.manager,'addFunctionAllowedRoles',[target.address,selectors,[role]],this.admin,'map-role-'+name+'-'+target.name);
   }
   for(const account of accounts) await this.send(this.manager,'grantRole',[role,account,0],this.admin,'grant-'+name);
   return role;
 }
 async snapshot(fixture,ids=[]) {
   const f=fixture;
   const nonces={};
   for(const source of [10101,30303,40404]) nonces[source]=(await this.read(f.receiver,'getInboundNonce',[source])).toString();
   const targets={};
   for(const [name,target] of Object.entries({A:f.a,B:f.b})) targets[name]={total:(await this.read(target,'total')).toString(),calls:(await this.read(target,'calls')).toString(),fails:await this.read(target,'fails')};
   const executed={}; for(const id of ids) executed[id]=await this.read(f.executor,'executed',[id]);
   const outbound={single:(await this.read(f.sender,'getOutboundNonce',[20202])).toString(),dispatch_batch:(await this.read(f.batchSender,'outboundNonce',[20202])).toString()};
   return {nonces,targets,executed,outbound};
 }
 async captureContractState(fixture,ids,label) {
   const block=await this.rpc('eth_getBlockByNumber',['latest',false]);
   const state=await this.snapshot(fixture,ids); const code={};
   for(const key of ['manager','endpoint','sourceEndpoint','receiver','resource','executor','sender','batchSender','a','b']) {
     const h=fixture[key]; const bytes=await this.rpc('eth_getCode',[h.address,'latest']);
     code[key]={address:h.address,keccak256:ethers.keccak256(bytes),bytes:(bytes.length-2)/2};
   }
   const slot=await this.rpc('eth_getStorageAt',[fixture.executor.address,IMPLEMENTATION_SLOT,'latest']);
   const layout=this.contracts[FILES.executor].RaylsMessageExecutorV1.storageLayout;
   const mappingSlot=layout.storage.find(x=>x.label==='executed').slot;
   const consumed_storage={};
   for(const id of ids) {
     const slotKey=ethers.keccak256(ethers.AbiCoder.defaultAbiCoder().encode(['bytes32','uint256'],[id,mappingSlot]));
     consumed_storage[id]={mapping_base_slot:mappingSlot,slot:slotKey,value:await this.rpc('eth_getStorageAt',[fixture.executor.address,slotKey,'latest'])};
   }
   const result={label,block_number:block.number,block_hash:block.hash,local_chain_id:await this.rpc('eth_chainId'),state,code,executor_implementation_slot:slot,consumed_storage};
   write(path.join(this.out,label+'.json'),result);return result;
 }
 save() {write(path.join(this.out,'transaction-index-'+this.phase+'.json'),this.records);write(path.join(this.out,'deployments-'+this.phase+'.json'),this.deployments);write(path.join(this.out,'rpc-counts-'+this.phase+'.json'),this.rpcCounts);}
}
function emptyMessage(nonce='1',ignoresNonce=true) {
 return {messageMetadata:{valid:true,nonce:String(nonce),newResourceMetadata:{valid:false,resourceDeployType:0,bytecode:'0x',factoryTemplate:0,initializerParams:'0x'},resourceId:ethers.ZeroHash,lockData:'0x',revertPayloadDataSender:'0x',revertPayloadDataReceiver:'0x',transferMetadata:{assetType:0,id:'0',from:ethers.ZeroAddress,to:ethers.ZeroAddress,tokenAddress:ethers.ZeroAddress,amount:'0'},ignoresNonce},payload:'0x'};
}
module.exports={Harness,FILES,IMPLEMENTATION_SLOT,toPlain,eventPlain,emptyMessage};
