'use strict';
const fs=require('node:fs');
const path=require('node:path');
const assert=require('node:assert/strict');
const {ethers}=require('ethers');
const {ROOT,COMMIT,FILES,write}=require('./common.cjs');
const {Harness}=require('./harness.cjs');
const {makeFixture,serializeFixture,restoreFixture,dispatch,deliver}=require('./fixtures.cjs');
const {focused}=require('./focused.cjs');
const {seeded}=require('./seeded.cjs');
const phase=process.argv[2],out=path.resolve(process.argv[3]);
if(!['experiment','restart'].includes(phase))throw Error('Unknown phase');
// The experiment has no upstream chain or transport endpoint. A fetch attempt is
// a hard error instead of a hidden live-state fallback.
global.fetch=async()=>{throw Error('Network access is disabled during local execution');};
const ganache=require('ganache');
const contracts=JSON.parse(fs.readFileSync(path.join(out,'compiled-contracts.json')));
const provider=ganache.provider({
 logging:{quiet:true},database:{dbPath:path.join(out,'local-chain-db')},
 wallet:{deterministic:true,totalAccounts:6,defaultBalance:1000},
 chain:{chainId:31337,networkId:31337,hardfork:'shanghai',time:new Date('2026-01-01T00:00:00Z')},
 miner:{blockGasLimit:'0x2625a00',timestampIncrement:1}
});
const h=new Harness(provider,contracts,out,phase);
async function main(){
 const accounts=await h.rpc('eth_accounts');
 [h.admin,h.deliverer,h.direct,h.origin,h.outsider]=accounts;
 assert.equal(await h.rpc('eth_chainId'),'0x7a69');
 if(phase==='experiment') {
   const fixture=await makeFixture(h,'focused');
   const result=await focused(h,fixture);
   const seededRuns=[];
   for(const seed of [1701,2909,4177])seededRuns.push(await seeded(h,seed,60));
   h.manager=fixture.manager;
   const before=await h.captureContractState(fixture,result.tracked_ids,'before-process-restart');
   write(path.join(out,'restart-input.json'),{fixture:serializeFixture(fixture),accounts,tracked_ids:result.tracked_ids,repeat_message:result.restart_message,unconsumed_message:result.unconsumed_message,expected:before});
   write(path.join(out,'experiment-summary.json'),{
     status:'passed',source_commit:COMMIT,physical_local_chain_id:31337,
     focused_cases:result.cases.length,seeded_sequences:seededRuns.length,seeded_operations:seededRuns.reduce((n,x)=>n+x.operations,0),
     seeded_unique_source_messages:seededRuns.reduce((n,x)=>n+x.issued_messages,0),
     focused_fixture:serializeFixture(fixture),seeded:seededRuns.map(({seed,operations,issued_messages,actions})=>({seed,operations,issued_messages,actions})),
     real_protocol_contracts:['EndpointV1','MessageSender','BatchMessageSender','MessageReceiver','ResourceManager','RaylsMessageExecutorV1','RaylsAccessManagerV1'],
     synthetic_components:['RecordingTarget','PermissiveValidationFixture','ReentryTarget','StudyExecutorV2'],
     transport:'Source events manually injected by a locally authorized deliverer into a destination Endpoint on the same Ganache chain',
     absent_components:['live relayer','Private Network Hub','Merkle/consensus proof verification','CTS encryption','live token registry or participant validation','mainnet state','real asset transfers'],
     automatic_factory_deployment_exercised:false,network_fallback:false,
     transaction_count_phase_1:h.records.length
   });
 }else{
   const info=JSON.parse(fs.readFileSync(path.join(out,'restart-input.json')));
   assert.deepEqual(accounts,info.accounts,'Fixture accounts changed across restart');
   const fixture=restoreFixture(h,info.fixture);
   const after=await h.captureContractState(fixture,info.tracked_ids,'after-process-restart');
   for(const field of ['block_number','block_hash','local_chain_id','state','code','executor_implementation_slot','consumed_storage'])assert.deepEqual(after[field],info.expected[field],'Restart mismatch: '+field);
   await deliver(h,fixture,info.repeat_message,'R01-replay-after-process-restart','MessageIdAlreadyExecuted');
   const fresh=await dispatch(h,fixture,23,fixture.a,'R02');
   const prior=await h.snapshot(fixture,[fresh.id]);
   const rec=await deliver(h,fixture,fresh,'R02-fresh-after-process-restart');
   const final=await h.snapshot(fixture,[fresh.id,...info.tracked_ids]);
   assert.equal(BigInt(final.targets.A.total)-BigInt(prior.targets.A.total),23n);
   assert.equal(final.executed[fresh.id],true);
   assert.equal(final.executed[info.unconsumed_message.id],false);
   write(path.join(out,'restart-summary.json'),{status:'passed',separate_node_process:true,identical_state_and_code_on_reopen:true,same_last_block_hash:true,duplicate_rejected:true,fresh_message_succeeded:true,source_generated_fresh_message:fresh,final_state:final,tracked_ids:info.tracked_ids,scope:'Local Ganache database reopened in a new Node process; not a relayer restart or network recovery test.'});
   console.log('PASS separate-process restart, replay rejection and fresh execution');
 }
 h.save();
}
main().catch(error=>{
 write(path.join(out,'failure-'+phase+'.json'),{message:error.message,stack:error.stack});
 h.save();console.error(error.stack);process.exitCode=1;
}).finally(async()=>{await provider.disconnect();});
