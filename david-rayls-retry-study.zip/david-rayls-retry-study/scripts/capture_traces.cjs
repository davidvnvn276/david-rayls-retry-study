'use strict';
const fs=require('node:fs'),path=require('node:path'),zlib=require('node:zlib');
const assert=require('node:assert/strict');
const {ethers}=require('ethers');
const {ROOT,FILES,write}=require('./common.cjs');
const args=process.argv.slice(2);if(args.length!==1)throw Error('Usage: node scripts/capture_traces.cjs runs/my-check-01');
const out=path.resolve(ROOT,args[0]);
if(!fs.existsSync(path.join(out,'local-chain-db','CURRENT')))throw Error('This run has no local database. Execute a fresh run before collecting traces. Supplied traces can be inspected without the database.');
global.fetch=async()=>{throw Error('No network fallback in trace capture');};
const ganache=require('ganache');
const provider=ganache.provider({logging:{quiet:true},database:{dbPath:path.join(out,'local-chain-db')},wallet:{deterministic:true,totalAccounts:6,defaultBalance:1000},chain:{chainId:31337,networkId:31337,hardfork:'shanghai'},miner:{blockGasLimit:'0x2625a00',timestampIncrement:1}});
async function main(){
 const input=JSON.parse(fs.readFileSync(path.join(out,'compiled-contracts.json')));
 const slot=input[FILES.executor].RaylsMessageExecutorV1.storageLayout.storage.find(x=>x.label==='executed').slot;
 const index=JSON.parse(fs.readFileSync(path.join(out,'transaction-index-experiment.json')));
 const summary=JSON.parse(fs.readFileSync(path.join(out,'experiment-summary.json')));
 const executor=summary.focused_fixture.executor.address;
 const cases=[['F01','F01-first-delivery',true],['F06','F06-failed-delivery',false],['F25','F25-executor-batch-failure',false]];
 const results=[];
 const before=await provider.request({method:'eth_getBlockByNumber',params:['latest',false]});
 for(const [key,label,expectedConsumed] of cases){
   const caseData=JSON.parse(fs.readFileSync(path.join(out,'focused',key+'.json')));
   const id=Object.keys(caseData.after.executed)[0];
   const entry=index.find(x=>x.label===label);assert.ok(entry);
   const record=JSON.parse(fs.readFileSync(path.join(out,entry.file)));
   const options={disableMemory:true,disableStack:false,disableStorage:true};
   const trace=await provider.request({method:'debug_traceTransaction',params:[entry.hash,options]});
   assert.ok(trace.structLogs?.length,'No opcode trace');
   const storageKey=ethers.keccak256(ethers.AbiCoder.defaultAbiCoder().encode(['bytes32','uint256'],[id,slot]));
   const writes=[],calls=[],reverts=[],logOps=[];
   for(let i=0;i<trace.structLogs.length;i++){
     const row=trace.structLogs[i],stack=row.stack||[];
     if(row.op==='SSTORE'&&stack.length>=2&&('0x'+stack.at(-1).replace(/^0x/,''))===storageKey){
       const value='0x'+stack.at(-2).replace(/^0x/,'');writes.push({step:i,pc:row.pc,depth:row.depth,slot:storageKey,value});
     }
     if(['CALL','DELEGATECALL','STATICCALL'].includes(row.op)&&stack.length>=2)calls.push({step:i,pc:row.pc,depth:row.depth,op:row.op,to:'0x'+stack.at(-2).replace(/^0x/,'').slice(-40)});
     if(row.op==='REVERT')reverts.push({step:i,pc:row.pc,depth:row.depth});
     if(/^LOG[0-4]$/.test(row.op))logOps.push({step:i,pc:row.pc,depth:row.depth,op:row.op});
   }
   assert.ok(writes.some(x=>BigInt(x.value)===1n),'No tentative consumed-ID write found');
   if(!expectedConsumed)assert.ok(reverts.length,'Failed receipt has no revert opcode');
   const block=record.receipt.blockNumber;
   const word=await provider.request({method:'eth_getStorageAt',params:[executor,storageKey,block]});
   assert.equal(BigInt(word==='0x'?'0x0':word)!==0n,expectedConsumed);
   const encoded=zlib.gzipSync(Buffer.from(JSON.stringify({method:'debug_traceTransaction',params:[entry.hash,options],result:trace})),{level:9});
   fs.mkdirSync(path.join(out,'traces'),{recursive:true});fs.writeFileSync(path.join(out,'traces',key+'.json.gz'),encoded);
   results.push({case:key,label,transaction_hash:entry.hash,receipt_status:record.receipt.status,message_id:id,computed_mapping_slot:storageKey,opcode_steps:trace.structLogs.length,tentative_consumed_writes:writes,revert_opcodes:reverts,log_opcodes:logOps,calls,receipt_logs:record.receipt.logs.length,post_transaction_storage_word:word,post_transaction_consumed:expectedConsumed,raw_trace:'traces/'+key+'.json.gz'});
   console.log('PASS opcode trace',key,'SSTORE=1 found; post-transaction consumed='+expectedConsumed,'steps='+trace.structLogs.length);
 }
 const after=await provider.request({method:'eth_getBlockByNumber',params:['latest',false]});assert.equal(before.hash,after.hash,'Tracing changed the chain');
 write(path.join(out,'trace-summary.json'),{status:'passed',captured_at_utc:new Date().toISOString(),scope:'Read-only opcode traces from the saved local Ganache chain. They are not mainnet traces, another empirical experiment or independent consensus authentication.',last_block_unchanged:true,cases:results});
}
main().catch(e=>{console.error(e.stack);process.exitCode=1;}).finally(async()=>provider.disconnect());
