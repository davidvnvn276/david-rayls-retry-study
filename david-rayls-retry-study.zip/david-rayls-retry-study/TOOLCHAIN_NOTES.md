# Toolchain and construction notes

Recorded runtime: Node v24.19.0, npm 11.9.0, Linux x64. Compiler: solc-js `0.8.24+commit.e11b9ed9`, optimizer 50 runs, Paris EVM target. Ganache 7.9.2 executes the compiled code with its Shanghai hardfork setting. The compiler target is a subset of that local EVM’s supported instructions; the experiment does not benchmark a Rayls ledger client.

## Optional fsevents lockfile metadata

The first `npm install --ignore-scripts --no-audit --no-fund` generated a lockfile that included Ganache’s bundled `node_modules/ganache/node_modules/fsevents` entry with `os: ["darwin"]` and `extraneous: true`, but no `optional` marker. A separate clean Linux `npm ci` failed with `EBADPLATFORM` for fsevents 2.3.2.

The distributed lockfile adds exactly one semantic field:

```text
packages["node_modules/ganache/node_modules/fsevents"].optional = true
```

No package version, download URL or integrity value was changed. The pre-edit generated lockfile is retained as `sources/package-lock.generated-before-optional-metadata-fix.json`. This is the study’s generated lockfile, not an original Rayls evidence artifact. The clean install check uses the corrected distribution file.

## Expected native warning

On the recorded Node version, Ganache’s native µWS binary was unavailable and Ganache fell back to JavaScript. The warning remains in the supplied stderr files. It did not prevent the experiment or restart checks from completing. Performance numbers should not be inferred from these runs.

## Harness construction corrections

During construction, a partial development attempt stopped when the harness supplied the internal `SendRequest[]` shape to the public Endpoint’s `sendBatch` wrapper. The actual Endpoint ABI accepts three-field `DestinationPayloadRequest[]` tuples. The harness was corrected to use that ABI. The incomplete development attempt is not one of the supplied complete experiment runs or part of the article’s counts.

The saved-record verifier also handles Ganache’s empty `0x` representation of an all-zero storage value when interpreting the sampled unconsumed mapping slot. The raw response remains unchanged.

## Limits

These local code executions do not establish a live deployment version, relayer timing, proof authenticity, real token eligibility, asset backing, distributed ordering or arbitrary upgrade safety. Source-byte checks, a manifest, a compiler run and repeated local results do not replace those missing observations.
