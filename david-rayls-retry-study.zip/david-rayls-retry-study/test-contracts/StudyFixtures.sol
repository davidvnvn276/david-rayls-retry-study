// SPDX-License-Identifier: MIT
pragma solidity 0.8.24;

import {RaylsMessageExecutorV1} from "vendor/rayls-contracts/src/rayls-protocol/RaylsMessageExecutor/RaylsMessageExecutorV1.sol";

/// @notice Test double: permits participant/token checks. It proves nothing about
///         a real registry, permissioned membership, proofs or transport authenticity.
contract PermissiveValidationFixture {
    function validateMessageParticipants(uint256, uint256) external pure {}
    function validateTokenForParticipant(bytes32, uint256) external pure {}
}

/// @notice Synthetic application: records effects, not currency or token balances.
contract RecordingTarget {
    uint256 public total;
    uint256 public calls;
    bool public fails;

    error ControlledTargetFailure(uint256 requestedUnits);
    event EffectApplied(
        bytes32 indexed messageId,
        uint256 sourceChainId,
        address sourceSender,
        uint256 units,
        uint256 totalAfter,
        uint256 callsAfter,
        address immediateCaller
    );

    function setFailure(bool value) external { fails = value; }

    function applyEffect(uint256 units) external {
        if (fails) revert ControlledTargetFailure(units);
        require(msg.data.length >= 120, "missing execution context");
        bytes32 messageId;
        uint256 sourceChainId;
        address sourceSender;
        assembly {
            messageId := calldataload(sub(calldatasize(), 84))
            sourceChainId := calldataload(sub(calldatasize(), 52))
            sourceSender := shr(96, calldataload(sub(calldatasize(), 20)))
        }
        total += units;
        calls++;
        emit EffectApplied(messageId, sourceChainId, sourceSender, units, total, calls, msg.sender);
    }
}

/// @notice Deliberately granted a local executor role so the nested attempt reaches
///         the receive reentrancy guard instead of failing the permission check first.
contract ReentryTarget {
    address public executor;
    bytes public nestedCall;
    uint256 public calls;
    event NestedAttempt(bool succeeded, bytes returnedData);

    function configure(address executor_, bytes calldata call_) external {
        executor = executor_;
        nestedCall = call_;
    }

    function trigger() external {
        calls++;
        (bool success, bytes memory result) = executor.call(nestedCall);
        emit NestedAttempt(success, result);
    }
}

/// @notice Test-only, storage-compatible UUPS implementation. This is not an
///         official Rayls release and cannot establish arbitrary upgrade safety.
contract StudyExecutorV2 is RaylsMessageExecutorV1 {
    function contractVersion() external pure override returns (uint256) { return 2; }
}
