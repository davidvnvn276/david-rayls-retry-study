# How the official-component supplement fits this release

The complete original supplement is nested under `official-components/`. Its source, evidence, helper programs, original documentation and 999-entry manifest are retained unchanged. Its own statements about being a separate package describe its original delivery; it is now included here for convenience.

The preserved Go run compiled the official private relayer binary and executed its help command, then called actual official proof/calldata packages through an explicitly authored adapter. Four official unit-test packages passed; their 15 top-level tests include mocks and negative cases.

The component run re-executed 40 source transactions from an earlier local fixture and generated calldata matching 18 preserved destination calls. It did not execute that destination EVM again. Those 18 comparisons must not be substituted for the current added application runs' 19 delivery attempts.

For a fresh legacy transaction, proof generation and canonical signed-value agreement passed. A fresh type-2 transaction with valid fee caps encountered a transaction-root mismatch. The separate checker reconstructs the correct typed root and the differing legacy-style root produced by the pinned conversion. This is a narrow local compatibility observation, not a production vulnerability finding. Header submission and Hub acceptance were not completed; the fixture and contract header formats also have a documented boundary.

The CLI generated full-local configuration and then failed because Docker was unavailable. A read-only public RPC attempt returned HTTP 403 before chain ID was obtained. That response is an unavailable observation from that environment, not zero state or a globally unavailable RPC.

The original supplement's `study-input/lineage.json` names an earlier assembled archive hash. That is the lineage of its copied inputs, not the hash of this consolidated release. Its copied raw records are preserved independently. New application observations in `extension-evidence/` have their own source/build inputs, raw logs and repeatability checks; they are not silently substituted into the old component dataset.

Reproduce saved component checks with the root npm dependencies installed:

```bash
cd official-components
python check_integrity.py
node verify_saved.cjs evidence/run-02
cd ..
```

Fresh Go compilation/execution is optional and documented in the original README. A complete relayer service run still requires the actual coordinated private-network topology. This release does not authenticate an institutional deployment or establish current live transport behavior.
