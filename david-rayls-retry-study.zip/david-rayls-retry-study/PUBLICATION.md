# Publishing the article and evidence

## Before posting

1. Read `ARTICLE.md` and retain its local/synthetic/manual-transport scope. This package does not identify a production deployment or report a user incident.
2. Upload `david-rayls-retry-study.zip`, or the expanded project excluding `node_modules`, to a new public GitHub repository for this study. A suggested repository name is `david-rayls-retry-study`; this package does not claim that repository already exists.
3. Verify the uploaded ZIP’s SHA-256 against the file you uploaded. For an expanded repository, keep the included manifest and source pin.
4. Open the public link without relying on a signed-in private session. Confirm the article, README and evidence can be downloaded.
5. Add that real evidence URL to the last paragraph of the article. Do not link the unrelated earlier study or create a link to a repository that has not been published.
6. Pin the public commit or release so the reviewed evidence version remains identifiable.

The article’s official-source links already point to the tested contract commit. The reproducibility link still needs the actual URL created by your publication step.

### Simple browser upload

1. Sign into your own GitHub account and choose **New repository** from the plus menu.
2. Select your account as owner. Enter a new repository name, for example `david-rayls-retry-study` if available.
3. Choose **Public** if you want the moderator and readers to inspect it. Leave initial README creation unchecked, then create the repository.
4. Choose the page’s **uploading an existing file** link, or **Add file → Upload files**.
5. On your computer, make a separate copy of `GITHUB_README.md` and rename that copy to `README.md`. Keep the original package files unchanged.
6. Upload that public landing README, `ARTICLE.md` and the complete `david-rayls-retry-study.zip` as three files. You do not need to upload thousands of individual evidence files through the browser.
7. Use a commit message describing this local study, then commit the upload.
8. Open the ZIP in the repository file list and use its raw/download button. Confirm the downloaded archive opens and contains the full English README and evidence.
9. Copy the real repository or pinned-commit URL into the manuscript’s reproducibility paragraph. Open the public link from a private browser window to check reader access.
10. Keep the article’s local/synthetic/manual-transport labels when posting it. The new public repository’s URL is a publication step, not something this package claims has already happened.

## Images and placement

| File | Position | What it contributes |
|---|---|---|
| `figures/01-retry-banner.png` | Below the title, before the opening paragraph | The three identity/retry outcomes and explicit local scope |
| `figures/02-measured-outcomes.png` | After the “A new source submission is a new message” section | Exact receipt, counter and execution-flag outcomes from the focused records |
| `figures/03-ordering-policy.png` | After “The nonce existed, but ordering was conditional” | Source-emitted flag versus explicitly conditional strict-mode controls |

Use the original PNG files at full resolution. Keep the footnotes visible. They are rendered evidence diagrams, not explorer screenshots. Source SVGs and `figure-data.json` are included for inspection.

The revised figures place the supplied full-colour Rayls symbol proportionally and retain its original black background. The PNG bytes are unchanged; there is no typed wordmark or invented token icon. `figures/brand-provenance.json` records its identity. The original homepage navigation SVG remains as an unused reference asset.

## Copying and platform adaptation

`ARTICLE.md` contains the full canonical draft. The HTML reading copy has a formatted-text copy button; add images separately in the platform editor. Copying a local HTML image does not upload it to Binance Square, Medium or X.

For an X introduction, use the same question and link to the full article/evidence. For a cross-post, preserve the same central findings and scope. A shortened version must still state that the test is local, the application is synthetic and the transport is manual.

Do not convert “one committed execution per message ID” into “exactly-once payments.” Do not present strict-nonce controls as the pinned senders’ default. Do not describe the study-only V2 as an official Rayls upgrade.

## Language and score

The article is an English research draft. It does not claim an RP score, imply endorsement by Rayls or guarantee that every implementation, upgrade or deployment behaves the same way. Evaluation belongs to the quest moderator.
