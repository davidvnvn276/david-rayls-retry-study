# Publish and edit the reviewed article

Release `david-retry-reviewed-20261021`. All publication text and instructions are English. The PNGs are exact authored evidence diagrams, not explorer screenshots.

## Update the public evidence first

1. Upload the new `david-rayls-retry-study.zip` to the existing evidence repository, replacing the older ZIP.
2. Use `GITHUB_README.md` as the repository's root README.md. Upload the ZIP's external `.sha256` companion if desired.
3. Open the repository in a signed-out browser and confirm the ZIP is downloadable.
4. Download it and check that its `RELEASE.json` says `david-retry-reviewed-20261021`.
5. For a fixed citation, copy the actual GitHub commit permalink after the upload. No new commit hash is invented by this package.
6. Only then replace the published article text. The article's repository link is a real existing location, but this review has not uploaded its new release there.

## Binance Square

Open `ARTICLE.html` in a browser and use **Copy formatted text**. Paste into the platform's article editor. If clipboard access is unavailable, select and copy the visible article, or use `ARTICLE.md` and format headings manually. Check paragraphs, the comparison table, links and title after pasting. Upload the three supplied PNGs separately; copying formatted text intentionally omits embedded images.

| Image | Placement | Dimensions |
|---|---|---|
| `figures/01-retry-banner.png` | Cover/banner; before the opening paragraph if the editor has no separate cover field | 3200 × 1280, exactly 5:2 |
| `figures/02-measured-outcomes.png` | After the final paragraph of “Two successful message IDs, one repeated business request,” before the recovery heading | 3200 × 1800, 16:9 |
| `figures/03-ordering-policy.png` | After the final paragraph of “Message identity does not determine delivery order,” before “What the records establish” | 3200 × 1800, 16:9 |

Suggested captions:

1. Two local application fixtures receive the same repeated business request. Different protocol IDs can result in two effects or one, depending on the application guard. Synthetic units; manual local delivery.
2. Two successful protocol IDs do not necessarily imply two business effects. Separate recovery control: failure leaves a 5-unit message retryable; success commits its state; replay is rejected.
3. The harness delivers digit operations in different orders: 12 versus 21. An application sequence guard rejects premature step 2 and accepts that same message after step 1.

Suggested alt text:

- Banner: Local Rayls request comparison, unguarded total 14 and request-ID guarded total 7 after two submissions of a 7-unit request.
- Figure 2: Protocol IDs consumed and business effects counted separately; failed, recovered and replayed states of the same 5-unit message.
- Figure 3: Forward digit order yields 12, reversed delivery yields 21, and sequence-guarded recovery yields 12.

Preserve the opening scope paragraph. Keep synthetic counter units separate from tokens or customer payments. Do not describe these fixtures as a production bridge deployment or the manually injected delivery as live relayer transport.

## Substack and Medium

For Substack, open `SUBSTACK.html` and copy its formatted text into a new or existing draft. Insert the same three images at the marked section boundaries visible in that reading copy. This is an adapted explanation of the same experiment, not a new research submission.

For Medium or another article editor, either the full ARTICLE reading copy or the shorter SUBSTACK version can be used. HTML files are reading/copy aids; they do not guarantee direct HTML import support on a platform. Preview the actual post after pasting.

The cover remains 5:2. Keep critical text inside its margins and inspect the platform's preview crop. Do not stretch the image to another ratio. Internal diagrams are 16:9.

## Final publishing check

Verify the correct release is public, the title matches the chosen version, all three figures show the new application controls, source links are intact, the result table is legible and the scope is visible before sharing the link. The package neither posts to an account nor updates GitHub automatically.
