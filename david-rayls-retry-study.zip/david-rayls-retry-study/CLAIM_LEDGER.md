# Publication claim ledger

| Claim | Evidence | Boundary |
|---|---|---|
| Retrying a failed ID can succeed after recovery | Added E01–E03; raw destination transactions, exact parent-state errors and same-block getters | Manual local delivery; no automatic relayer recovery |
| Another source submission gets a new ID | Added messages.json; E04–E07; source receipt and nonce/ID reconstruction | Pinned sender snapshot, authored application payload |
| Application request guard changes repeated-request outcome from 14 to 7 | Added E04–E07, RequestApplied/DuplicateIgnored events and getters | Synthetic fixtures; not evidence of duplicate real payments |
| The guard still accepts a distinct operation | E10, total 7 to 15 | Simple fixed-origin fixture, not complete financial idempotency |
| Changing amount under an existing request ID is rejected | E09 | Illustrative application policy |
| Order changes a noncommutative application result | E13–E14, digit events and getters | Delivery order chosen by the harness |
| An application sequence guard preserves retry of step 2 | E15–E16 | Application rule, separate from protocol nonce branch |
| Source-emitted messages ignore receiver nonce enforcement in this snapshot | Pinned MessageSender and BatchMessageSender; baseline F05/F07; added inbound nonce reads | Not a production transport policy finding |
| Strict nonce enforcement exists conditionally | Baseline F11–F16 | Manually assembled false-flag inputs |
| Tentative execution marker is rolled back | Baseline F06 opcode/storage records; added E01 state | Local EVM semantics |
| Two actual local EVMs are used in added runs | fixture.json, RPC chain IDs, source code absence/destination code presence | Two providers in one process; not an official private network |
| Original experiment is repeatable | Four preserved baseline runs, comparison and reviewer checks | Repeated deterministic experiment |
| Added controls are repeatable | Two new runs and application-repeatability.json | Repeated deterministic experiment |
| Official code components were executed | official-components execution logs and evidence/run-02 | Not a running official daemon |
| Type-2 proof encoding differs for the retained control | Separate Node canonical/legacy root reconstruction plus official generator output | Ganache single-transaction blocks; no Axyl or production claim |
| Full service topology was not completed | Preserved full-init error and NEXT_STEPS.md | Missing Docker in original review environment |

Authoritative current documents are the root ARTICLE.md, README.md, RESULTS.md and this ledger. Files in review/history are earlier publication snapshots retained for provenance. The original component supplement is also retained unchanged and must be read with OFFICIAL_COMPONENTS.md.
