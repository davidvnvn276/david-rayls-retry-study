# Claim ledger

This table separates code observations, local execution and analysis. It does not certify a live deployment.

| Claim | Evidence level | Reproducible reference | Limit |
|---|---|---|---|
| The source snapshot is exactly pinned | Source identity | `sources/provenance.json`; `check_integrity.cjs`; 383 Git blobs | Inventory is obtained from GitHub; this is not a deployed-runtime match |
| The tested senders emit `ignoresNonce=true` | Source and local execution | `MessageSender.prepareMessage`, `BatchMessageSender.prepareBatch`; raw source events; derived source messages | Does not establish every live transport stage’s metadata policy |
| The same successful ID is rejected | Local execution | F01–F03, F09, F27–F28, seeded replays, restart | Same executor state and tested code/configuration |
| Failure leaves the message retryable | Local execution plus EVM rollback analysis | F06–F08; failed receipt, revert bytes, getter and effect delta | Does not guarantee eventual delivery or automatic relayer retries |
| New source submissions can carry identical application payload under different IDs | Local execution and independent ID reconstruction | F04; source events; nonce 1 versus 2; A.total 7 → 14 | Synthetic application lacks business deduplication; not a duplicate-payment incident |
| Nonce alone is insufficient across sending modules | Source and local execution | F10; equal nonce/message data, different module addresses and IDs | Concerns the two inspected module instances |
| The emitted payloads accepted reversed delivery | Local execution | F05; nonce 4 before 3; both IDs consumed; inbound counter stays 0 | Manual delivery on one EVM, not an observed live network order |
| A strict-order receiver branch exists | Source and conditional local probes | F11–F16 | Inputs were manually assembled with the flag false, not emitted as the pinned default |
| Role/pause failures can leave fresh IDs unconsumed | Local execution | F17–F20 | The test deliberately restores permissions/unpauses; it does not prove recovery of an external operator |
| Executor batch failure rolls back its subcalls | Local execution | F25–F28, raw failure index, effect deltas | Not the same interface as `Endpoint.sendBatch`; not distributed atomicity |
| Compatible test upgrade preserved the sampled consumed ID | Local execution and storage reads | F31; UUPS slot; mapping slot before/after | Study V2 changes only the version getter; no arbitrary upgrade guarantee |
| State persisted across process exit/reopen | Local execution | before/after process snapshots and R01/R02 | Local Ganache database; no relayer, distributed failover or production chain |
| Events and state reconcile in all four complete runs | Saved-record verification | `saved-record-verification.json`, `derived-effects.json`, `review/four-run-comparison.json` | Three original runs plus one fresh review execution; checkers are not independent consensus observers or extra EVM runs |
| The failed execution contains a tentative marker write that does not persist | Local opcode trace and historical state | F01/F06/F25 raw compressed traces and `trace-summary.json` | Traces come from the same local EVM; they are not independent production observations |
| Compiled artifacts match a fresh execution of the compiler | Compiler reproduction | `recompile-verification.json` | Same compiler implementation and original entry-point selection |
| Recorded deployments match reconstructed creation inputs and fixed runtime bytes | Saved deployment reconciliation | `deployment-verification.json`, raw local `eth_getCode` replies | Compiler-declared immutables are masked in fixed-byte comparison; constructors are fully checked; no production mapping |
| Business deduplication needs a separately defined identity policy | Analysis supported by F04 and per-ID standard semantics | Article’s integration discussion; ERC-5164 | Does not infer whether any real Rayls application already implements such a policy |

## Conditions that would require revising the article

- A different source version changes sender metadata, nonce behavior or ID construction.
- A mapped live deployment uses different code/configuration or a transport stage changes the metadata.
- A raw event, ID, state delta or storage reading fails reconciliation.
- A reproduction changes fixtures, permissions, application semantics, upgrade layout or runtime assumptions.
- A future claim concerns real assets, membership, encryption or transport authenticity that this harness does not exercise.

The manuscript intentionally states the conclusion at the level this evidence supports. Passing these cases does not prove correctness for every input or deployment.
