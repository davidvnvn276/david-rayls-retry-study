# What Does a Cross-Chain Message ID Actually Protect?

## A local Rayls experiment on retries, repeated requests and ordering

A transaction succeeds. The message is marked executed. But how many business operations did the receiving application actually perform?

That question led me to a useful local comparison. I submitted the same 7-unit business request twice through pinned Rayls contracts. An application without a request guard reached **14**. A second application, with its own request-ID guard, stayed at **7**. In both comparisons, two different message IDs were successfully executed by the local destination.

**These are synthetic application units, not money.** The added tests run on two separate local Ganache EVMs, with authorized manual message delivery. They do not test a live institutional network, actual relayer transport or customer payments.

## Two IDs can represent one intended operation

The first application was deliberately simple: each accepted instruction added its amount. Submitting the same request ID and amount in another source transaction advanced the sender nonce and produced a different message ID. Both messages were valid for the fixture, so the effect happened twice.

The second application retained the same idea but added a business-level record. After checking the expected executor and origin, it recorded the request ID and amount. A later matching request returned successfully without applying the amount again.

The comparison was therefore specific:

| Two submissions of the same 7-unit request | No application guard | Request-ID guard |
|---|---:|---:|
| Consumed protocol IDs | 2 | 2 |
| Business effects | 2 | 1 |
| Final counter | 14 | 7 |

A distinct 8-unit request still worked in the guarded application, bringing it to 15. Reusing the earlier request ID with a changed amount was rejected. These controls distinguish request identity from a blanket refusal to process later work.

This does not expose duplicate payments in a deployed financial product. It shows an expected boundary: a protocol's protection against replaying one successful ID is different from an application's decision about repeated business instructions.

## Failure can preserve a message for retry

I then made another guarded application fail deliberately on a 5-unit instruction.

The destination transaction reverted. The application total stayed at 0. Neither its business-request marker nor the executor's consumed-ID marker remained committed.

After removing the failure condition, the same message ID and payload succeeded. The total became 5. Another replay was rejected and left it at 5.

The pinned executor writes its execution marker before the application call. A propagated revert rolls that tentative write back. In the authored application, the same rollback also removes the tentative request marker.

That establishes retryability under the tested conditions. It does not demonstrate that a live relayer will retry automatically or that an application which keeps failing will eventually recover. Rayls' documented standard teleport flow describes manual retry after a destination execution revert; the local study examines the contract behavior beneath that workflow.

## Order needs a different control

Addition is a poor way to demonstrate ordering: adding 1 and 2 produces the same sum either way. I used an application that appends digits instead.

With the same intended sequence, forward delivery produced **12**. Reversing the manual delivery produced **21**. The pinned source senders set `ignoresNonce = true`, and the receiver's inbound nonce remained 0 in these controls.

The harness chose those orders. This is not evidence of the ordering policy or usual behavior of a running production relayer.

A third fixture enforced its own next expected step. Sending step 2 first reverted and left its ID unconsumed. Sending step 1, then retrying that exact step-2 message, produced **12**. Application sequencing and protocol replay protection solved different questions.

## What was actually run

The contract snapshot is commit `ed8863885c8ed5d5d317d47a34c063907192687a`, whose package metadata reports `2.6.3-nightly.2`. The experiment uses actual pinned Endpoint, sender, receiver, resource, executor and access-manager code, with linked libraries and proxies. Applications and permissive source validation are explicit test fixtures.

The added experiment was executed twice from fresh providers, physical chain IDs 10101 and 20202, in one Node process. Each has 16 cases, 14 source messages, 19 delivery attempts and 90 transactions including setup and seven deliberate reverts. All deterministic case records match between those runs.

A separate saved-record checker reconstructs IDs from raw source events and binds delivery inputs, receipts and state readings. The package also preserves four broader one-EVM baseline runs, opcode/storage records and a separate official-component supplement.

The complete official service topology was not run. Official proof/calldata component execution is recorded separately, including a narrow Ganache transaction-encoding mismatch. There is no completed Hub/CTS transport result or verified production mapping. These limits remain part of the published evidence.

## Keep the identities connected

Before retrying, an application needs to know which existing message failed and whether its intended effect already happened. Before resubmitting at the source, it needs a rule for recognizing the same business request under a different protocol ID.

The record should connect the business request, source transaction, message ID, destination result and final application state. Counting green receipts alone cannot replace that connection.

The [evidence repository](https://github.com/davidvnvn276/david-rayls-retry-study) hosts the study. This revision is identified by release `david-retry-reviewed-20261021` inside the reviewed ZIP. Its English README gives separate instructions for checking saved observations and executing new local controls. No real assets are required.

Primary references: [ERC-5164](https://eips.ethereum.org/EIPS/eip-5164), [Rayls' cross-chain transaction guide](https://docs.rayls.com/docs/how-a-cross-chain-transaction-works), and the [pinned contract source](https://github.com/raylsnetwork/rayls-sovereign-contracts/tree/ed8863885c8ed5d5d317d47a34c063907192687a).
