# Checked results and evidence paths

Release `david-retry-reviewed-20261021`.

## Added two-EVM application experiment

Two fresh deterministic executions are preserved in `extension-evidence/run-01` and `run-02`. Physical chain IDs are 10101 and 20202. Providers are separate but run in one Node process. Delivery is manual; there is no live relayer or transport authentication.

| Control | Result | Cases |
|---|---|---|
| Same 7-unit business request, no application guard | Two consumed IDs; two effects; total 14 | E04–E05 |
| Same request with application guard | Two consumed IDs; one effect; total 7 | E06–E07 |
| New 8-unit request | Guarded total becomes 15 | E10 |
| Existing request ID with changed amount | Reverts; fresh protocol ID remains unconsumed | E09 |
| Controlled application failure | Total 0; business and execution markers false | E01 |
| Same-ID recovery | Total 5; both markers true | E02 |
| Replay after recovery | Rejected; total remains 5 | E03 |
| Forward digit operations | 12 | E13 |
| Reversed delivery | 21 | E14 |
| Premature sequenced step 2 | Reverts; ID remains unconsumed | E15 |
| Step 1 then the same step-2 ID | 12; next expected application sequence 3 | E16 |

Each run: 16 cases, 14 source messages, 19 destination delivery attempts, 90 transactions including setup, seven intentional reverts and 12 consumed protocol IDs. Raw-record verification: 90 transaction/RPC bindings, 940 getter bindings, 14 ID reconstructions and 19 receiver-input bindings. Eleven application effects and one successful duplicate-ignored event are distinct observations.

`review/application-repeatability.json` compares both runs. `review/application-checker-controls.json` records intentional copied-record mutations. They test consistency and the checker, not additional real-world experiments.

## Original contract baseline

Four complete runs, each with one physical EVM, 33 focused cases, three 60-operation sequences, 579 transactions, 103 intentional reverts and a separate-process local-database restart. The saved-record checker reconciles 114 application effects, 107 source-emitted messages and 113 committed IDs per run. Those quantities describe different scopes and must not be added as one experiment count.

Paths: `evidence/run-01` through `run-03`; `review-evidence/run-04`. The original execution scripts and vendor bytes remain unchanged.

## Official components

`official-components/` preserves its original evidence and manifest. It records actual component execution, 40 source transactions replayed with matching hashes, and 18 calldata comparisons against a separate preserved destination dataset. A type-0 proof verifies; the type-2 control has a reconstructed-root mismatch on Ganache. The full official stack failed its Docker preflight in the original review host. No production deployment was identified.

See `OFFICIAL_COMPONENTS.md`. These results do not demonstrate a live relayer, successful Hub proof submission or production failure.
