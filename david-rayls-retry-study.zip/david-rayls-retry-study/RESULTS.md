# Results and evidence map

## Provenance

- Public contract source: `raylsnetwork/rayls-sovereign-contracts`, commit `ed8863885c8ed5d5d317d47a34c063907192687a`.
- 383 vendored files match the Git blob identities in the captured source inventory. This is not an assertion that the commit is deployed in production.
- Compiler: solc-js 0.8.24; optimizer 50; Paris target. EVM: local Ganache 7.9.2, Shanghai, chain ID 31337.
- Runs were executed on Linux with Node v24.19.0. Their metadata records start/finish timestamps.

## Repeated execution

| Metric | Run 01 | Run 02 | Run 03, clean install | Run 04, review |
|---|---:|---:|---:|---:|
| Focused cases | 33 | 33 | 33 | 33 |
| Fresh fixtures for seeded sequences | 3 | 3 | 3 | 3 |
| Seeded operations | 180 | 180 | 180 | 180 |
| Source messages in seed 1701 / 2909 / 4177 | 28 / 33 / 32 | 28 / 33 / 32 | 28 / 33 / 32 | 28 / 33 / 32 |
| Local transactions, including setup | 579 | 579 | 579 | 579 |
| Successful / intentionally reverted transactions | 476 / 103 | 476 / 103 | 476 / 103 | 476 / 103 |
| Raw application-effect events | 114 | 114 | 114 | 114 |
| Source-emitted messages | 107 | 107 | 107 | 107 |
| Unique committed IDs across that run’s executors | 113 | 113 | 113 | 113 |
| Separate Node process reopening the local database | Passed | Passed | Passed | Passed |
| Separate raw-record reconciliation | Passed | Passed | Passed | Passed |

The four runs repeat the same deterministic experiment on separate fresh local databases. They are not observations from four live networks. Counts of setup transactions, effects, source messages and consumed IDs must not be treated as interchangeable sample sizes. Run 03 and review run 04 each used a separate clean install and project directory; neither is a different protocol scenario. The fourth raw dataset is under `review-evidence/run-04/`; the four-run comparison is under `review/four-run-comparison.json`.

## Main measured findings

| Case | Input or condition | Measured result |
|---|---|---|
| F01 | First source-emitted 7-unit instruction | A.total 0 → 7; consumed flag false → true |
| F02 | Same successful message again | `MessageIdAlreadyExecuted`; A.total stays 7 |
| F04 | Same application payload submitted again at source | New nonce and ID; A.total 7 → 14 |
| F05 | Source nonce 4 delivered before 3, both carrying `ignoresNonce=true` | Both succeed; inbound counter remains 0 |
| F06 | Controlled application failure for a 17-unit message | `MessageFailure` wrapping `ControlledTargetFailure`; B.total stays 13; ID false |
| F07 | Later default-path message while F06 remains failed | Later message succeeds; earlier ID still false |
| F08 | Remove the failure and deliver the identical message | B.total 13 → 30; ID becomes true |
| F09 | Deliver the recovered message again | Replay rejected; B.total stays 30 |
| F10 | First dispatch-batch item versus first single message | Same nonce/message data, different IDs due to sending-module address |
| F11–F16 | Controlled `ignoresNonce=false` inputs | Strict sequence enforced; target failure and ID rejection roll the inbound nonce back |
| F17–F20 | Role removed/restored; executor paused/unpaused | Rejected deliveries leave fresh IDs unconsumed; same messages work after restoration |
| F23–F24 | Missing resource mapping, then registration | Failure does not consume ID; same controlled input succeeds after registration |
| F25–F28 | Direct executor batch and cross-entry replays | Failed batch effects roll back; recovered batch succeeds; single/batch methods share consumed-ID state |
| F29 | Nested call deliberately passes authorization | Receive reentrancy guard rejects inner call; no inner ID consumed |
| F30–F32 | Unauthorized upgrade; compatible study V2 upgrade | Unauthorized upgrade rejected; compatible test upgrade preserves old consumed ID; fresh execution works |
| F33 | Destination has no contract code | Rejected, no application effect, ID remains false |

The counter totals are not balances. The strict-mode inputs are manually assembled controls, not source-emitted defaults. The compatible V2 is a study fixture, not an official release. Direct executor batches are not equivalent to dispatch batches or distributed atomic settlement.

## Revert categories per run

| Category | Reverted local transactions |
|---|---:|
| MessageIdAlreadyExecuted | 20 |
| MessageFailure | 31 |
| MessageReceiver__WrongNonce | 1 |
| RaylsAccessManaged__Unauthorized | 33 |
| RaylsAccessManaged__ContractPaused | 14 |
| MessageReceiver__UnauthorizedEndpoint | 1 |
| Error(string), no contract at destination | 2 |
| MessageBatchFailure | 1 |
| **Total** | **103** |

These are expected test outcomes. A failed destination attempt is not evidence that a customer transaction failed in production. Revert bytes were obtained through parent-state `eth_call` simulations of the exact mined failed inputs; both inputs and errors are retained in the RPC journal.

## Opcode trace reconciliation

The local database was reopened to collect read-only `debug_traceTransaction` output for three selected transactions. No block was added during capture. Compressed raw traces and request options are supplied under each run’s `traces/` directory.

| Case | Opcode steps | Tentative execution-slot write | Historical post-transaction flag | Log opcodes / receipt logs |
|---|---:|---|---|---:|
| F01 successful first delivery | 12,395 | 1 | true | 2 / 2 |
| F06 controlled application failure | 12,369 | 1 | false | 0 / 0 |
| F25 failed executor batch | 4,089 | 1 | false | 1 / 0 |

The computed mapping key is derived from the message ID and the compiler’s `executed` storage slot. The verifier checks the corresponding SSTORE stack values against the compressed raw trace. In F25, the first application subcall reached a log opcode, but the later failure reverted the transaction and left no receipt logs. These are local traces of already counted transactions, not additional experiments or mainnet observations.

## Evidence levels

**Documented/source-inspected:** sender nonce construction, sender flag, ID derivation, optional receiver nonce branch, executor state and failure propagation, and ERC-5164’s per-ID execution/retry requirements.

**Executed locally:** the cases and sequences above, real Rayls authorization and routing modules, controlled target failures, readback of counters/flags, storage-compatible study upgrade and database reopening in another Node process.

**Analysis:** an integration should distinguish application request identity, message identity, ordering policy and application completion. The protocol’s consumed-ID ledger is not a substitute for an application’s business deduplication policy.

**Not established:** live deployment equivalence, transport authenticity, encryption, relayer recovery/timing, consensus safety, real membership/token validation, automatic resource deployment, asset backing, customer payments, arbitrary upgrades or full-system exactly-once behavior.

## Files to start with

1. `evidence/run-01/saved-record-verification.json`
2. `evidence/run-01/focused/F04.json`
3. `evidence/run-01/focused/F05.json`
4. `evidence/run-01/focused/F06.json` and `F08.json`
5. `evidence/run-01/before-process-restart.json` and `after-process-restart.json`
6. `evidence/repeatability-comparison.json`

Each focused case links its raw transaction records. Source messages are saved separately and can be checked against the decoded source events and independent ID reconstruction.
