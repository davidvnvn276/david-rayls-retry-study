'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const ganache=require('ganache'),solc=require('solc'),{ethers}=require('ethers');
const {ROOT,FILES,COMMIT,write,sha256,verifyVendor}=require('../scripts/common.cjs');
const {Harness}=require('../scripts/harness.cjs');
const APP='extensions/ApplicationControls.sol';
const args=process.argv.slice(2);assert(args.length===2&&args[0]==='--output','Usage: node extensions/run.cjs --output runs/application-01');
const out=path.resolve(ROOT,args[1]);assert(out.startsWith(ROOT+path.sep)&&!fs.existsSync(out),'Choose a new output directory inside this project');fs.mkdirSync(out,{recursive:true});
const started=new Date().toISOString();
global.fetch=async()=>{throw Error('External network disabled for this experiment');};
const inputs=['extensions/run.cjs',APP,'scripts/common.cjs','scripts/harness.cjs','package.json','package-lock.json'];
write(path.join(out,'execution-inputs.json'),{captured_before_execution:true,source_commit:COMMIT,sha256:Object.fromEntries(inputs.map(f=>[f,sha256(fs.readFileSync(path.join(ROOT,f)))]))});
function compile(){
 const resolved={};function load(name){for(const root of [ROOT,path.join(ROOT,'node_modules')]){const p=path.resolve(root,name);if(p.startsWith(root+path.sep)&&fs.existsSync(p)){const content=fs.readFileSync(p,'utf8');resolved[name]={content};return {contents:content};}}return {error:'Missing '+name};}
 const sources={};for(const name of [...Object.values(FILES),APP]){const r=load(name);assert(!r.error,r.error);sources[name]={content:r.contents};}
 const settings={optimizer:{enabled:true,runs:50},evmVersion:'paris',outputSelection:{'*':{'*':['abi','evm.bytecode','evm.deployedBytecode','storageLayout']}}};
 const result=JSON.parse(solc.compile(JSON.stringify({language:'Solidity',sources,settings}),{import:load}));
 write(path.join(out,'compiler-diagnostics.json'),result.errors||[]);assert(!(result.errors||[]).some(x=>x.severity==='error'),JSON.stringify(result.errors));
 write(path.join(out,'solc-input.json'),{language:'Solidity',sources:resolved,settings});write(path.join(out,'compiled-contracts.json'),result.contracts);
 write(path.join(out,'build-provenance.json'),{compiler:solc.version(),source_commit:COMMIT,vendor_files:verifyVendor(),source_count:Object.keys(resolved).length,input_sha256:sha256(fs.readFileSync(path.join(out,'solc-input.json')))});
 return result.contracts;
}
// Original baseline scripts remain unchanged. New controls explicitly set valid EIP-1559 fee caps.
class ControlHarness extends Harness { async tx(label,request,expected='success'){return super.tx(label,{type:'0x2',maxFeePerGas:'0xb2d05e00',maxPriorityFeePerGas:'0x3b9aca00',...request},expected);} }
const contracts=compile(),providers=[];
function newProvider(chainId){const p=ganache.provider({logging:{quiet:true},wallet:{deterministic:true,totalAccounts:6,defaultBalance:1000},chain:{chainId,networkId:chainId,hardfork:'shanghai',time:new Date('2026-01-01T00:00:00Z')},miner:{blockGasLimit:'0x2625a00',timestampIncrement:1}});providers.push(p);return p;}
const src=new ControlHarness(newProvider(10101),contracts,out,'source'),dst=new ControlHarness(newProvider(20202),contracts,out,'destination');
const messages=[],deliveries=[],cases=[];let s,d,apps,requests;
async function bootstrap(h,id,source){
 const accounts=await h.rpc('eth_accounts');[h.admin,h.deliverer,h.direct,h.origin,h.outsider]=accounts;
 const manager=await h.proxy(FILES.manager,'RaylsAccessManagerV1',[h.admin],(source?'source':'destination')+'-manager');h.manager=manager;
 const endpoint=await h.proxy(FILES.endpoint,'EndpointV1',[id,99999,50,manager.address],(source?'source':'destination')+'-endpoint');
 const executor=await h.proxy(FILES.executor,'RaylsMessageExecutorV1',[manager.address],(source?'source':'destination')+'-executor');
 const resource=await h.deploy(FILES.resource,'ResourceManager',[ethers.ZeroAddress,h.admin,manager.address]);
 const receiver=await h.deploy(FILES.receiver,'MessageReceiver',[resource.address,executor.address,endpoint.address,h.admin,manager.address]);
 let sender;
 if(source){const validator=await h.deploy(FILES.fixtures,'PermissiveValidationFixture');sender=await h.deploy(FILES.sender,'MessageSender',[id,99999,validator.address,validator.address,endpoint.address,h.admin,manager.address]);}
 await h.send(endpoint,'configureModules',[resource.address,sender?.address||ethers.ZeroAddress,receiver.address,ethers.ZeroAddress],h.admin,'configure-'+id);
 if(source)await h.role('LOCAL_SOURCE_USER',[[endpoint,['send(uint256,address,bytes)']]],[h.origin,h.outsider]);
 else await h.role('LOCAL_DELIVERER',[[endpoint,['receivePayload']]],[h.deliverer]);
 await h.role('MESSAGE_RECEIVER',[[executor,['executeMessage','executeMessageBatch']]],[receiver.address]);
 await h.role('RESOURCE_RESOLVER',[[resource,['handleWithResourceId']]],[receiver.address]);
 return {manager,endpoint,executor,resource,receiver,sender};
}
async function dispatch(app,fn,fnArgs,label,caller=src.origin){
 const payload=app.interface.encodeFunctionData(fn,fnArgs);
 const rec=await src.send(s.endpoint,'send(uint256,address,bytes)',[20202,app.address,payload],caller,label+'-source');
 const e=rec.decoded_logs.find(x=>x.name==='MessageDispatched');assert(e);
 const m={id:e.args.messageId,from:e.args.from,to:e.args.to,sourceChainId:10101,destinationChainId:20202,message:e.args.data,source_hash:rec.receipt.transactionHash,source_transaction:src.records.at(-1).file};
 assert.equal(m.message.messageMetadata.ignoresNonce,true);messages.push(m);return m;
}
async function deliver(m,label,expected='success',controlled=false){
 const rec=await dst.send(d.endpoint,'receivePayload',[m.sourceChainId,m.from,m.to,m.message,m.id],dst.deliverer,label,expected);
 deliveries.push({label,messageId:m.id,sourceChainId:m.sourceChainId,controlled_receiver_input:controlled,destination_transaction:dst.records.at(-1).file});return rec;
}
function handleInfo(h){return {file:h.file,name:h.name,address:h.address,implementation:h.implementation};}
async function snapshot(){
 const block=await dst.rpc('eth_getBlockByNumber',['latest',false]),reads=[];
 async function read(h,fn,args=[]){const input={to:h.address,data:h.interface.encodeFunctionData(fn,args)},raw=await dst.rpc('eth_call',[input,block.number]);const v=h.interface.decodeFunctionResult(fn,raw)[0];reads.push({file:h.file,contract:h.name,address:h.address,fn,args,raw,value:typeof v==='bigint'?v.toString():v});return typeof v==='bigint'?v.toString():v;}
 const state={apps:{},executed:{},inboundNonce:await read(d.receiver,'getInboundNonce',[10101])};
 for(const [name,a] of Object.entries(apps)){
  if(['forward','reverse','sequenced'].includes(name))state.apps[name]={value:await read(a,'value'),nextSequence:await read(a,'nextSequence')};
  else state.apps[name]={total:await read(a,'total'),calls:await read(a,'calls'),fails:await read(a,'fails'),sharedProcessed:await read(a,'processed',[requests.shared]),retryProcessed:await read(a,'processed',[requests.retry])};
 }
 for(const m of messages)state.executed[m.id]=await read(d.executor,'executed',[m.id]);
 return {block_number:block.number,block_hash:block.hash,state,reads};
}
async function record(id,description,action,check){const before=await snapshot(),start=dst.records.length;await action();const after=await snapshot();check(after.state,before.state);const item={id,description,before,after,destination_transactions:dst.records.slice(start).map(x=>x.file)};cases.push(item);write(path.join(out,'cases',id+'.json'),item);console.log('PASS',id,description);}
async function main(){
 s=await bootstrap(src,10101,true);d=await bootstrap(dst,20202,false);
 assert.equal(await src.rpc('eth_chainId'),'0x2775');assert.equal(await dst.rpc('eth_chainId'),'0x4eea');
 apps={};for(const [name,guard] of [['plain',false],['guarded',true],['recovery',true]])apps[name]=await dst.deploy(APP,'RequestCounter',[d.executor.address,10101,src.origin,guard],name);
 for(const [name,guard] of [['forward',false],['reverse',false],['sequenced',true]])apps[name]=await dst.deploy(APP,'SequenceCounter',[d.executor.address,10101,src.origin,guard],name);
 requests=Object.fromEntries(['retry','shared','fresh','outsider'].map(x=>[x,ethers.id('application-control-'+x)]));
 const isolation=[];for(const [name,a] of Object.entries(apps)){const sourceCode=await src.rpc('eth_getCode',[a.address,'latest']),destinationCode=await dst.rpc('eth_getCode',[a.address,'latest']);assert.equal(sourceCode,'0x');assert.notEqual(destinationCode,'0x');isolation.push({name,address:a.address,source_code:sourceCode,destination_runtime_keccak256:ethers.keccak256(destinationCode)});}
 write(path.join(out,'fixture.json'),{sourceChainId:10101,destinationChainId:20202,source:Object.fromEntries(Object.entries(s).filter(([,v])=>v).map(([k,v])=>[k,handleInfo(v)])),destination:Object.fromEntries(Object.entries(d).filter(([,v])=>v).map(([k,v])=>[k,handleInfo(v)])),apps:Object.fromEntries(Object.entries(apps).map(([k,v])=>[k,handleInfo(v)])),requests,isolation,origin:src.origin,deliverer:dst.deliverer,outsider:src.outsider});
 await dst.send(apps.recovery,'setFails',[true],dst.admin,'enable-controlled-failure');
 const retry=await dispatch(apps.recovery,'applyRequest',[requests.retry,5],'E01');
 await record('E01','application failure rolls back protocol and business markers',async()=>{const r=await deliver(retry,'E01-fails','MessageFailure');assert.equal(r.revert.inner.name,'ControlledApplicationFailure');},a=>{assert.equal(a.apps.recovery.total,'0');assert.equal(a.apps.recovery.retryProcessed,false);assert.equal(a.executed[retry.id],false);});
 await dst.send(apps.recovery,'setFails',[false],dst.admin,'clear-controlled-failure');
 await record('E02','same message succeeds after application recovery',()=>deliver(retry,'E02-same-id-retry'),a=>{assert.equal(a.apps.recovery.total,'5');assert.equal(a.apps.recovery.retryProcessed,true);assert.equal(a.executed[retry.id],true);});
 await record('E03','successful message replay is rejected',()=>deliver(retry,'E03-replay','MessageIdAlreadyExecuted'),a=>assert.equal(a.apps.recovery.total,'5'));
 const p1=await dispatch(apps.plain,'applyRequest',[requests.shared,7],'E04');
 await record('E04','first unguarded request adds seven',()=>deliver(p1,'E04-plain-first'),a=>assert.equal(a.apps.plain.total,'7'));
 const p2=await dispatch(apps.plain,'applyRequest',[requests.shared,7],'E05');assert.notEqual(p1.id,p2.id);
 await record('E05','new ID repeats unguarded business effect',()=>deliver(p2,'E05-plain-resubmission'),a=>assert.equal(a.apps.plain.total,'14'));
 const g1=await dispatch(apps.guarded,'applyRequest',[requests.shared,7],'E06');
 await record('E06','guarded first request adds seven',()=>deliver(g1,'E06-guarded-first'),a=>assert.equal(a.apps.guarded.total,'7'));
 const g2=await dispatch(apps.guarded,'applyRequest',[requests.shared,7],'E07');assert.notEqual(g1.id,g2.id);
 await record('E07','new protocol ID is consumed without a second business effect',()=>deliver(g2,'E07-guarded-resubmission'),a=>{assert.equal(a.apps.guarded.total,'7');assert.equal(a.executed[g1.id],true);assert.equal(a.executed[g2.id],true);});
 await record('E08','replay of consumed duplicate message is rejected',()=>deliver(g2,'E08-guarded-replay','MessageIdAlreadyExecuted'),a=>assert.equal(a.apps.guarded.total,'7'));
 const conflict=await dispatch(apps.guarded,'applyRequest',[requests.shared,8],'E09');
 await record('E09','same request ID with changed amount is rejected',async()=>{const r=await deliver(conflict,'E09-conflict','MessageFailure');assert.equal(r.revert.inner.name,'RequestConflict');},a=>{assert.equal(a.apps.guarded.total,'7');assert.equal(a.executed[conflict.id],false);});
 const fresh=await dispatch(apps.guarded,'applyRequest',[requests.fresh,8],'E10');
 await record('E10','distinct business request remains executable',()=>deliver(fresh,'E10-fresh-request'),a=>assert.equal(a.apps.guarded.total,'15'));
 await record('E11','controlled wrong-chain receiver input is rejected by the app',async()=>{const r=await deliver({...conflict,sourceChainId:30303},'E11-wrong-chain','MessageFailure',true);assert.equal(r.revert.inner.name,'UnexpectedOrigin');},a=>{assert.equal(a.apps.guarded.total,'15');assert.equal(a.executed[conflict.id],false);});
 const outsider=await dispatch(apps.guarded,'applyRequest',[requests.outsider,1],'E12',src.outsider);
 await record('E12','different source sender is rejected by the app',async()=>{const r=await deliver(outsider,'E12-wrong-sender','MessageFailure');assert.equal(r.revert.inner.name,'UnexpectedOrigin');},a=>assert.equal(a.executed[outsider.id],false));
 const f1=await dispatch(apps.forward,'append',[1,1],'E13-one'),f2=await dispatch(apps.forward,'append',[2,2],'E13-two');
 await record('E13','forward noncommutative operations produce twelve',async()=>{await deliver(f1,'E13-one');await deliver(f2,'E13-two');},a=>assert.equal(a.apps.forward.value,'12'));
 const r1=await dispatch(apps.reverse,'append',[1,1],'E14-one'),r2=await dispatch(apps.reverse,'append',[2,2],'E14-two');
 await record('E14','reversing the same operation sequence produces twenty-one',async()=>{await deliver(r2,'E14-two');await deliver(r1,'E14-one');},a=>assert.equal(a.apps.reverse.value,'21'));
 const q1=await dispatch(apps.sequenced,'append',[1,1],'E15-one'),q2=await dispatch(apps.sequenced,'append',[2,2],'E15-two');
 await record('E15','application sequence guard leaves premature second step retryable',async()=>{const r=await deliver(q2,'E15-premature','MessageFailure');assert.equal(r.revert.inner.name,'SequenceMismatch');},a=>{assert.equal(a.apps.sequenced.value,'0');assert.equal(a.executed[q2.id],false);});
 await record('E16','first step then same-ID retry produces twelve',async()=>{await deliver(q1,'E16-one');await deliver(q2,'E16-same-id-two');},a=>{assert.equal(a.apps.sequenced.value,'12');assert.equal(a.apps.sequenced.nextSequence,'3');assert.equal(a.inboundNonce,'0');});
 src.save();dst.save();write(path.join(out,'messages.json'),messages);write(path.join(out,'deliveries.json'),deliveries);
 const final=await snapshot();write(path.join(out,'final-state.json'),final);
 write(path.join(out,'summary.json'),{status:'passed',started_at_utc:started,finished_at_utc:new Date().toISOString(),node:process.version,platform:process.platform,source_commit:COMMIT,physical_evms:2,physical_chain_ids:[10101,20202],same_node_process:true,manual_delivery:true,actual_transport_proof_verification:false,valid_explicit_type2_fee_caps:true,cases:cases.length,source_messages:messages.length,destination_delivery_attempts:deliveries.length,transactions:src.records.length+dst.records.length,reverted_transactions:[...src.records,...dst.records].filter(x=>x.status==='0x0').length,consumed_message_ids:Object.values(final.state.executed).filter(Boolean).length,plain_total_after_two_same_business_requests:cases.find(x=>x.id==='E05').after.state.apps.plain.total,guarded_total_after_two_same_business_requests:cases.find(x=>x.id==='E07').after.state.apps.guarded.total,guarded_total_after_distinct_request:final.state.apps.guarded.total,forward_value:final.state.apps.forward.value,reverse_value:final.state.apps.reverse.value,sequenced_value:final.state.apps.sequenced.value,scope:'Two separate unforked Ganache providers in one Node process; real pinned Rayls contracts, authored apps and permissive source validation; authorized manual destination delivery. No relayer daemon, Hub, CTS, Axyl or production claim.'});
 console.log('PASS application controls:',cases.length,'cases;',messages.length,'source messages;',deliveries.length,'delivery attempts.');
}
main().catch(e=>{src.save();dst.save();write(path.join(out,'failure.json'),{message:e.message,stack:e.stack});console.error(e);process.exitCode=1;}).finally(async()=>{for(const p of providers)await p.disconnect();});
