'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
assert(process.argv.length===4,'Usage: node extensions/compare.cjs RUN_A RUN_B');
const [a,b]=process.argv.slice(2).map(x=>path.resolve(x));
for(const f of fs.readdirSync(path.join(a,'cases')).sort())assert.deepEqual(JSON.parse(fs.readFileSync(path.join(a,'cases',f))),JSON.parse(fs.readFileSync(path.join(b,'cases',f))),'Case differs: '+f);
const load=p=>JSON.parse(fs.readFileSync(path.join(p,'summary.json'))),A=load(a),B=load(b);
for(const key of ['cases','source_messages','destination_delivery_attempts','transactions','reverted_transactions','consumed_message_ids','plain_total_after_two_same_business_requests','guarded_total_after_two_same_business_requests','guarded_total_after_distinct_request','forward_value','reverse_value','sequenced_value'])assert.deepEqual(A[key],B[key],'Summary differs: '+key);
console.log('PASS all 16 deterministic application case records and comparable results match. Repetitions are not independent production observations.');
