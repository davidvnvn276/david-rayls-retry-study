// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.24;

// Authored application fixtures, not Rayls protocol contracts or production apps.
abstract contract ExpectedOrigin {
    address public immutable expectedExecutor;
    uint256 public immutable expectedChain;
    address public immutable expectedSender;
    error UnexpectedOrigin();
    constructor(address executor, uint256 chain, address sender) {
        expectedExecutor = executor; expectedChain = chain; expectedSender = sender;
    }
    function checkOrigin() internal view returns (bytes32 id) {
        uint256 chain; address sender;
        // MessageLib appends bytes32 messageId, uint256 fromChainId, address from.
        assembly {
            id := calldataload(sub(calldatasize(), 84))
            chain := calldataload(sub(calldatasize(), 52))
            sender := shr(96, calldataload(sub(calldatasize(), 20)))
        }
        if (msg.sender != expectedExecutor || chain != expectedChain || sender != expectedSender) revert UnexpectedOrigin();
    }
}

contract RequestCounter is ExpectedOrigin {
    bool public immutable guardEnabled;
    address public immutable owner;
    bool public fails;
    uint256 public total;
    uint256 public calls;
    mapping(bytes32 => bool) public processed;
    mapping(bytes32 => uint256) public requestAmount;
    error ControlledApplicationFailure();
    error RequestConflict();
    error OwnerOnly();
    event RequestApplied(bytes32 indexed requestId, bytes32 indexed messageId, uint256 amount, uint256 total);
    event DuplicateIgnored(bytes32 indexed requestId, bytes32 indexed messageId);
    constructor(address executor, uint256 chain, address sender, bool guarded) ExpectedOrigin(executor, chain, sender) {
        owner = msg.sender; guardEnabled = guarded;
    }
    function setFails(bool value) external { if (msg.sender != owner) revert OwnerOnly(); fails = value; }
    function applyRequest(bytes32 requestId, uint256 amount) external {
        bytes32 messageId = checkOrigin();
        if (guardEnabled) {
            if (processed[requestId]) {
                if (requestAmount[requestId] != amount) revert RequestConflict();
                emit DuplicateIgnored(requestId, messageId); return;
            }
            processed[requestId] = true; requestAmount[requestId] = amount;
        }
        // Tentative business-marker writes above must also roll back on failure.
        if (fails) revert ControlledApplicationFailure();
        total += amount; calls += 1;
        emit RequestApplied(requestId, messageId, amount, total);
    }
}

contract SequenceCounter is ExpectedOrigin {
    bool public immutable enforceSequence;
    uint256 public value;
    uint256 public nextSequence = 1;
    error SequenceMismatch(uint256 expected, uint256 supplied);
    event DigitApplied(bytes32 indexed messageId, uint256 sequence, uint256 digit, uint256 value);
    constructor(address executor, uint256 chain, address sender, bool enforce) ExpectedOrigin(executor, chain, sender) { enforceSequence = enforce; }
    function append(uint256 sequence, uint256 digit) external {
        bytes32 messageId = checkOrigin();
        require(digit > 0 && digit < 10, "one digit required");
        if (enforceSequence) {
            if (sequence != nextSequence) revert SequenceMismatch(nextSequence, sequence);
            nextSequence += 1;
        }
        value = value * 10 + digit;
        emit DigitApplied(messageId, sequence, digit, value);
    }
}
