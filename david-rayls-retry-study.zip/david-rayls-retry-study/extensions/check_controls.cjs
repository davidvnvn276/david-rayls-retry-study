'use strict';
const fs=require('node:fs'),path=require('node:path'),os=require('node:os'),assert=require('node:assert/strict'),cp=require('node:child_process');
const {ROOT,write}=require('../scripts/common.cjs');
const input=path.resolve(ROOT,process.argv[2]||'extension-evidence/run-01');
const temp=fs.mkdtempSync(path.join(os.tmpdir(),'david-checker-controls-'));
const results=[];
try{
 for(const name of ['unchanged','reported-total','source-message','destination-input']){
  const target=path.join(temp,name);fs.cpSync(input,target,{recursive:true});
  const edit=(file,fn)=>{const p=path.join(target,file),x=JSON.parse(fs.readFileSync(p));fn(x);fs.writeFileSync(p,JSON.stringify(x,null,2)+'\n');};
  if(name==='reported-total')edit('cases/E07.json',x=>x.after.state.apps.guarded.total='14');
  if(name==='source-message')edit('messages.json',x=>x[0].message.payload='0x12345678');
  if(name==='destination-input'){const x=JSON.parse(fs.readFileSync(path.join(target,'deliveries.json')));edit(x[0].destination_transaction,r=>r.input.data=r.input.data.slice(0,-2)+'ff');}
  const run=cp.spawnSync(process.execPath,[path.join(ROOT,'extensions/verify.cjs'),target],{cwd:ROOT,encoding:'utf8'});
  const passed=run.status===0;assert.equal(passed,name==='unchanged','Unexpected checker outcome: '+name);
  results.push({control:name,expected:name==='unchanged'?'accept':'reject',observed:passed?'accepted':'rejected',exit_code:run.status,output:(run.stderr||run.stdout).slice(-2000)});
 }
 const result={status:'passed',scope:'Intentional mutations of copied saved records test the checker; these are not chain experiments.',controls:results};
 if(process.argv[3])write(path.resolve(ROOT,process.argv[3]),result);
 console.log(JSON.stringify(result,null,2));
}finally{fs.rmSync(temp,{recursive:true,force:true});}
