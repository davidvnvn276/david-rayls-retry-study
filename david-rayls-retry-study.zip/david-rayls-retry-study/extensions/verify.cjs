'use strict';
// Separate saved-record checker. Does not execute the EVM or authenticate a live chain.
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const {ethers}=require('ethers');
const {ROOT,FILES,COMMIT,sha256,stringify}=require('../scripts/common.cjs');
const directory=process.argv[2];assert(directory,'Usage: node extensions/verify.cjs extension-evidence/run-01');
const dir=path.resolve(ROOT,directory),load=f=>JSON.parse(fs.readFileSync(path.join(dir,f)));
const summary=load('summary.json'),fixture=load('fixture.json'),artifacts=load('compiled-contracts.json'),messages=load('messages.json'),deliveries=load('deliveries.json');
assert.equal(summary.source_commit,COMMIT);assert.deepEqual(summary.physical_chain_ids,[10101,20202]);assert.equal(summary.manual_delivery,true);
for(const [f,hash] of Object.entries(load('execution-inputs.json').sha256))assert.equal(sha256(fs.readFileSync(path.join(ROOT,f))),hash,'Execution input changed: '+f);
assert.equal(sha256(fs.readFileSync(path.join(dir,'solc-input.json'))),load('build-provenance.json').input_sha256);
const compilerInput=load('solc-input.json');for(const [name,source] of Object.entries(compilerInput.sources)){
 const local=fs.existsSync(path.join(ROOT,name))?path.join(ROOT,name):path.join(ROOT,'node_modules',name);
 assert.equal(fs.readFileSync(local,'utf8'),source.content,'Compiled source bytes differ: '+name);
}
const ifaceFor=h=>new ethers.Interface(artifacts[h.file][h.name||h.contract].abi);
const sourceEndpoint=ifaceFor(fixture.source.endpoint),destinationEndpoint=ifaceFor(fixture.destination.endpoint),executor=ifaceFor(fixture.destination.executor);
const sourceEventParam=sourceEndpoint.getEvent('MessageDispatched').inputs[4];
const journals={};let txBindings=0,getterBindings=0;
for(const phase of ['source','destination']){
 const journal=fs.readFileSync(path.join(dir,'rpc-'+phase+'.jsonl'),'utf8').trim().split('\n').map(JSON.parse);journals[phase]=journal;
 const index=load('transaction-index-'+phase+'.json');
 for(const item of index){const record=load(item.file),hash=record.receipt.transactionHash;
  assert.equal(hash,item.hash);assert.equal(record.receipt.status,item.status);assert.equal(record.mined.hash,hash);
  const submit=journal.find(x=>x.method==='eth_sendTransaction'&&x.result===hash);assert(submit,'Missing raw submission '+hash);assert.deepEqual(submit.params[0],record.input);
  assert.deepEqual(journal.find(x=>x.method==='eth_getTransactionReceipt'&&x.params[0]===hash).result,record.receipt);
  assert.deepEqual(journal.find(x=>x.method==='eth_getTransactionByHash'&&x.params[0]===hash).result,record.mined);
  assert.equal(record.mined.from.toLowerCase(),record.input.from.toLowerCase());assert.equal(record.mined.input,record.input.data);assert.equal(BigInt(record.mined.chainId),BigInt(phase==='source'?10101:20202));
  assert.equal(record.mined.type,'0x2');assert(BigInt(record.mined.maxPriorityFeePerGas)<=BigInt(record.mined.maxFeePerGas));
  if(record.receipt.status==='0x0'){
   const parent=ethers.toQuantity(BigInt(record.receipt.blockNumber)-1n),failed=journal.find(x=>x.method==='eth_call'&&x.params[1]===parent&&JSON.stringify(x.params[0])===JSON.stringify(record.input)&&x.error);
   assert(failed,'Missing exact parent-state error '+hash);const raw=typeof failed.error.data==='string'?failed.error.data:failed.error.data?.result;assert.equal(raw,record.revert.raw);assert.equal(record.receipt.logs.length,0);
  }txBindings++;
 }
}
const byId=new Map();
for(const m of messages){assert(!byId.has(m.id));byId.set(m.id,m);const record=load(m.source_transaction);
 const parsed=record.receipt.logs.map(l=>{try{return sourceEndpoint.parseLog(l)}catch{return null}}).find(e=>e?.name==='MessageDispatched'&&e.args.messageId===m.id);assert(parsed);
 const decoded=sourceEndpoint.decodeFunctionData('send(uint256,address,bytes)',record.input.data);assert.equal(decoded[0],20202n);assert.equal(decoded[1].toLowerCase(),m.to.toLowerCase());assert.equal(decoded[2],m.message.payload);
 const encoded=ethers.AbiCoder.defaultAbiCoder().encode([sourceEventParam],[m.message]);
 const id=ethers.keccak256(ethers.AbiCoder.defaultAbiCoder().encode(['address','uint256','address','uint256','address','bytes'],[fixture.source.sender.address,10101,m.from,20202,m.to,encoded]));assert.equal(id,m.id);
 assert.equal(m.message.messageMetadata.ignoresNonce,true);assert.equal(record.receipt.transactionHash,m.source_hash);assert.equal(record.input.from.toLowerCase(),m.from.toLowerCase());
 const decodedEncoded=ethers.AbiCoder.defaultAbiCoder().encode([sourceEventParam],[parsed.args.data]);assert.equal(decodedEncoded,encoded);
}
let committed=0;const committedIds=new Set(),effects=[];
for(const d of deliveries){const m=byId.get(d.messageId);assert(m);const record=load(d.destination_transaction);
 const wanted=destinationEndpoint.encodeFunctionData('receivePayload',[d.sourceChainId,m.from,m.to,m.message,m.id]);assert.equal(record.input.data,wanted);assert.equal(record.input.from.toLowerCase(),fixture.deliverer.toLowerCase());
 if(d.controlled_receiver_input){assert.equal(d.label,'E11-wrong-chain');assert.equal(d.sourceChainId,30303);}else assert.equal(d.sourceChainId,10101);
 const executedLogs=record.receipt.logs.filter(l=>l.address.toLowerCase()===fixture.destination.executor.address.toLowerCase()).map(l=>{try{return executor.parseLog(l)}catch{return null}}).filter(e=>e?.name==='MessageIdExecuted');
 if(record.receipt.status==='0x1'){assert.equal(executedLogs.length,1);const e=executedLogs[0];assert.equal(e.args.messageId,m.id);assert.equal(e.args.fromChainId,10101n);assert(!committedIds.has(m.id),'Repeated successful ID');committedIds.add(m.id);committed++;}else assert.equal(executedLogs.length,0);
 for(const l of record.receipt.logs){const h=Object.values(fixture.apps).find(a=>a.address.toLowerCase()===l.address.toLowerCase());if(h){const e=ifaceFor(h).parseLog(l);effects.push({name:e.name,id:e.args.messageId,request:e.args.requestId,value:e.args.total??e.args.value,amount:e.args.amount});assert.equal(e.args.messageId,m.id);}}
}
const cases=fs.readdirSync(path.join(dir,'cases')).sort().map(f=>load('cases/'+f));assert.equal(cases.length,16);
for(const c of [...cases, {id:'final',after:load('final-state.json')}])for(const side of ['before','after']){
 const snap=c[side];if(!snap)continue;
 assert(journals.destination.some(x=>x.method==='eth_getBlockByNumber'&&x.result?.number===snap.block_number&&x.result?.hash===snap.block_hash),'Missing captured block');
 for(const r of snap.reads){const h={file:r.file,contract:r.contract},iface=ifaceFor(h),input={to:r.address,data:iface.encodeFunctionData(r.fn,r.args)};
  const raw=journals.destination.find(x=>x.method==='eth_call'&&x.params[1]===snap.block_number&&x.params[0].to?.toLowerCase()===input.to.toLowerCase()&&x.params[0].data===input.data&&!x.error);assert(raw,'Missing same-block getter');assert.equal(raw.result,r.raw);
  const v=iface.decodeFunctionResult(r.fn,r.raw)[0],plain=typeof v==='bigint'?v.toString():v;assert.equal(plain,r.value);
  const app=Object.entries(fixture.apps).find(([,a])=>a.address.toLowerCase()===r.address.toLowerCase());
  if(app){const key=r.fn==='processed'?(r.args[0]===fixture.requests.shared?'sharedProcessed':'retryProcessed'):r.fn;assert.equal(snap.state.apps[app[0]][key],plain);}
  else if(r.fn==='executed')assert.equal(snap.state.executed[r.args[0]],plain);else if(r.fn==='getInboundNonce')assert.equal(snap.state.inboundNonce,plain);
  getterBindings++;
 }
}
const after=id=>cases.find(x=>x.id===id).after.state;
assert.equal(after('E01').apps.recovery.total,'0');assert.equal(after('E01').apps.recovery.retryProcessed,false);assert.equal(after('E02').apps.recovery.total,'5');assert.equal(after('E02').apps.recovery.retryProcessed,true);assert.equal(after('E03').apps.recovery.total,'5');
assert.equal(after('E05').apps.plain.total,'14');assert.equal(after('E07').apps.guarded.total,'7');assert.equal(after('E07').apps.guarded.calls,'1');assert.equal(after('E10').apps.guarded.total,'15');assert.equal(after('E13').apps.forward.value,'12');assert.equal(after('E14').apps.reverse.value,'21');assert.equal(after('E15').apps.sequenced.value,'0');assert.equal(after('E16').apps.sequenced.value,'12');assert.equal(after('E16').apps.sequenced.nextSequence,'3');assert.equal(after('E16').inboundNonce,'0');
assert.equal(effects.filter(e=>e.name==='DuplicateIgnored').length,1);assert.equal(effects.filter(e=>e.name==='RequestApplied').length,5);assert.equal(effects.filter(e=>e.name==='DigitApplied').length,6);
for(const iso of fixture.isolation){assert.equal(iso.source_code,'0x');assert(journals.source.some(x=>x.method==='eth_getCode'&&x.params[0].toLowerCase()===iso.address.toLowerCase()&&x.result==='0x'));assert(journals.destination.some(x=>x.method==='eth_getCode'&&x.params[0].toLowerCase()===iso.address.toLowerCase()&&ethers.keccak256(x.result)===iso.destination_runtime_keccak256));}
const sourceIndex=load('transaction-index-source.json'),destIndex=load('transaction-index-destination.json');assert.equal(summary.transactions,sourceIndex.length+destIndex.length);assert.equal(summary.source_messages,messages.length);assert.equal(summary.destination_delivery_attempts,deliveries.length);assert.equal(summary.consumed_message_ids,committedIds.size);assert.equal(summary.reverted_transactions,[...sourceIndex,...destIndex].filter(x=>x.status==='0x0').length);
const result={status:'passed',scope:'Saved-record consistency and source/event/state bindings; no EVM execution or production authentication.',cases:cases.length,transaction_rpc_bindings:txBindings,getter_bindings:getterBindings,source_message_id_reconstructions:messages.length,delivery_calldata_bindings:deliveries.length,committed_message_ids:committed,application_effect_events:effects.filter(e=>e.name!=='DuplicateIgnored').length,duplicate_ignored_events:1,physical_chain_ids:[10101,20202]};
console.log(stringify(result));
