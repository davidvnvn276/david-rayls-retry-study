# Official Rayls components: execution and integration boundaries

This supplement records what could actually be executed after the local retry study. It does **not** claim a running end-to-end relayer, authenticated proof transport or a production deployment check.

## Results

| Check | Observed result |
|---|---|
| Exact Go toolchain | Go 1.26.4 installed; official archive SHA-256 matched |
| Official proof/calldata unit tests | Four packages passed; 15 top-level tests, including mocks and negative cases |
| Official private relayer | Native build succeeded; command-line help executed |
| Official full-stack CLI | Build succeeded; `init --full --no-blockscout` generated configuration, then failed the Docker availability check |
| Source EVM | 40 original source transactions re-executed with matching transaction and block hashes |
| Official Go calldata generator | 14 preserved source messages generated calldata matching 18 recorded destination calls |
| Fresh type-0 source transaction | Official inclusion-proof generation passed; verified value equalled the signed transaction; changed root rejected |
| Fresh type-2 source transaction | Official generator reconstructed a different transaction root and could not generate a proof for the canonical root |
| Separate Node check | Keccak/RLP independently reconstructed both canonical one-transaction roots and the legacy-style root explaining the type-2 mismatch |
| Public mainnet RPC attempt | `eth_chainId` returned HTTP 403; no chain state was obtained |
| Production private-network mapping | Not established; no verified RPC/registry/deployment manifest was obtained |

These are different observations, not a count of independent experiments. Build success, unit tests, local RPC execution and a full service run must remain distinct.

## Pinned sources

- Relayer: `raylsnetwork/rayls-sovereign-relayer`, commit `b01b427de4cfc2ac66e75eba0d5070b73a3b137c`.
- CLI: `raylsnetwork/rayls-sovereign-cli`, commit `c356f9211b168c643d8f25d26df709af7dc4dd92`.
- `sources/provenance.json` lists 807 relayer and 70 CLI Git blob identities.
- `sources/relayer/study_driver/main.go` is an **authored adapter**, additional to those unmodified upstream files. It calls the official `proofgen.New`, `proofs.VerifyProof` and destination calldata generator.
- The Node fixture inputs come from the revised local retry study. `study-input/lineage.json` identifies that archive.

No source fix was applied to make the observed type-2 result pass.

## 1. Extract and inspect the archive

Extract the complete `david-official-component-check` folder. Open a terminal in that folder and run:

```bash
python check_integrity.py
```

Python 3 standard library is sufficient. This checks the distributed manifest and pinned upstream Git blobs. It establishes byte identity, not production authenticity.

## 2. Install locked Node dependencies

The recorded environment used Linux, Node 24.19.0, npm 11.9.0 and Go 1.26.4.

```bash
npm ci --ignore-scripts --no-audit --no-fund
```

On PowerShell, `npm.cmd` can be used if `npm.ps1` is blocked. Native Windows execution was not tested.

The package reuses the original study's unchanged Node package metadata and lockfile. Ganache's optional native-uWS warning can fall back to its Node implementation. The supplied data are not a performance benchmark.

## 3. Verify the saved result without Go or an RPC

```bash
node verify_saved.cjs evidence/run-02
```

Expected: 877 upstream source files, 40 source transaction/block bindings, 18 calldata bindings, type-0 root agreement and type-2 root disagreement.

This separate checker verifies Keccak/RLP for the two inspected **single-transaction blocks at index zero**. It is not a generic MPT verifier. The recorded Go binary fingerprint is retained, but binaries are omitted from this source distribution; that fingerprint is not independently rebuilt by this saved-record command.

## 4. Build and run the actual Go components

Install Go 1.26.4, then check:

```bash
go version
```

Run compilation commands sequentially. From the project root:

```bash
mkdir -p build
cd sources/relayer
go test -json -p 2 ./cryptography/proofs ./private-relayer/dest/txgen ./private-relayer/proof ./private-relayer/proofgen
go build -p 2 -o ../../build/relayer ./private-relayer/cmd
go build -p 2 -o ../../build/study-driver ./study_driver
cd ../..
```

On PowerShell, create the folder with `New-Item -ItemType Directory -Force build`. Name the binaries `relayer.exe` and `study-driver.exe` when building for Windows; the supplied Node runner currently expects the Linux binary name. This is not claimed as a tested Windows command sequence.

Go modules are resolved using the pinned upstream `go.mod` and `go.sum`. Internet access is needed for the first dependency download. Do not remove integrity checks or change versions merely to obtain a passing result.

## 5. Run the source-EVM and Go component comparison again

Choose a fresh output folder:

```bash
node run_native.cjs --output runs/my-component-check
node verify_saved.cjs runs/my-component-check
```

The runner:

1. Captures input hashes before execution.
2. Starts one fresh Ganache source EVM on loopback, chain ID 10101.
3. Re-executes the 40 preserved source transactions and checks their transaction/block hashes.
4. Dispatches two additional source messages through the deployed Endpoint: one explicit valid-fee type-2 transaction and one legacy type-0 transaction.
5. Calls the actual official proof generator over local HTTP RPC for each fresh transaction.
6. Uses the actual official destination generator to encode the 14 preserved messages, then compares its output with the 18 historical destination calls.
7. Saves inputs, receipts, RPC journals, proof output and the component summary, then stops the local server.

No new destination EVM execution is performed here: the 18 destination calls are preserved observations from the main study. The proof component performs only read-only RPC methods. All state changes are on the new local source EVM with synthetic balances.

The fresh type-2 control sets priority fee <= maximum fee explicitly. Some original Ganache fixture transactions have fee-cap combinations a stricter Ethereum client would reject. Replaying those original inputs checks the existing EVM-state record; it is **not** evidence of production transaction admission. The compatibility comparison uses the two fresh explicitly configured controls.

## 6. Understand the encoding finding

For the fresh type-2 transaction, the separate Node checker reconstructs its canonical transaction trie root from the typed signed bytes. It matches the source block's root.

The pinned Go `cryptography/proofs/transaction.go` reconstructs transaction values as the nine-field legacy RLP structure. The Node checker independently performs that conversion for the type-2 input and obtains the exact different root reported by the Go generator. The type-0 control's reconstructed root agrees with its source block, and its proof verifies.

This establishes a local encoding compatibility boundary for these inputs and this source snapshot. It does **not** establish a live Axyl result, a production exploit, loss of funds, or behavior of every release. Do not describe it as a confirmed production vulnerability.

The header-submission boundary is also untested. The pinned `Proofs.sol` requires 21 post-Prague header fields, whereas this source fixture uses Ganache's Shanghai setting. No successful header submission, Hub proof acceptance or consensus certificate check is claimed.

## 7. What is still needed for a full run

See `NEXT_STEPS.md`. The official full local topology requires a Docker-capable host and the actual node, Hub, CTS, database and messaging services. Enygma proof generation additionally needs the proving service and development keys. A native component test does not replace those services.

For production read-only verification, obtain a deployment manifest identifying the exact private-network chain/RPC, registry and proxy/implementation addresses, and the linked source release. No production private key is needed for read-only verification. A private relayer cannot be operated against an institutional network merely by downloading public code.

## Files

- `REVIEW.md`: interpretation and limits.
- `evidence/run-02/`: final checked source-EVM/component execution.
- `study-input/`: retained source and destination observations used as inputs.
- `execution-logs/`: actual official build/test/help/full-init outputs.
- `public-rpc/selection-rpc.json`: failed public RPC observation, preserved as an unavailable reading.
- `sources/`: upstream source and explicit authored Go adapter.
- `SHA256SUMS.txt`: every distributed file except itself.

The larger main article and its figures are separate. This supplement does not silently replace them or publish anything. No RP score is guaranteed.
