# Requirements for the remaining tests

## Full local relayer and transport

Use a host where Docker and Compose can run. The documented local demo needs no funded account. Keep all services bound to loopback and use the development keys only within this isolated setup.

Before execution, identify a coordinated component version and preserve image digests. A source commit's package metadata does not itself map every pulled image to that source. The current source-mode CLI also documents the need to fetch Gnark's Git-LFS proving files when testing Enygma.

The expected topology includes two Sovereign nodes, the Private Network Hub, CTS instances, PostgreSQL, NATS and relayers. Follow the official CLI guide and inspect each health check and deployment record before sending a test message. The example full-stack command attempted in this review was:

```bash
rayls init --full --no-blockscout
```

This command did not complete in the review host. A successful future run should capture source dispatch, proof generation, header registration, encrypted Hub storage, destination decryption, transaction receipt and application state. Test failure/recovery through the actual service queues rather than a coordinator calling the destination directly.

Resolve or explain the transaction-envelope compatibility boundary before treating the current source fixture as accepted by the official proof path. Do not edit source or change transaction type silently to obtain a passing trace.

## Production read-only mapping

Obtain from an authoritative deployment reference:

- the network environment and chain IDs;
- a permitted read-only RPC or Explorer;
- DeploymentProxyRegistry and Endpoint proxy addresses;
- the implementation addresses/runtime hashes and source release;
- a permitted transaction example, if one can be disclosed publicly;
- what information may be published.

No production signing key, seed phrase, CTS secret or KMS credential is required to request these read-only references. Do not run private-network transactions or deploy infrastructure on somebody else's network without authorization.
