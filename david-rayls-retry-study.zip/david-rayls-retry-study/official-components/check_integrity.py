from pathlib import Path
import hashlib,json
root=Path(__file__).resolve().parent
lines=(root/'SHA256SUMS.txt').read_text().splitlines()
for line in lines:
 digest,rel=line.split('  ',1);path=(root/rel).resolve();assert path.is_relative_to(root)
 assert hashlib.sha256(path.read_bytes()).hexdigest()==digest,rel
count=0
for repo,info in json.loads((root/'sources/provenance.json').read_text())['repositories'].items():
 for item in info['files']:
  data=(root/'sources'/repo/item['path']).read_bytes();assert len(data)==item['bytes']
  assert hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()==item['git_blob_sha1']
  count+=1
print('PASS',len(lines),'manifest files and',count,'upstream Git blobs. Scope: file identity, not production authenticity.')
