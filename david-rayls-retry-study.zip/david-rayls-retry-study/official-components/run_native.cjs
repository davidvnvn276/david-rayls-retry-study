'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),{spawn}=require('node:child_process');
const base=__dirname;
const ganache=require('ganache');
const {ethers}=require('ethers');
const {eventPlain}=require('./study_helpers/harness.cjs');
const evidence=path.join(base,'study-input');
const outputIndex=process.argv.indexOf('--output');
const outputArg=outputIndex>=0?process.argv[outputIndex+1]:'runs/my-check';
if(!outputArg)throw Error('Supply an output directory');
const out=path.resolve(base,outputArg);
assert(out.startsWith(base+path.sep),'Output must be inside this project');
assert(!fs.existsSync(out),'Choose a fresh component evidence directory');fs.mkdirSync(out,{recursive:true});
save('execution-inputs.json',{captured_before_execution:true,node:process.version,source_commit:'b01b427de4cfc2ac66e75eba0d5070b73a3b137c',sha256:Object.fromEntries(['run_native.cjs','sources/relayer/study_driver/main.go','sources/relayer/go.mod','sources/relayer/go.sum','build/study-driver','package.json','package-lock.json','study-input/messages.json','study-input/deliveries.json','study-input/fixture.json','study-input/endpoint-abi.json','study_helpers/harness.cjs','study_helpers/common.cjs'].map(f=>[f,require('node:crypto').createHash('sha256').update(fs.readFileSync(path.join(base,f))).digest('hex')]))});
function save(name,value){fs.writeFileSync(path.join(out,name),JSON.stringify(value,null,2)+'\n');}
function runDriver(args,name){return new Promise((resolve,reject)=>{
 const p=spawn(path.join(base,'build/study-driver'),args,{cwd:base});let stdout='',stderr='';
 p.stdout.on('data',x=>stdout+=x);p.stderr.on('data',x=>stderr+=x);
 p.on('error',reject);p.on('exit',code=>{
  fs.writeFileSync(path.join(out,name+'.stdout'),stdout);fs.writeFileSync(path.join(out,name+'.stderr'),stderr);
  if(code!==0)return reject(Error(name+' exited '+code+': '+stderr.slice(-1500)));
  const value=JSON.parse(stdout);save(name+'.json',value);resolve(value);
 });
});}
async function main(){
 const server=ganache.server({logging:{quiet:true},wallet:{deterministic:true,totalAccounts:6,defaultBalance:1000},chain:{chainId:10101,networkId:10101,hardfork:'shanghai',time:new Date('2026-01-01T00:00:00Z')},miner:{blockGasLimit:'0x2625a00',timestampIncrement:1}});
 await server.listen(0,'127.0.0.1');
 const rpc='http://127.0.0.1:'+server.address().port;
 try{
  const files=fs.readdirSync(path.join(evidence,'source/transactions-source')).sort();const replay=[];
  for(const file of files){
   const original=JSON.parse(fs.readFileSync(path.join(evidence,'source/transactions-source',file)));
   const hash=await server.provider.request({method:'eth_sendTransaction',params:[original.input]});
   const receipt=await server.provider.request({method:'eth_getTransactionReceipt',params:[hash]});
   assert.equal(hash,original.receipt.transactionHash);assert.equal(receipt.blockHash,original.receipt.blockHash);assert.equal(receipt.status,original.receipt.status);
   replay.push({file,hash,receipt});
  }
  save('source-replay.json',{scope:'Fresh source-only EVM execution; 40 transaction and block hashes match the retained run. Not a second destination run or production observation.',chain_id:10101,transactions:replay});
  const messages=JSON.parse(fs.readFileSync(path.join(evidence,'messages.json')));
  const typedTemplate=JSON.parse(fs.readFileSync(path.join(evidence,'source/transactions-source',files[files.length-1])));
  const typedInput={...typedTemplate.input,type:'0x2',maxFeePerGas:'0xb2d05e00',maxPriorityFeePerGas:'0x3b9aca00'};
  const typedHash=await server.provider.request({method:'eth_sendTransaction',params:[typedInput]});
  const typedReceipt=await server.provider.request({method:'eth_getTransactionReceipt',params:[typedHash]});assert.equal(typedReceipt.status,'0x1');
  const typedMined=await server.provider.request({method:'eth_getTransactionByHash',params:[typedHash]});assert.equal(typedMined.type,'0x2');assert(BigInt(typedMined.maxPriorityFeePerGas)<=BigInt(typedMined.maxFeePerGas));
  save('typed-source-transaction.json',{input:typedInput,receipt:typedReceipt,mined:typedMined});
  const typed=await runDriver(['--mode','proof','--rpc',rpc,'--tx',typedHash,'--journal',path.join(out,'typed-proof-rpc.jsonl')],'typed-source-proof');
  const original=JSON.parse(fs.readFileSync(path.join(evidence,'source/transactions-source',files[files.length-1])));
  const input={...original.input,type:'0x0',gasPrice:'0x77359400'};
  const hash=await server.provider.request({method:'eth_sendTransaction',params:[input]});
  const receipt=await server.provider.request({method:'eth_getTransactionReceipt',params:[hash]});assert.equal(receipt.status,'0x1');
  const mined=await server.provider.request({method:'eth_getTransactionByHash',params:[hash]});assert.equal(mined.type,'0x0');
  const fixture=JSON.parse(fs.readFileSync(path.join(evidence,'fixture.json')));
  const endpoint=fixture.source.endpoint,iface=new ethers.Interface(JSON.parse(fs.readFileSync(path.join(evidence,'endpoint-abi.json'))));
  const event=receipt.logs.map(l=>{try{return iface.parseLog(l)}catch{return null}}).find(l=>l?.name==='MessageDispatched');assert(event);
  const args=eventPlain(event).args;
  const extra={id:args.messageId,from:args.from,to:args.to,sourceChainId:10101,message:args.data,source_hash:hash};
  save('legacy-source-transaction.json',{input,receipt,mined,message:extra});
  const legacy=await runDriver(['--mode','proof','--rpc',rpc,'--tx',hash,'--journal',path.join(out,'legacy-proof-rpc.jsonl')],'legacy-source-proof');
  assert.equal(legacy.status,'passed');assert.equal(legacy.verified_value_equals_canonical_transaction,true);
  const messagePath=path.join(out,'source-event-inputs.json');fs.writeFileSync(messagePath,JSON.stringify(messages,null,2)+'\n');
  const encoded=await runDriver(['--mode','encode','--messages',messagePath],'official-calldata');
  const byId=new Map(encoded.messages.map(x=>[x.message_id,x]));let bindings=0;
  const deliveries=JSON.parse(fs.readFileSync(path.join(evidence,'deliveries.json')));
  for(const d of deliveries){
   const record=JSON.parse(fs.readFileSync(path.join(evidence,d.destination_transaction)));
   assert.equal(byId.get(d.messageId).calldata,record.input.data);assert.equal(byId.get(d.messageId).ignores_nonce,true);bindings++;
  }
  const result={status:'passed',source_commit:'b01b427de4cfc2ac66e75eba0d5070b73a3b137c',source_replayed_transactions:replay.length,additional_controlled_source_transactions:2,typed_control_fee_caps_valid:true,matching_source_transaction_and_block_hashes:true,source_message_inputs:messages.length,official_go_calldata_bindings_to_preserved_destination_transactions:bindings,typed_source_transaction_type:typed.transaction_type,typed_generator_root_matches_source_root:typed.generator_root_matches_source_root,typed_generator_root:typed.generator_reconstructed_trie_root,typed_canonical_root:typed.transactions_root,typed_source_proof_status:typed.status,typed_source_proof_error:typed.generation_error||null,legacy_source_transaction_type:legacy.transaction_type,legacy_generator_root_matches_source_root:legacy.generator_root_matches_source_root,legacy_source_proof_status:legacy.status,legacy_proof_value_matches_signed_transaction:true,legacy_wrong_root_rejected:true,scope:'Source EVM re-execution plus actual official Go proof/calldata components. No official daemon, CTS, Hub proof submission, transport authentication, Axyl node or production deployment was run.'};save('component-check-result.json',result);console.log(JSON.stringify(result,null,2));
 }finally{await server.close();}
}
main().catch(e=>{console.error(e);process.exitCode=1});
