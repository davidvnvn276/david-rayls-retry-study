# Review: what running the official components established

## Outcome

The official relayer can be compiled in this environment after installing Go. Its proof and calldata components were executed. The complete service topology could not start because Docker is absent, no Docker socket is available, and a rootless user-namespace probe was denied by the host.

The actual CLI initialization produced a compose file and then failed its Docker check. This is an environment limitation, not an observed Rayls production failure.

## Completed execution

- Official Go 1.26.4 archive identity checked against go.dev release metadata.
- Four official unit-test packages passed: cryptography/proofs, private-relayer/dest/txgen, private-relayer/proof and private-relayer/proofgen. Fifteen top-level tests include mocks; they are not fifteen integration environments.
- Official private-relayer binary built and its help command ran. No initialized relayer daemon is claimed.
- Official CLI built at its own pinned commit and the full-local initialization command was attempted.
- Forty source EVM transactions were re-executed, preserving the original transaction/block hashes.
- Actual official Go calldata generation matched 18 retained destination transaction inputs for 14 source messages.
- Actual official Go proof generation over local HTTP RPC passed for one freshly emitted type-0 transaction, with signed-transaction value agreement and a wrong-root control.
- A freshly emitted, explicitly valid-fee type-2 transaction failed generation against its source root. The separate Node checker reconstructs the source root and the different legacy-style root, explaining the mismatch without modifying upstream code.

## Scope of the compatibility result

These are two local source transactions with one transaction per block. The type-2 control explicitly uses a priority cap below the maximum fee. It is separate from the older fixture's default fee construction.

The pinned proof library converts transaction objects into a legacy nine-field RLP value. Applying the same conversion independently to the type-2 signed envelope reproduces the observed mismatched root. Type-0 remains a positive control.

This is not a completed private-network transport test. The source ledger is Ganache, not Axyl; no encrypted Hub submission, CTS delivery, source consensus certificate, destination daemon or production deployment was exercised. Header submission is not covered; the published Proofs contract's post-Prague format exceeds the Shanghai fixture's header format.

The existing article's contract-level retry, deduplication and ordering measurements remain local measurements. This supplementary check does not justify relabelling them as end-to-end results. It supplies a concrete reason to keep that boundary visible.

## Production

The first attempted public RPC read returned HTTP 403 before chain ID was retrieved. It establishes an unavailable observation from this environment, not zero state or a globally unavailable RPC.

The reviewed primary documentation explains a local demo topology and directs production operators to Rayls. This review did not obtain a verified institutional deployment RPC, registry address or release-to-runtime mapping. The Public Chain RPC alone would not establish the private-chain Endpoint deployment under study.

## Publication implications

Keep this as a clearly labelled supplement until the complete integration environment is run and the intended deployment is identified. Do not add claims of production vulnerability, automatic recovery, proof-path completion or real payment effects. Additional unit tests, checker comparisons and build success do not guarantee 9 RP.

Primary references:

- https://docs.rayls.com/docs/installing-a-private-network
- https://docs.rayls.com/docs/running-a-private-network
- https://docs.rayls.com/docs/deploying-rayls-sovereign
- https://github.com/raylsnetwork/rayls-sovereign-relayer/tree/b01b427de4cfc2ac66e75eba0d5070b73a3b137c
- https://github.com/raylsnetwork/rayls-sovereign-cli/tree/c356f9211b168c643d8f25d26df709af7dc4dd92
