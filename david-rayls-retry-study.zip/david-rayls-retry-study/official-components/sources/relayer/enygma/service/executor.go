package service

//go:generate moq --skip-ensure --pkg service_test -out executor_mock_test.go . executorTracer executorEnygmaBatcher executorProofGenerator executorEnygmaHistoryRepository executorEnygmaClient ExecutorDvpIntegrationClient executorKeysClient executorCommitmentCalculator

import (
	"context"
	"errors"
	"fmt"
	"log/slog"
	"math/big"
	"time"

	"github.com/ethereum/go-ethereum/common"
	"github.com/raylsnetwork/rayls-sovereign-relayer/contractclient"
	keyspb "github.com/raylsnetwork/rayls-sovereign-relayer/cts/gen/proto/keys"
	"github.com/raylsnetwork/rayls-sovereign-relayer/dvp"
	"github.com/raylsnetwork/rayls-sovereign-relayer/enygma"
	"github.com/raylsnetwork/rayls-sovereign-relayer/faultinjector"
	telemetry "github.com/raylsnetwork/rayls-sovereign-relayer/otel"
	repository "github.com/raylsnetwork/rayls-sovereign-relayer/private-relayer/repository"
	"github.com/raylsnetwork/rayls-sovereign-relayer/txsim"
	"github.com/raylsnetwork/rayls-sovereign-relayer/txutil"
	"github.com/raylsnetwork/rayls-sovereign-relayer/types"
	"go.opentelemetry.io/otel/attribute"
	"go.opentelemetry.io/otel/codes"
	"go.opentelemetry.io/otel/trace"
	"google.golang.org/grpc"
)

const millisPerSecond = txutil.MillisPerSecond

type ExecutorConfig struct {
	DefaultContextTimeout time.Duration
}

type executorTracer interface {
	Start(ctx context.Context, spanName string, opts ...trace.SpanStartOption) (context.Context, trace.Span)
}

type executorEnygmaBatcher interface {
	CreateBatchesWithAnonimity(
		ctx context.Context,
		resourceId string,
		blockNumber *big.Int,
		txsByChainID map[string][]*types.EnygmaTransferBatchTx,
	) ([]*types.EnygmaTransferBatch, error)
}

type executorProofGenerator interface {
	GenerateTransferProof(
		ctx context.Context,
		params enygma.TransferProofParams,
	) (*types.EnygmaProofResponse, []*types.Point, []*big.Int, []*big.Int, error)
	GenerateDepositProof(
		ctx context.Context,
		params enygma.DepositProofParams,
	) (*types.EnygmaProofResponse, []*types.Point, []*big.Int, []*big.Int, error)
	GenerateWithdrawProof(
		ctx context.Context,
		params enygma.WithdrawProofParams,
	) (*types.EnygmaProofResponse, []*types.Point, []*big.Int, []*big.Int, error)
}

type executorEnygmaHistoryRepository interface {
	InsertEnygmaHistory(ctx context.Context, history types.EnygmaHistory) error
}

type executorEnygmaClient interface {
	SupplyUpdate(
		ctx context.Context,
		batchID string,
		tokenAddress common.Address,
		senderChainId *big.Int,
		blockNumber *big.Int,
		update types.EnygmaSupplyUpdate,
	) error
	TransferBatch(
		ctx context.Context,
		batchID string,
		tokenAddress common.Address,
		batches []*types.EnygmaTransferBatch,
		proof *types.EnygmaProofResponse,
		blockNumber *big.Int,
	) error
	GetDvpIntegrationContractAddress(ctx context.Context, tokenAddress common.Address) (common.Address, error)
}

type ExecutorDvpIntegrationClient interface {
	Deposit(ctx context.Context, req contractclient.DvpIntegrationTxRequest) error
	Withdraw(ctx context.Context, req contractclient.DvpIntegrationTxRequest, jsProof *dvp.ProofReceipt) error
}

type executorKeysClient interface {
	GetPaymentSpendKey(ctx context.Context, in *keyspb.GetPaymentSpendKeyRequest, opts ...grpc.CallOption) (*keyspb.PaymentSpendKeyResponse, error)
}

type executorCommitmentCalculator interface {
	CalculatePaymentCommitment(spendPK, salt, paymentAmount *big.Int, tokenAddress string) (*big.Int, error)
}

type EnygmaExecutor struct {
	conf                    ExecutorConfig
	tracer                  executorTracer
	batcher                 executorEnygmaBatcher
	proofGen                executorProofGenerator
	enygmaHistoryRepository executorEnygmaHistoryRepository
	keysClient              executorKeysClient
	enygmaClient            executorEnygmaClient
	enygmaIntegrationClient ExecutorDvpIntegrationClient
	commitmentCalculator    executorCommitmentCalculator
	plChainId               *big.Int
}

func NewEnygmaExecutor(
	conf ExecutorConfig,
	tracer executorTracer,
	batcher executorEnygmaBatcher,
	proofGen executorProofGenerator,
	enygmaHistoryRepository executorEnygmaHistoryRepository,
	keysClient executorKeysClient,
	enygmaClient executorEnygmaClient,
	enygmaIntegrationClient ExecutorDvpIntegrationClient,
	commitmentCalculator executorCommitmentCalculator,
	plChainId *big.Int,
) *EnygmaExecutor {
	return &EnygmaExecutor{
		conf:                    conf,
		tracer:                  tracer,
		batcher:                 batcher,
		proofGen:                proofGen,
		enygmaHistoryRepository: enygmaHistoryRepository,
		keysClient:              keysClient,
		enygmaClient:            enygmaClient,
		enygmaIntegrationClient: enygmaIntegrationClient,
		commitmentCalculator:    commitmentCalculator,
		plChainId:               plChainId,
	}
}

// recordSoftFinalityLatency calculates and records the soft finality latency on the given span.
func (e *EnygmaExecutor) recordSoftFinalityLatency(span trace.Span, batches []*types.EnygmaTransferBatch) {
	if len(batches) == 0 || batches[0].SoftFinalityStartTimestamp <= 0 {
		return
	}

	softFinalityEndTime := time.Now().UnixMilli()
	softFinalityLatencyMillis := softFinalityEndTime - batches[0].SoftFinalityStartTimestamp
	latencySeconds := float64(softFinalityLatencyMillis) / millisPerSecond

	span.SetAttributes(
		attribute.Float64(telemetry.ATTR_SOFT_FINALITY_LATENCY, latencySeconds),
	)
}

func (e *EnygmaExecutor) ExecuteEnygmaSupplyUpdate(
	ctx context.Context,
	batchID string,
	resourceId string,
	blockNumber uint64,
	supplyUpdate types.EnygmaSupplyUpdate,
	enygmaAddress common.Address,
) error {
	ctx, span := e.tracer.Start(ctx, telemetry.SPAN_INITIATE_ENYGMA_SUPPLY_UPDATE)
	defer span.End()

	span.SetAttributes(
		attribute.String(telemetry.ATTR_RESOURCE_ID, resourceId),
		attribute.String(telemetry.ATTR_ENYGMA_SUPPLY_UPDATE_TYPE, supplyUpdate.Type.String()),
		attribute.String(telemetry.ATTR_AMOUNT, supplyUpdate.Amount.String()),
		//nolint:gosec // block numbers are within int range
		attribute.Int(telemetry.ATTR_BLOCK_NUMBER, int(blockNumber)),
	)

	if supplyUpdate.Type != types.EnygmaMint && supplyUpdate.Type != types.EnygmaBurn {
		return fmt.Errorf("invalid supply update type: must be mint or burn, got %d", supplyUpdate.Type)
	}

	blockNumberPrivateHub := new(big.Int).SetUint64(blockNumber)

	txCtx, cancel := context.WithTimeout(ctx, e.conf.DefaultContextTimeout)
	defer cancel()

	err := e.enygmaClient.SupplyUpdate(txCtx, batchID, enygmaAddress, e.plChainId, blockNumberPrivateHub, supplyUpdate)
	if err != nil {
		slog.Error("Error signing Enygma supply update", slog.String("resourceId", resourceId), slog.Any("err", err))
		return fmt.Errorf("signing enygma supply update: %w", err)
	}

	balanceChange := new(big.Int).Set(supplyUpdate.Amount)
	if supplyUpdate.Type == types.EnygmaBurn {
		balanceChange = balanceChange.Neg(balanceChange)
	}

	history := types.EnygmaHistory{
		ResourceId:            resourceId,
		FromChainId:           e.plChainId,
		RFactor:               big.NewInt(0),
		BlockNumberPrivateHub: blockNumberPrivateHub,
		BalanceChange:         balanceChange,
		EventType:             supplyUpdate.Type,
	}

	if err := e.enygmaHistoryRepository.InsertEnygmaHistory(ctx, history); err != nil {
		if !errors.Is(err, repository.ErrAlreadyProcessed) {
			return fmt.Errorf("inserting enygma history: %w", err)
		}
	}

	return nil
}

func (e *EnygmaExecutor) ExecuteEnygmaCrossTransfer(
	parentCtx context.Context,
	batchID string,
	blockNumber uint64,
	resourceId string,
	txsByChainID map[string][]*types.EnygmaTransferBatchTx,
	enygmaAddress common.Address,
) error {
	ctx, span := e.tracer.Start(parentCtx, telemetry.SPAN_INITIATE_ENYGMA_CROSS_TRANSFER)
	defer span.End()

	// Fault injection: drives the orchestrator's revert path under test by making
	// every executor call fail. With ActionError, the retryService exhausts its
	// retries and surfaces the error up, which moves the flow into the revert
	// branch (crossRevertMint on source PL). Used by the resilience suite —
	// Enygma_RevertCrash_DoubleRevertMint.ts in particular requires this hook.
	if err := faultinjector.Check("enygma.service.EnygmaExecutor.ExecuteEnygmaCrossTransfer.before_execute"); err != nil {
		return fmt.Errorf("fault injection at before_execute: %w", err)
	}

	blockNumberPrivateHub := new(big.Int).SetUint64(blockNumber)

	batches, err := e.batcher.CreateBatchesWithAnonimity(ctx, resourceId, blockNumberPrivateHub, txsByChainID)
	if err != nil {
		return fmt.Errorf("creating batches for cross transfer: %w", err)
	}

	senderPLTotalAmount := big.NewInt(0)
	for _, batch := range batches {
		for _, tx := range batch.Transactions {
			senderPLTotalAmount.Add(senderPLTotalAmount, tx.ToAmount)
		}
	}

	anonymityIndex := len(batches)
	proof, _, rValues, _, err := e.proofGen.GenerateTransferProof(
		ctx,
		enygma.TransferProofParams{
			ResourceId:     resourceId,
			AnonymityIndex: anonymityIndex,
			SenderAmount:   senderPLTotalAmount,
			BlockNumber:    blockNumberPrivateHub,
			Batches:        batches,
			TokenAddress:   enygmaAddress,
		},
	)
	if err != nil {
		slog.Error(
			"Error generating Enygma transfer proof",
			slog.String("resourceId", resourceId),
			slog.String("err", err.Error()),
		)
		return fmt.Errorf("generating enygma transfer proof: %w", err)
	}

	senderRFactor := big.NewInt(0)
	for i, batch := range batches {
		batch.ToRValueToAdd = rValues[i]
		if batch.ToChainID.Cmp(e.plChainId) == 0 {
			senderRFactor = rValues[i]
		}
	}

	txCtx, cancel := context.WithTimeout(ctx, e.conf.DefaultContextTimeout)
	defer cancel()

	err = e.enygmaClient.TransferBatch(txCtx, batchID, enygmaAddress, batches, proof, blockNumberPrivateHub)
	if err != nil {
		span.RecordError(err)
		span.SetStatus(codes.Error, telemetry.STATUS_ERROR_FAILED_TO_SEND_TRANSFER_BATCH)
		// Mirror the destination-side programmability log: when the batch reverted on-chain, log the
		// raw revert (0x… selector + args) and a decoded `revert reason` NAME instead of dumping the
		// wrapped stack trace. Keeps programmability reverts readable and consistent across both sides.
		logAttrs := []any{slog.String("resourceId", resourceId), slog.Any("err", err)}
		var revertErr *contractclient.ErrorWithRevertData
		if errors.As(err, &revertErr) {
			logAttrs[1] = slog.String("err", revertErr.Error())
			if decoded, decErr := txsim.DecodeRevertBytes(revertErr.GetRevertData()); decErr == nil && !decoded.IsEmpty() {
				logAttrs = append(logAttrs, slog.String("revert reason", decoded.Reason()))
			}
		}
		slog.Error("Error signing Enygma transfer batch", logAttrs...)
		return fmt.Errorf("signing enygma transfer batch: %w", err)
	}

	history := types.EnygmaHistory{
		ResourceId:            resourceId,
		FromChainId:           e.plChainId,
		RFactor:               senderRFactor,
		BalanceChange:         new(big.Int).Neg(senderPLTotalAmount),
		BlockNumberPrivateHub: blockNumberPrivateHub,
		EventType:             types.EnygmaTransfer,
	}

	if err := e.enygmaHistoryRepository.InsertEnygmaHistory(ctx, history); err != nil {
		if !errors.Is(err, repository.ErrAlreadyProcessed) {
			return fmt.Errorf("inserting enygma history: %w", err)
		}
	}

	e.recordSoftFinalityLatency(span, batches)

	span.SetStatus(codes.Ok, telemetry.STATUS_SUCCESS_ENYGMA_CROSS_TRANSFER_INITIATED)
	return nil
}

func (e *EnygmaExecutor) ExecuteEnygmaDeposit(
	ctx context.Context,
	chainEventID string,
	resourceId string,
	amount *big.Int,
	blockNumber uint64,
	depositCommitment *big.Int,
	depositSalt *big.Int,
	from common.Address,
	txHash common.Hash,
	enygmaAddress common.Address,
) error {
	blockNumberPrivateHub := new(big.Int).SetUint64(blockNumber)

	batches, err := e.batcher.CreateBatchesWithAnonimity(ctx, resourceId, blockNumberPrivateHub, nil)
	if err != nil {
		return fmt.Errorf("creating batches for deposit: %w", err)
	}

	spendKeyResp, err := e.keysClient.GetPaymentSpendKey(ctx, &keyspb.GetPaymentSpendKeyRequest{})
	if err != nil {
		return fmt.Errorf("getting payment spend key for deposit: %w", err)
	}
	spendKey := types.PaymentSpendKey{
		SecretKey: new(big.Int).SetBytes(spendKeyResp.GetSecretKey()),
		PublicKey: new(big.Int).SetBytes(spendKeyResp.GetPublicKey()),
	}

	anonymityIndex := len(batches)
	proof, _, rValues, _, err := e.proofGen.GenerateDepositProof(
		ctx,
		enygma.DepositProofParams{
			ResourceId:        resourceId,
			AnonymityIndex:    anonymityIndex,
			SenderAmount:      amount,
			BlockNumber:       blockNumberPrivateHub,
			Batches:           batches,
			DepositCommitment: depositCommitment,
			DepositSalt:       depositSalt,
			DepositPublicKey:  spendKey.PublicKey,
			TokenAddress:      enygmaAddress,
		},
	)
	if err != nil {
		slog.Error(
			"Error generating Enygma deposit proof",
			slog.String("resourceId", resourceId),
			slog.String("err", err.Error()),
		)
		return fmt.Errorf("generating enygma deposit proof: %w", err)
	}

	senderRFactor := big.NewInt(0)
	for i, batch := range batches {
		batch.ToRValueToAdd = rValues[i]
		if batch.ToChainID.Cmp(e.plChainId) == 0 {
			senderRFactor = rValues[i]
		}
	}

	ctxTx, cancel := context.WithTimeout(ctx, e.conf.DefaultContextTimeout)
	defer cancel()

	enygmaIntegrationAddress, err := e.enygmaClient.GetDvpIntegrationContractAddress(ctx, enygmaAddress)
	if err != nil {
		return fmt.Errorf("getting dvp integration contract address for deposit: %w", err)
	}
	err = e.enygmaIntegrationClient.Deposit(ctxTx, contractclient.DvpIntegrationTxRequest{
		ChainEventID:          chainEventID,
		Batches:               batches,
		Proof:                 proof,
		BlockNumber:           blockNumberPrivateHub,
		ChainId:               e.plChainId,
		ResourceId:            resourceId,
		Amount:                amount,
		From:                  from,
		SourceTxHash:          txHash,
		DvpIntegrationAddress: enygmaIntegrationAddress,
	})
	if err != nil {
		slog.Error(
			"Error signing Enygma deposit",
			slog.String("resourceId", resourceId),
			slog.Any("err", err.Error()),
		)
		return fmt.Errorf("signing enygma deposit: %w", err)
	}

	history := types.EnygmaHistory{
		ResourceId:            resourceId,
		FromChainId:           e.plChainId,
		RFactor:               senderRFactor,
		BalanceChange:         new(big.Int).Neg(amount),
		BlockNumberPrivateHub: blockNumberPrivateHub,
		EventType:             types.EnygmaDepositToDvp,
	}

	if err := e.enygmaHistoryRepository.InsertEnygmaHistory(ctx, history); err != nil {
		if !errors.Is(err, repository.ErrAlreadyProcessed) {
			return fmt.Errorf("inserting enygma history: %w", err)
		}
	}

	slog.Debug("Enygma deposit done", slog.String("resourceId", resourceId))
	return nil
}

// EnygmaWithdrawalRequest holds the inputs for an Enygma withdrawal from DvP.
type EnygmaWithdrawalRequest struct {
	ChainEventID  string
	ResourceId    string
	Amount        *big.Int
	PaymentSalt   *big.Int
	BlockNumber   uint64
	EnygmaAddress common.Address
	JSProof       *dvp.ProofReceipt
	// WithdrawingUser is the user whose DvP balance is withdrawn; it becomes the
	// From of the DvP balance-update record (user -> DvP integration contract).
	WithdrawingUser common.Address
	TxHash          common.Hash
}

// ExecuteEnygmaWithdrawal proves and submits a withdrawal of req.Amount from DvP
// back into the Enygma balance, binding the proof to the join-split payment output.
func (e *EnygmaExecutor) ExecuteEnygmaWithdrawal(ctx context.Context, req EnygmaWithdrawalRequest) error {
	if req.Amount == nil {
		return errors.New("withdrawal request is missing its amount")
	}
	if req.PaymentSalt == nil {
		return errors.New("withdrawal request is missing its payment salt")
	}
	if req.JSProof == nil {
		return errors.New("withdrawal request is missing its join-split receipt")
	}

	blockNumberPrivateHub := new(big.Int).SetUint64(req.BlockNumber)

	spendKeyResp, err := e.keysClient.GetPaymentSpendKey(ctx, &keyspb.GetPaymentSpendKeyRequest{})
	if err != nil {
		return fmt.Errorf("getting payment spend key for withdrawal: %w", err)
	}
	spendKey := types.PaymentSpendKey{
		SecretKey: new(big.Int).SetBytes(spendKeyResp.GetSecretKey()),
		PublicKey: new(big.Int).SetBytes(spendKeyResp.GetPublicKey()),
	}

	// The withdraw proof opens the join-split's payment output with the credited
	// amount, and the contract requires it to equal the receipt's commitments[0].
	// The commitment is recomputed from the spend key fetched above (the proof
	// needs its secret half anyway), so a key that changed since the initiator
	// built the join-split is caught here rather than on-chain.
	paymentCommitment, err := e.commitmentCalculator.CalculatePaymentCommitment(
		spendKey.PublicKey,
		req.PaymentSalt,
		req.Amount,
		// The Enygma contract address is the token address: the initiator finds
		// the deposits and builds the join-split output with this same address.
		req.EnygmaAddress.Hex(),
	)
	if err != nil {
		return fmt.Errorf("calculating payment commitment: %w", err)
	}
	if err := checkPaymentOutput(req.JSProof, paymentCommitment); err != nil {
		return fmt.Errorf("validating join-split payment output for withdrawal: %w", err)
	}

	batches, err := e.batcher.CreateBatchesWithAnonimity(ctx, req.ResourceId, blockNumberPrivateHub, nil)
	if err != nil {
		return fmt.Errorf("creating batches for withdrawal: %w", err)
	}

	anonymityIndex := len(batches)
	proof, _, rValues, _, err := e.proofGen.GenerateWithdrawProof(
		ctx,
		enygma.WithdrawProofParams{
			ResourceId:        req.ResourceId,
			AnonymityIndex:    anonymityIndex,
			SenderAmount:      req.Amount,
			BlockNumber:       blockNumberPrivateHub,
			Batches:           batches,
			TokenAddress:      req.EnygmaAddress,
			PaymentCommitment: paymentCommitment,
			PaymentSecretKey:  spendKey.SecretKey,
			PaymentSalt:       req.PaymentSalt,
		},
	)
	if err != nil {
		slog.Error(
			"Error generating Enygma withdrawal proof",
			slog.String("resourceId", req.ResourceId),
			slog.String("err", err.Error()),
		)
		return fmt.Errorf("generating enygma withdrawal proof: %w", err)
	}

	senderRFactor := big.NewInt(0)
	for i, batch := range batches {
		batch.ToRValueToAdd = rValues[i]
		if batch.ToChainID.Cmp(e.plChainId) == 0 {
			senderRFactor = rValues[i]
		}
	}

	ctxTx, cancel := context.WithTimeout(ctx, e.conf.DefaultContextTimeout)
	defer cancel()

	enygmaIntegrationAddress, err := e.enygmaClient.GetDvpIntegrationContractAddress(ctx, req.EnygmaAddress)
	if err != nil {
		return fmt.Errorf("getting dvp integration contract address for withdrawal: %w", err)
	}

	err = e.enygmaIntegrationClient.Withdraw(ctxTx, contractclient.DvpIntegrationTxRequest{
		ChainEventID:          req.ChainEventID,
		Batches:               batches,
		Proof:                 proof,
		BlockNumber:           blockNumberPrivateHub,
		ChainId:               e.plChainId,
		ResourceId:            req.ResourceId,
		Amount:                req.Amount,
		From:                  req.WithdrawingUser,
		SourceTxHash:          req.TxHash,
		DvpIntegrationAddress: enygmaIntegrationAddress,
	}, req.JSProof)
	if err != nil {
		slog.Error("Error signing Enygma withdrawal", slog.String("resourceId", req.ResourceId), slog.Any("err", err))
		return fmt.Errorf("signing enygma withdrawal: %w", err)
	}

	history := types.EnygmaHistory{
		ResourceId:            req.ResourceId,
		FromChainId:           e.plChainId,
		RFactor:               senderRFactor,
		BalanceChange:         req.Amount,
		BlockNumberPrivateHub: blockNumberPrivateHub,
		EventType:             types.EnygmaWithdrawFromDvp,
	}

	if err := e.enygmaHistoryRepository.InsertEnygmaHistory(ctx, history); err != nil {
		if !errors.Is(err, repository.ErrAlreadyProcessed) {
			return fmt.Errorf("inserting enygma history: %w", err)
		}
	}

	slog.Debug("Enygma withdrawal done", slog.String("resourceId", req.ResourceId))
	return nil
}

// checkPaymentOutput reports whether the join-split receipt's payment output
// (commitments[0]) is the commitment the withdraw proof will open. The contract
// rejects the withdrawal otherwise, so a mismatch is caught before proving.
// ExecuteEnygmaWithdrawal already rejects a nil receipt, and the nil
// commitment check only fires if the calculator breaks its contract by
// returning (nil, nil); both are defensive, so the guard never panics.
// A mismatch is deliberately not a retryable error: it cannot heal at a later
// block, so the withdrawal fails fast and must be re-driven.
func checkPaymentOutput(jsProof *dvp.ProofReceipt, paymentCommitment *big.Int) error {
	if paymentCommitment == nil {
		return errors.New("calculated withdraw payment commitment is nil")
	}
	if jsProof == nil || len(jsProof.Commitments) == 0 || jsProof.Commitments[0] == nil {
		return errors.New("join-split receipt has no payment output")
	}
	if jsProof.Commitments[0].Cmp(paymentCommitment) != 0 {
		return fmt.Errorf(
			"join-split payment output %s does not match withdraw payment commitment %s"+
				" (spend key, salt or amount differs from the join-split's)",
			jsProof.Commitments[0], paymentCommitment,
		)
	}
	return nil
}
