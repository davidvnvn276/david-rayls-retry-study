package service_test

import (
	"context"
	"errors"
	"math/big"
	"testing"
	"time"

	"github.com/ethereum/go-ethereum/common"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
	"google.golang.org/grpc"

	"github.com/raylsnetwork/rayls-sovereign-relayer/contractclient"
	keyspb "github.com/raylsnetwork/rayls-sovereign-relayer/cts/gen/proto/keys"
	"github.com/raylsnetwork/rayls-sovereign-relayer/dvp"
	"github.com/raylsnetwork/rayls-sovereign-relayer/enygma"
	"github.com/raylsnetwork/rayls-sovereign-relayer/enygma/service"
	"github.com/raylsnetwork/rayls-sovereign-relayer/enygma/testutils"
	"github.com/raylsnetwork/rayls-sovereign-relayer/types"
)

// NOTE on this rewrite:
// The previous test file in `issue/173` exercised an older richer executor
// that owned a transaction-recovery repository, a TxOps sender, a contract
// clients factory, a broadcaster, a receipter and a simulator. The CTS
// migration on `feat/cts` collapsed those responsibilities — the
// `EnygmaExecutor` now talks directly to a single `executorEnygmaClient`
// and `ExecutorDvpIntegrationClient` plus a `executorKeysClient` (gRPC).
// Test cases that exercised the removed pipeline (crash recovery resume,
// contract factory failures, broadcaster/receipter assertions, TxOps-send
// counters) have been dropped because the underlying behaviour no longer
// exists in `executor.go`. The remaining cases still cover happy-path
// success and every error branch the executor produces today.

func executorTestResourceId() string {
	return "test-resource-123"
}

func executorTestBlockNumber() uint64 {
	return 100
}

func executorTestTxHash() common.Hash {
	return common.HexToHash("0xabcd")
}

func executorTestFromAddress() common.Address {
	return common.HexToAddress("0xfrom1234")
}

func executorTestEnygmaAddress() common.Address {
	return common.HexToAddress("0x1234567890123456789012345678901234567890")
}

func executorTestAmount() *big.Int {
	return big.NewInt(1000)
}

func executorTestPnChainId() *big.Int {
	return big.NewInt(1)
}

func executorTestConfig() service.ExecutorConfig {
	return service.ExecutorConfig{
		DefaultContextTimeout: 5 * time.Second,
	}
}

// successKeysClient returns a deterministic payment-spend key tuple.
func successKeysClient() *executorKeysClientMock {
	return &executorKeysClientMock{
		GetPaymentSpendKeyFunc: func(
			ctx context.Context,
			in *keyspb.GetPaymentSpendKeyRequest,
			opts ...grpc.CallOption,
		) (*keyspb.PaymentSpendKeyResponse, error) {
			return &keyspb.PaymentSpendKeyResponse{
				PublicKey: big.NewInt(1).Bytes(),
				SecretKey: big.NewInt(999).Bytes(),
			}, nil
		},
	}
}

func TestEnygmaExecutor_ExecuteEnygmaSupplyUpdate(t *testing.T) {
	t.Run("successfully executes mint supply update", func(t *testing.T) {
		ctx := context.Background()
		conf := executorTestConfig()
		resourceId := executorTestResourceId()
		blockNumber := executorTestBlockNumber()
		enygmaAddress := executorTestEnygmaAddress()
		amount := executorTestAmount()
		plChainId := executorTestPnChainId()

		tracer := &testutils.MockTracer{}
		batcher := &executorEnygmaBatcherMock{}
		proofGen := &executorProofGeneratorMock{}
		repository := &executorEnygmaHistoryRepositoryMock{
			InsertEnygmaHistoryFunc: func(ctx context.Context, history types.EnygmaHistory) error {
				return nil
			},
		}
		keysClient := successKeysClient()
		enygmaClient := &executorEnygmaClientMock{
			SupplyUpdateFunc: func(
				ctx context.Context,
				_ string,
				tokenAddress common.Address,
				senderChainId *big.Int,
				blockNumber *big.Int,
				update types.EnygmaSupplyUpdate,
			) error {
				return nil
			},
		}
		integrationClient := &ExecutorDvpIntegrationClientMock{}
		commitmentCalc := &executorCommitmentCalculatorMock{}

		executor := service.NewEnygmaExecutor(
			conf,
			tracer,
			batcher,
			proofGen,
			repository,
			keysClient,
			enygmaClient,
			integrationClient,
			commitmentCalc,
			plChainId,
		)

		supplyUpdate := types.EnygmaSupplyUpdate{
			Type:   types.EnygmaMint,
			Amount: amount,
		}
		err := executor.ExecuteEnygmaSupplyUpdate(ctx, "test-batch-id", resourceId, blockNumber, supplyUpdate, enygmaAddress)

		require.NoError(t, err)
		require.Len(t, repository.InsertEnygmaHistoryCalls(), 1)
		history := repository.InsertEnygmaHistoryCalls()[0].History
		assert.Equal(t, types.EnygmaMint, history.EventType)
		assert.Equal(t, amount, history.BalanceChange)
		assert.Equal(t, plChainId, history.FromChainId)
		assert.Equal(t, big.NewInt(0), history.RFactor)
		assert.Equal(t, new(big.Int).SetUint64(blockNumber), history.BlockNumberPrivateHub)
		assert.Len(t, enygmaClient.SupplyUpdateCalls(), 1)
	})

	t.Run("successfully executes burn supply update", func(t *testing.T) {
		ctx := context.Background()
		conf := executorTestConfig()
		resourceId := executorTestResourceId()
		blockNumber := executorTestBlockNumber()
		enygmaAddress := executorTestEnygmaAddress()
		amount := executorTestAmount()
		plChainId := executorTestPnChainId()

		tracer := &testutils.MockTracer{}
		batcher := &executorEnygmaBatcherMock{}
		proofGen := &executorProofGeneratorMock{}
		repository := &executorEnygmaHistoryRepositoryMock{
			InsertEnygmaHistoryFunc: func(ctx context.Context, history types.EnygmaHistory) error {
				return nil
			},
		}
		keysClient := successKeysClient()
		enygmaClient := &executorEnygmaClientMock{
			SupplyUpdateFunc: func(
				ctx context.Context,
				_ string,
				tokenAddress common.Address,
				senderChainId *big.Int,
				blockNumber *big.Int,
				update types.EnygmaSupplyUpdate,
			) error {
				return nil
			},
		}
		integrationClient := &ExecutorDvpIntegrationClientMock{}
		commitmentCalc := &executorCommitmentCalculatorMock{}

		executor := service.NewEnygmaExecutor(
			conf,
			tracer,
			batcher,
			proofGen,
			repository,
			keysClient,
			enygmaClient,
			integrationClient,
			commitmentCalc,
			plChainId,
		)

		supplyUpdate := types.EnygmaSupplyUpdate{
			Type:   types.EnygmaBurn,
			Amount: amount,
		}
		err := executor.ExecuteEnygmaSupplyUpdate(ctx, "test-batch-id", resourceId, blockNumber, supplyUpdate, enygmaAddress)

		require.NoError(t, err)
		require.Len(t, repository.InsertEnygmaHistoryCalls(), 1)
		history := repository.InsertEnygmaHistoryCalls()[0].History
		assert.Equal(t, types.EnygmaBurn, history.EventType)
		assert.Equal(t, plChainId, history.FromChainId)
		assert.Equal(t, big.NewInt(0), history.RFactor)
		assert.Equal(t, new(big.Int).SetUint64(blockNumber), history.BlockNumberPrivateHub)
		// For burn, balance change should be negative.
		assert.Equal(t, big.NewInt(-1000), history.BalanceChange)
	})

	t.Run("returns error for invalid supply update type", func(t *testing.T) {
		ctx := context.Background()
		conf := executorTestConfig()
		resourceId := executorTestResourceId()
		blockNumber := executorTestBlockNumber()
		enygmaAddress := executorTestEnygmaAddress()
		amount := executorTestAmount()
		plChainId := executorTestPnChainId()

		tracer := &testutils.MockTracer{}
		batcher := &executorEnygmaBatcherMock{}
		proofGen := &executorProofGeneratorMock{}
		repository := &executorEnygmaHistoryRepositoryMock{}
		keysClient := successKeysClient()
		enygmaClient := &executorEnygmaClientMock{}
		integrationClient := &ExecutorDvpIntegrationClientMock{}
		commitmentCalc := &executorCommitmentCalculatorMock{}

		executor := service.NewEnygmaExecutor(
			conf,
			tracer,
			batcher,
			proofGen,
			repository,
			keysClient,
			enygmaClient,
			integrationClient,
			commitmentCalc,
			plChainId,
		)

		supplyUpdate := types.EnygmaSupplyUpdate{
			Type:   types.EnygmaTransfer,
			Amount: amount,
		}
		err := executor.ExecuteEnygmaSupplyUpdate(ctx, "test-batch-id", resourceId, blockNumber, supplyUpdate, enygmaAddress)

		require.Error(t, err)
		assert.Contains(t, err.Error(), "invalid supply update type")
		assert.Empty(t, repository.InsertEnygmaHistoryCalls())
	})

	t.Run("returns error when SupplyUpdate fails", func(t *testing.T) {
		ctx := context.Background()
		conf := executorTestConfig()
		resourceId := executorTestResourceId()
		blockNumber := executorTestBlockNumber()
		enygmaAddress := executorTestEnygmaAddress()
		amount := executorTestAmount()
		plChainId := executorTestPnChainId()

		tracer := &testutils.MockTracer{}
		batcher := &executorEnygmaBatcherMock{}
		proofGen := &executorProofGeneratorMock{}
		repository := &executorEnygmaHistoryRepositoryMock{}
		keysClient := successKeysClient()
		enygmaClient := &executorEnygmaClientMock{
			SupplyUpdateFunc: func(
				ctx context.Context,
				_ string,
				tokenAddress common.Address,
				senderChainId *big.Int,
				blockNumber *big.Int,
				update types.EnygmaSupplyUpdate,
			) error {
				return errors.New("supply update failed")
			},
		}
		integrationClient := &ExecutorDvpIntegrationClientMock{}
		commitmentCalc := &executorCommitmentCalculatorMock{}

		executor := service.NewEnygmaExecutor(
			conf,
			tracer,
			batcher,
			proofGen,
			repository,
			keysClient,
			enygmaClient,
			integrationClient,
			commitmentCalc,
			plChainId,
		)

		supplyUpdate := types.EnygmaSupplyUpdate{
			Type:   types.EnygmaMint,
			Amount: amount,
		}
		err := executor.ExecuteEnygmaSupplyUpdate(ctx, "test-batch-id", resourceId, blockNumber, supplyUpdate, enygmaAddress)

		require.Error(t, err)
		assert.Contains(t, err.Error(), "supply update failed")
		assert.Empty(t, repository.InsertEnygmaHistoryCalls())
	})

	t.Run("returns error when repository insertion fails", func(t *testing.T) {
		ctx := context.Background()
		conf := executorTestConfig()
		resourceId := executorTestResourceId()
		blockNumber := executorTestBlockNumber()
		enygmaAddress := executorTestEnygmaAddress()
		amount := executorTestAmount()
		plChainId := executorTestPnChainId()

		tracer := &testutils.MockTracer{}
		batcher := &executorEnygmaBatcherMock{}
		proofGen := &executorProofGeneratorMock{}
		repository := &executorEnygmaHistoryRepositoryMock{
			InsertEnygmaHistoryFunc: func(ctx context.Context, history types.EnygmaHistory) error {
				return errors.New("database error")
			},
		}
		keysClient := successKeysClient()
		enygmaClient := &executorEnygmaClientMock{
			SupplyUpdateFunc: func(
				ctx context.Context,
				_ string,
				tokenAddress common.Address,
				senderChainId *big.Int,
				blockNumber *big.Int,
				update types.EnygmaSupplyUpdate,
			) error {
				return nil
			},
		}
		integrationClient := &ExecutorDvpIntegrationClientMock{}
		commitmentCalc := &executorCommitmentCalculatorMock{}

		executor := service.NewEnygmaExecutor(
			conf,
			tracer,
			batcher,
			proofGen,
			repository,
			keysClient,
			enygmaClient,
			integrationClient,
			commitmentCalc,
			plChainId,
		)

		supplyUpdate := types.EnygmaSupplyUpdate{
			Type:   types.EnygmaMint,
			Amount: amount,
		}
		err := executor.ExecuteEnygmaSupplyUpdate(ctx, "test-batch-id", resourceId, blockNumber, supplyUpdate, enygmaAddress)

		require.Error(t, err)
		assert.Contains(t, err.Error(), "database error")
	})
}

func TestEnygmaExecutor_ExecuteEnygmaCrossTransfer(t *testing.T) {
	t.Run("successfully executes cross transfer", func(t *testing.T) {
		ctx := context.Background()
		conf := executorTestConfig()
		resourceId := executorTestResourceId()
		blockNumber := executorTestBlockNumber()
		enygmaAddress := executorTestEnygmaAddress()
		plChainId := executorTestPnChainId()
		toChainId := big.NewInt(2)
		senderRFactor := big.NewInt(100)

		txsByChainID := make(map[string][]*types.EnygmaTransferBatchTx)

		tracer := &testutils.MockTracer{}
		batcher := &executorEnygmaBatcherMock{
			CreateBatchesWithAnonimityFunc: func(
				ctx context.Context,
				resourceId string,
				blockNumber *big.Int,
				txsByChainID map[string][]*types.EnygmaTransferBatchTx,
			) ([]*types.EnygmaTransferBatch, error) {
				return []*types.EnygmaTransferBatch{
					{
						ResourceId:   resourceId,
						ToChainID:    plChainId,
						FromChainID:  plChainId,
						Transactions: []*types.EnygmaTransferBatchTx{},
					},
					{
						ResourceId:  resourceId,
						ToChainID:   toChainId,
						FromChainID: plChainId,
						Transactions: []*types.EnygmaTransferBatchTx{
							{
								MessageId:   "msg-1",
								ReferenceId: [32]byte{1, 2, 3, 4},
								FromAddress: common.HexToAddress("0x1111111111111111111111111111111111111111"),
								ToAmount:    big.NewInt(100),
								ToAddress:   common.HexToAddress("0x2222222222222222222222222222222222222222"),
							},
						},
					},
				}, nil
			},
		}
		proofGen := &executorProofGeneratorMock{
			GenerateTransferProofFunc: func(
				ctx context.Context,
				params enygma.TransferProofParams,
			) (*types.EnygmaProofResponse, []*types.Point, []*big.Int, []*big.Int, error) {
				return &types.EnygmaProofResponse{}, []*types.Point{}, []*big.Int{
					senderRFactor,
					big.NewInt(200),
				}, []*big.Int{}, nil
			},
		}
		repository := &executorEnygmaHistoryRepositoryMock{
			InsertEnygmaHistoryFunc: func(ctx context.Context, history types.EnygmaHistory) error {
				return nil
			},
		}
		keysClient := successKeysClient()
		enygmaClient := &executorEnygmaClientMock{
			TransferBatchFunc: func(
				ctx context.Context,
				_ string,
				tokenAddress common.Address,
				batches []*types.EnygmaTransferBatch,
				proof *types.EnygmaProofResponse,
				blockNumber *big.Int,
			) error {
				return nil
			},
		}
		integrationClient := &ExecutorDvpIntegrationClientMock{}
		commitmentCalc := &executorCommitmentCalculatorMock{}

		executor := service.NewEnygmaExecutor(
			conf,
			tracer,
			batcher,
			proofGen,
			repository,
			keysClient,
			enygmaClient,
			integrationClient,
			commitmentCalc,
			plChainId,
		)

		err := executor.ExecuteEnygmaCrossTransfer(ctx, "test-batch-id", blockNumber, resourceId, txsByChainID, enygmaAddress)

		require.NoError(t, err)
		assert.Len(t, batcher.CreateBatchesWithAnonimityCalls(), 1)
		assert.Len(t, proofGen.GenerateTransferProofCalls(), 1)
		assert.Len(t, enygmaClient.TransferBatchCalls(), 1)
		require.Len(t, repository.InsertEnygmaHistoryCalls(), 1)
		history := repository.InsertEnygmaHistoryCalls()[0].History
		assert.Equal(t, types.EnygmaTransfer, history.EventType)
		assert.Equal(t, senderRFactor, history.RFactor)
		assert.Equal(t, big.NewInt(-100), history.BalanceChange)
		assert.Equal(t, plChainId, history.FromChainId)
		assert.Equal(t, new(big.Int).SetUint64(blockNumber), history.BlockNumberPrivateHub)
	})

	t.Run("returns error when batcher fails", func(t *testing.T) {
		ctx := context.Background()
		conf := executorTestConfig()
		resourceId := executorTestResourceId()
		blockNumber := executorTestBlockNumber()
		enygmaAddress := executorTestEnygmaAddress()
		plChainId := executorTestPnChainId()

		txsByChainID := make(map[string][]*types.EnygmaTransferBatchTx)

		tracer := &testutils.MockTracer{}
		batcher := &executorEnygmaBatcherMock{
			CreateBatchesWithAnonimityFunc: func(
				ctx context.Context,
				resourceId string,
				blockNumber *big.Int,
				txsByChainID map[string][]*types.EnygmaTransferBatchTx,
			) ([]*types.EnygmaTransferBatch, error) {
				return nil, errors.New("batching failed")
			},
		}
		proofGen := &executorProofGeneratorMock{}
		repository := &executorEnygmaHistoryRepositoryMock{}
		keysClient := successKeysClient()
		enygmaClient := &executorEnygmaClientMock{}
		integrationClient := &ExecutorDvpIntegrationClientMock{}
		commitmentCalc := &executorCommitmentCalculatorMock{}

		executor := service.NewEnygmaExecutor(
			conf,
			tracer,
			batcher,
			proofGen,
			repository,
			keysClient,
			enygmaClient,
			integrationClient,
			commitmentCalc,
			plChainId,
		)

		err := executor.ExecuteEnygmaCrossTransfer(ctx, "test-batch-id", blockNumber, resourceId, txsByChainID, enygmaAddress)

		require.Error(t, err)
		assert.Contains(t, err.Error(), "batching failed")
		assert.Empty(t, proofGen.GenerateTransferProofCalls())
	})

	t.Run("returns error when proof generation fails", func(t *testing.T) {
		ctx := context.Background()
		conf := executorTestConfig()
		resourceId := executorTestResourceId()
		blockNumber := executorTestBlockNumber()
		enygmaAddress := executorTestEnygmaAddress()
		plChainId := executorTestPnChainId()

		txsByChainID := make(map[string][]*types.EnygmaTransferBatchTx)

		tracer := &testutils.MockTracer{}
		batcher := &executorEnygmaBatcherMock{
			CreateBatchesWithAnonimityFunc: func(
				ctx context.Context,
				resourceId string,
				blockNumber *big.Int,
				txsByChainID map[string][]*types.EnygmaTransferBatchTx,
			) ([]*types.EnygmaTransferBatch, error) {
				return []*types.EnygmaTransferBatch{}, nil
			},
		}
		proofGen := &executorProofGeneratorMock{
			GenerateTransferProofFunc: func(
				ctx context.Context,
				params enygma.TransferProofParams,
			) (*types.EnygmaProofResponse, []*types.Point, []*big.Int, []*big.Int, error) {
				return nil, nil, nil, nil, errors.New("proof generation failed")
			},
		}
		repository := &executorEnygmaHistoryRepositoryMock{}
		keysClient := successKeysClient()
		enygmaClient := &executorEnygmaClientMock{}
		integrationClient := &ExecutorDvpIntegrationClientMock{}
		commitmentCalc := &executorCommitmentCalculatorMock{}

		executor := service.NewEnygmaExecutor(
			conf,
			tracer,
			batcher,
			proofGen,
			repository,
			keysClient,
			enygmaClient,
			integrationClient,
			commitmentCalc,
			plChainId,
		)

		err := executor.ExecuteEnygmaCrossTransfer(ctx, "test-batch-id", blockNumber, resourceId, txsByChainID, enygmaAddress)

		require.Error(t, err)
		assert.Contains(t, err.Error(), "proof generation failed")
		assert.Empty(t, enygmaClient.TransferBatchCalls())
	})

	t.Run("returns error when TransferBatch fails", func(t *testing.T) {
		ctx := context.Background()
		conf := executorTestConfig()
		resourceId := executorTestResourceId()
		blockNumber := executorTestBlockNumber()
		enygmaAddress := executorTestEnygmaAddress()
		plChainId := executorTestPnChainId()

		txsByChainID := make(map[string][]*types.EnygmaTransferBatchTx)

		tracer := &testutils.MockTracer{}
		batcher := &executorEnygmaBatcherMock{
			CreateBatchesWithAnonimityFunc: func(
				ctx context.Context,
				resourceId string,
				blockNumber *big.Int,
				txsByChainID map[string][]*types.EnygmaTransferBatchTx,
			) ([]*types.EnygmaTransferBatch, error) {
				return []*types.EnygmaTransferBatch{}, nil
			},
		}
		proofGen := &executorProofGeneratorMock{
			GenerateTransferProofFunc: func(
				ctx context.Context,
				params enygma.TransferProofParams,
			) (*types.EnygmaProofResponse, []*types.Point, []*big.Int, []*big.Int, error) {
				return &types.EnygmaProofResponse{}, []*types.Point{}, []*big.Int{}, []*big.Int{}, nil
			},
		}
		repository := &executorEnygmaHistoryRepositoryMock{}
		keysClient := successKeysClient()
		enygmaClient := &executorEnygmaClientMock{
			TransferBatchFunc: func(
				ctx context.Context,
				_ string,
				tokenAddress common.Address,
				batches []*types.EnygmaTransferBatch,
				proof *types.EnygmaProofResponse,
				blockNumber *big.Int,
			) error {
				return errors.New("send transfer batch failed")
			},
		}
		integrationClient := &ExecutorDvpIntegrationClientMock{}
		commitmentCalc := &executorCommitmentCalculatorMock{}

		executor := service.NewEnygmaExecutor(
			conf,
			tracer,
			batcher,
			proofGen,
			repository,
			keysClient,
			enygmaClient,
			integrationClient,
			commitmentCalc,
			plChainId,
		)

		err := executor.ExecuteEnygmaCrossTransfer(ctx, "test-batch-id", blockNumber, resourceId, txsByChainID, enygmaAddress)

		require.Error(t, err)
		assert.Contains(t, err.Error(), "send transfer batch failed")
		assert.Empty(t, repository.InsertEnygmaHistoryCalls())
	})

	t.Run("returns error when repository insertion fails", func(t *testing.T) {
		ctx := context.Background()
		conf := executorTestConfig()
		resourceId := executorTestResourceId()
		blockNumber := executorTestBlockNumber()
		enygmaAddress := executorTestEnygmaAddress()
		plChainId := executorTestPnChainId()

		txsByChainID := make(map[string][]*types.EnygmaTransferBatchTx)

		tracer := &testutils.MockTracer{}
		batcher := &executorEnygmaBatcherMock{
			CreateBatchesWithAnonimityFunc: func(
				ctx context.Context,
				resourceId string,
				blockNumber *big.Int,
				txsByChainID map[string][]*types.EnygmaTransferBatchTx,
			) ([]*types.EnygmaTransferBatch, error) {
				return []*types.EnygmaTransferBatch{}, nil
			},
		}
		proofGen := &executorProofGeneratorMock{
			GenerateTransferProofFunc: func(
				ctx context.Context,
				params enygma.TransferProofParams,
			) (*types.EnygmaProofResponse, []*types.Point, []*big.Int, []*big.Int, error) {
				return &types.EnygmaProofResponse{}, []*types.Point{}, []*big.Int{}, []*big.Int{}, nil
			},
		}
		repository := &executorEnygmaHistoryRepositoryMock{
			InsertEnygmaHistoryFunc: func(ctx context.Context, history types.EnygmaHistory) error {
				return errors.New("database error")
			},
		}
		keysClient := successKeysClient()
		enygmaClient := &executorEnygmaClientMock{
			TransferBatchFunc: func(
				ctx context.Context,
				_ string,
				tokenAddress common.Address,
				batches []*types.EnygmaTransferBatch,
				proof *types.EnygmaProofResponse,
				blockNumber *big.Int,
			) error {
				return nil
			},
		}
		integrationClient := &ExecutorDvpIntegrationClientMock{}
		commitmentCalc := &executorCommitmentCalculatorMock{}

		executor := service.NewEnygmaExecutor(
			conf,
			tracer,
			batcher,
			proofGen,
			repository,
			keysClient,
			enygmaClient,
			integrationClient,
			commitmentCalc,
			plChainId,
		)

		err := executor.ExecuteEnygmaCrossTransfer(ctx, "test-batch-id", blockNumber, resourceId, txsByChainID, enygmaAddress)

		require.Error(t, err)
		assert.Contains(t, err.Error(), "database error")
	})
}

func TestEnygmaExecutor_ExecuteEnygmaDeposit(t *testing.T) {
	t.Run("successfully executes deposit", func(t *testing.T) {
		ctx := context.Background()
		conf := executorTestConfig()
		resourceId := executorTestResourceId()
		blockNumber := executorTestBlockNumber()
		enygmaAddress := executorTestEnygmaAddress()
		amount := executorTestAmount()
		txHash := executorTestTxHash()
		fromAddress := executorTestFromAddress()
		depositCommitment := big.NewInt(100)
		depositSalt := big.NewInt(200)
		plChainId := executorTestPnChainId()
		toChainId := big.NewInt(2)
		integrationAddress := common.HexToAddress("0xintegration1234")

		senderRFactor := big.NewInt(456)

		tracer := &testutils.MockTracer{}
		batcher := &executorEnygmaBatcherMock{
			CreateBatchesWithAnonimityFunc: func(
				ctx context.Context,
				resourceId string,
				blockNumber *big.Int,
				txsByChainID map[string][]*types.EnygmaTransferBatchTx,
			) ([]*types.EnygmaTransferBatch, error) {
				return []*types.EnygmaTransferBatch{
					{
						ResourceId:   resourceId,
						ToChainID:    plChainId,
						FromChainID:  plChainId,
						Transactions: []*types.EnygmaTransferBatchTx{},
					},
					{
						ResourceId:   resourceId,
						ToChainID:    toChainId,
						FromChainID:  plChainId,
						Transactions: []*types.EnygmaTransferBatchTx{},
					},
				}, nil
			},
		}
		proofGen := &executorProofGeneratorMock{
			GenerateDepositProofFunc: func(
				ctx context.Context,
				params enygma.DepositProofParams,
			) (*types.EnygmaProofResponse, []*types.Point, []*big.Int, []*big.Int, error) {
				return &types.EnygmaProofResponse{}, []*types.Point{}, []*big.Int{
					senderRFactor,
					big.NewInt(789),
				}, []*big.Int{}, nil
			},
		}
		repository := &executorEnygmaHistoryRepositoryMock{
			InsertEnygmaHistoryFunc: func(ctx context.Context, history types.EnygmaHistory) error {
				return nil
			},
		}
		keysClient := successKeysClient()
		enygmaClient := &executorEnygmaClientMock{
			GetDvpIntegrationContractAddressFunc: func(_ context.Context, tokenAddress common.Address) (common.Address, error) {
				return integrationAddress, nil
			},
		}
		integrationClient := &ExecutorDvpIntegrationClientMock{
			DepositFunc: func(context.Context, contractclient.DvpIntegrationTxRequest) error {
				return nil
			},
		}
		commitmentCalc := &executorCommitmentCalculatorMock{}

		executor := service.NewEnygmaExecutor(
			conf,
			tracer,
			batcher,
			proofGen,
			repository,
			keysClient,
			enygmaClient,
			integrationClient,
			commitmentCalc,
			plChainId,
		)

		err := executor.ExecuteEnygmaDeposit(
			ctx,
			"test-batch-id",
			resourceId,
			amount,
			blockNumber,
			depositCommitment,
			depositSalt,
			fromAddress,
			txHash,
			enygmaAddress,
		)

		require.NoError(t, err)
		assert.Len(t, batcher.CreateBatchesWithAnonimityCalls(), 1)
		assert.Len(t, proofGen.GenerateDepositProofCalls(), 1)
		assert.Len(t, enygmaClient.GetDvpIntegrationContractAddressCalls(), 1)
		assert.Len(t, integrationClient.DepositCalls(), 1)
		require.Len(t, repository.InsertEnygmaHistoryCalls(), 1)
		history := repository.InsertEnygmaHistoryCalls()[0].History
		assert.Equal(t, types.EnygmaDepositToDvp, history.EventType)
		assert.Equal(t, plChainId, history.FromChainId)
		assert.Equal(t, senderRFactor, history.RFactor)
		assert.Equal(t, new(big.Int).Neg(amount), history.BalanceChange)
		assert.Equal(t, new(big.Int).SetUint64(blockNumber), history.BlockNumberPrivateHub)
		// The integration client should receive the address resolved by the enygma client.
		assert.Equal(t, integrationAddress, integrationClient.DepositCalls()[0].Req.DvpIntegrationAddress)
	})

	t.Run("returns error when batcher fails", func(t *testing.T) {
		ctx := context.Background()
		conf := executorTestConfig()
		resourceId := executorTestResourceId()
		blockNumber := executorTestBlockNumber()
		enygmaAddress := executorTestEnygmaAddress()
		amount := executorTestAmount()
		txHash := executorTestTxHash()
		fromAddress := executorTestFromAddress()
		depositCommitment := big.NewInt(100)
		depositSalt := big.NewInt(200)
		plChainId := executorTestPnChainId()

		tracer := &testutils.MockTracer{}
		batcher := &executorEnygmaBatcherMock{
			CreateBatchesWithAnonimityFunc: func(
				ctx context.Context,
				resourceId string,
				blockNumber *big.Int,
				txsByChainID map[string][]*types.EnygmaTransferBatchTx,
			) ([]*types.EnygmaTransferBatch, error) {
				return nil, errors.New("batching failed")
			},
		}
		proofGen := &executorProofGeneratorMock{}
		repository := &executorEnygmaHistoryRepositoryMock{}
		keysClient := successKeysClient()
		enygmaClient := &executorEnygmaClientMock{}
		integrationClient := &ExecutorDvpIntegrationClientMock{}
		commitmentCalc := &executorCommitmentCalculatorMock{}

		executor := service.NewEnygmaExecutor(
			conf,
			tracer,
			batcher,
			proofGen,
			repository,
			keysClient,
			enygmaClient,
			integrationClient,
			commitmentCalc,
			plChainId,
		)

		err := executor.ExecuteEnygmaDeposit(
			ctx,
			"test-batch-id",
			resourceId,
			amount,
			blockNumber,
			depositCommitment,
			depositSalt,
			fromAddress,
			txHash,
			enygmaAddress,
		)

		require.Error(t, err)
		assert.Contains(t, err.Error(), "batching failed")
	})

	t.Run("returns error when keys client fails", func(t *testing.T) {
		ctx := context.Background()
		conf := executorTestConfig()
		resourceId := executorTestResourceId()
		blockNumber := executorTestBlockNumber()
		enygmaAddress := executorTestEnygmaAddress()
		amount := executorTestAmount()
		txHash := executorTestTxHash()
		fromAddress := executorTestFromAddress()
		depositCommitment := big.NewInt(100)
		depositSalt := big.NewInt(200)
		plChainId := executorTestPnChainId()

		tracer := &testutils.MockTracer{}
		batcher := &executorEnygmaBatcherMock{
			CreateBatchesWithAnonimityFunc: func(
				ctx context.Context,
				resourceId string,
				blockNumber *big.Int,
				txsByChainID map[string][]*types.EnygmaTransferBatchTx,
			) ([]*types.EnygmaTransferBatch, error) {
				return []*types.EnygmaTransferBatch{}, nil
			},
		}
		proofGen := &executorProofGeneratorMock{}
		repository := &executorEnygmaHistoryRepositoryMock{}
		keysClient := &executorKeysClientMock{
			GetPaymentSpendKeyFunc: func(
				ctx context.Context,
				in *keyspb.GetPaymentSpendKeyRequest,
				opts ...grpc.CallOption,
			) (*keyspb.PaymentSpendKeyResponse, error) {
				return nil, errors.New("keys client failed")
			},
		}
		enygmaClient := &executorEnygmaClientMock{}
		integrationClient := &ExecutorDvpIntegrationClientMock{}
		commitmentCalc := &executorCommitmentCalculatorMock{}

		executor := service.NewEnygmaExecutor(
			conf,
			tracer,
			batcher,
			proofGen,
			repository,
			keysClient,
			enygmaClient,
			integrationClient,
			commitmentCalc,
			plChainId,
		)

		err := executor.ExecuteEnygmaDeposit(
			ctx,
			"test-batch-id",
			resourceId,
			amount,
			blockNumber,
			depositCommitment,
			depositSalt,
			fromAddress,
			txHash,
			enygmaAddress,
		)

		require.Error(t, err)
		assert.Contains(t, err.Error(), "keys client failed")
	})

	t.Run("returns error when proof generation fails", func(t *testing.T) {
		ctx := context.Background()
		conf := executorTestConfig()
		resourceId := executorTestResourceId()
		blockNumber := executorTestBlockNumber()
		enygmaAddress := executorTestEnygmaAddress()
		amount := executorTestAmount()
		txHash := executorTestTxHash()
		fromAddress := executorTestFromAddress()
		depositCommitment := big.NewInt(100)
		depositSalt := big.NewInt(200)
		plChainId := executorTestPnChainId()

		tracer := &testutils.MockTracer{}
		batcher := &executorEnygmaBatcherMock{
			CreateBatchesWithAnonimityFunc: func(
				ctx context.Context,
				resourceId string,
				blockNumber *big.Int,
				txsByChainID map[string][]*types.EnygmaTransferBatchTx,
			) ([]*types.EnygmaTransferBatch, error) {
				return []*types.EnygmaTransferBatch{}, nil
			},
		}
		proofGen := &executorProofGeneratorMock{
			GenerateDepositProofFunc: func(
				ctx context.Context,
				params enygma.DepositProofParams,
			) (*types.EnygmaProofResponse, []*types.Point, []*big.Int, []*big.Int, error) {
				return nil, nil, nil, nil, errors.New("proof generation failed")
			},
		}
		repository := &executorEnygmaHistoryRepositoryMock{}
		keysClient := successKeysClient()
		enygmaClient := &executorEnygmaClientMock{}
		integrationClient := &ExecutorDvpIntegrationClientMock{}
		commitmentCalc := &executorCommitmentCalculatorMock{}

		executor := service.NewEnygmaExecutor(
			conf,
			tracer,
			batcher,
			proofGen,
			repository,
			keysClient,
			enygmaClient,
			integrationClient,
			commitmentCalc,
			plChainId,
		)

		err := executor.ExecuteEnygmaDeposit(
			ctx,
			"test-batch-id",
			resourceId,
			amount,
			blockNumber,
			depositCommitment,
			depositSalt,
			fromAddress,
			txHash,
			enygmaAddress,
		)

		require.Error(t, err)
		assert.Contains(t, err.Error(), "proof generation failed")
	})

	t.Run("returns error when getting integration address fails", func(t *testing.T) {
		ctx := context.Background()
		conf := executorTestConfig()
		resourceId := executorTestResourceId()
		blockNumber := executorTestBlockNumber()
		enygmaAddress := executorTestEnygmaAddress()
		amount := executorTestAmount()
		txHash := executorTestTxHash()
		fromAddress := executorTestFromAddress()
		depositCommitment := big.NewInt(100)
		depositSalt := big.NewInt(200)
		plChainId := executorTestPnChainId()

		tracer := &testutils.MockTracer{}
		batcher := &executorEnygmaBatcherMock{
			CreateBatchesWithAnonimityFunc: func(
				ctx context.Context,
				resourceId string,
				blockNumber *big.Int,
				txsByChainID map[string][]*types.EnygmaTransferBatchTx,
			) ([]*types.EnygmaTransferBatch, error) {
				return []*types.EnygmaTransferBatch{}, nil
			},
		}
		proofGen := &executorProofGeneratorMock{
			GenerateDepositProofFunc: func(
				ctx context.Context,
				params enygma.DepositProofParams,
			) (*types.EnygmaProofResponse, []*types.Point, []*big.Int, []*big.Int, error) {
				return &types.EnygmaProofResponse{}, []*types.Point{}, []*big.Int{}, []*big.Int{}, nil
			},
		}
		repository := &executorEnygmaHistoryRepositoryMock{}
		keysClient := successKeysClient()
		enygmaClient := &executorEnygmaClientMock{
			GetDvpIntegrationContractAddressFunc: func(_ context.Context, tokenAddress common.Address) (common.Address, error) {
				return common.Address{}, errors.New("failed to get integration address")
			},
		}
		integrationClient := &ExecutorDvpIntegrationClientMock{}
		commitmentCalc := &executorCommitmentCalculatorMock{}

		executor := service.NewEnygmaExecutor(
			conf,
			tracer,
			batcher,
			proofGen,
			repository,
			keysClient,
			enygmaClient,
			integrationClient,
			commitmentCalc,
			plChainId,
		)

		err := executor.ExecuteEnygmaDeposit(
			ctx,
			"test-batch-id",
			resourceId,
			amount,
			blockNumber,
			depositCommitment,
			depositSalt,
			fromAddress,
			txHash,
			enygmaAddress,
		)

		require.Error(t, err)
		assert.Contains(t, err.Error(), "failed to get integration address")
	})

	t.Run("returns error when Deposit fails", func(t *testing.T) {
		ctx := context.Background()
		conf := executorTestConfig()
		resourceId := executorTestResourceId()
		blockNumber := executorTestBlockNumber()
		enygmaAddress := executorTestEnygmaAddress()
		amount := executorTestAmount()
		txHash := executorTestTxHash()
		fromAddress := executorTestFromAddress()
		depositCommitment := big.NewInt(100)
		depositSalt := big.NewInt(200)
		plChainId := executorTestPnChainId()

		tracer := &testutils.MockTracer{}
		batcher := &executorEnygmaBatcherMock{
			CreateBatchesWithAnonimityFunc: func(
				ctx context.Context,
				resourceId string,
				blockNumber *big.Int,
				txsByChainID map[string][]*types.EnygmaTransferBatchTx,
			) ([]*types.EnygmaTransferBatch, error) {
				return []*types.EnygmaTransferBatch{}, nil
			},
		}
		proofGen := &executorProofGeneratorMock{
			GenerateDepositProofFunc: func(
				ctx context.Context,
				params enygma.DepositProofParams,
			) (*types.EnygmaProofResponse, []*types.Point, []*big.Int, []*big.Int, error) {
				return &types.EnygmaProofResponse{}, []*types.Point{}, []*big.Int{}, []*big.Int{}, nil
			},
		}
		repository := &executorEnygmaHistoryRepositoryMock{}
		keysClient := successKeysClient()
		enygmaClient := &executorEnygmaClientMock{
			GetDvpIntegrationContractAddressFunc: func(_ context.Context, tokenAddress common.Address) (common.Address, error) {
				return common.HexToAddress("0xintegration1234"), nil
			},
		}
		integrationClient := &ExecutorDvpIntegrationClientMock{
			DepositFunc: func(context.Context, contractclient.DvpIntegrationTxRequest) error {
				return errors.New("deposit failed")
			},
		}
		commitmentCalc := &executorCommitmentCalculatorMock{}

		executor := service.NewEnygmaExecutor(
			conf,
			tracer,
			batcher,
			proofGen,
			repository,
			keysClient,
			enygmaClient,
			integrationClient,
			commitmentCalc,
			plChainId,
		)

		err := executor.ExecuteEnygmaDeposit(
			ctx,
			"test-batch-id",
			resourceId,
			amount,
			blockNumber,
			depositCommitment,
			depositSalt,
			fromAddress,
			txHash,
			enygmaAddress,
		)

		require.Error(t, err)
		assert.Contains(t, err.Error(), "deposit failed")
		assert.Empty(t, repository.InsertEnygmaHistoryCalls())
	})

	t.Run("returns error when repository insertion fails", func(t *testing.T) {
		ctx := context.Background()
		conf := executorTestConfig()
		resourceId := executorTestResourceId()
		blockNumber := executorTestBlockNumber()
		enygmaAddress := executorTestEnygmaAddress()
		amount := executorTestAmount()
		txHash := executorTestTxHash()
		fromAddress := executorTestFromAddress()
		depositCommitment := big.NewInt(100)
		depositSalt := big.NewInt(200)
		plChainId := executorTestPnChainId()

		tracer := &testutils.MockTracer{}
		batcher := &executorEnygmaBatcherMock{
			CreateBatchesWithAnonimityFunc: func(
				ctx context.Context,
				resourceId string,
				blockNumber *big.Int,
				txsByChainID map[string][]*types.EnygmaTransferBatchTx,
			) ([]*types.EnygmaTransferBatch, error) {
				return []*types.EnygmaTransferBatch{}, nil
			},
		}
		proofGen := &executorProofGeneratorMock{
			GenerateDepositProofFunc: func(
				ctx context.Context,
				params enygma.DepositProofParams,
			) (*types.EnygmaProofResponse, []*types.Point, []*big.Int, []*big.Int, error) {
				return &types.EnygmaProofResponse{}, []*types.Point{}, []*big.Int{}, []*big.Int{}, nil
			},
		}
		repository := &executorEnygmaHistoryRepositoryMock{
			InsertEnygmaHistoryFunc: func(ctx context.Context, history types.EnygmaHistory) error {
				return errors.New("database error")
			},
		}
		keysClient := successKeysClient()
		enygmaClient := &executorEnygmaClientMock{
			GetDvpIntegrationContractAddressFunc: func(_ context.Context, tokenAddress common.Address) (common.Address, error) {
				return common.HexToAddress("0xintegration1234"), nil
			},
		}
		integrationClient := &ExecutorDvpIntegrationClientMock{
			DepositFunc: func(context.Context, contractclient.DvpIntegrationTxRequest) error {
				return nil
			},
		}
		commitmentCalc := &executorCommitmentCalculatorMock{}

		executor := service.NewEnygmaExecutor(
			conf,
			tracer,
			batcher,
			proofGen,
			repository,
			keysClient,
			enygmaClient,
			integrationClient,
			commitmentCalc,
			plChainId,
		)

		err := executor.ExecuteEnygmaDeposit(
			ctx,
			"test-batch-id",
			resourceId,
			amount,
			blockNumber,
			depositCommitment,
			depositSalt,
			fromAddress,
			txHash,
			enygmaAddress,
		)

		require.Error(t, err)
		assert.Contains(t, err.Error(), "database error")
	})
}

// executorTestPaymentCommitmentCalculator returns a calculator whose payment
// commitment matches executorTestWithdrawalRequest's join-split payment output.
func executorTestPaymentCommitmentCalculator() *executorCommitmentCalculatorMock {
	return &executorCommitmentCalculatorMock{
		CalculatePaymentCommitmentFunc: func(spendPK, salt, paymentAmount *big.Int, tokenAddress string) (*big.Int, error) {
			return big.NewInt(250), nil
		},
	}
}

// executorTestWithdrawalRequest returns a withdrawal whose join-split payment
// output (commitments[0]) is 250, the commitment the calculator mocks return.
func executorTestWithdrawalRequest() service.EnygmaWithdrawalRequest {
	return service.EnygmaWithdrawalRequest{
		ChainEventID:    "test-batch-id",
		ResourceId:      executorTestResourceId(),
		Amount:          executorTestAmount(),
		PaymentSalt:     big.NewInt(1),
		BlockNumber:     executorTestBlockNumber(),
		EnygmaAddress:   executorTestEnygmaAddress(),
		JSProof:         &dvp.ProofReceipt{Commitments: []*big.Int{big.NewInt(250), big.NewInt(0)}},
		WithdrawingUser: executorTestFromAddress(),
		TxHash:          executorTestTxHash(),
	}
}

// withdrawalTestDeps holds the executor's collaborators for withdrawal tests,
// each wired for a successful withdrawal; a test overrides only what it breaks.
type withdrawalTestDeps struct {
	batcher           *executorEnygmaBatcherMock
	proofGen          *executorProofGeneratorMock
	repository        *executorEnygmaHistoryRepositoryMock
	keysClient        *executorKeysClientMock
	enygmaClient      *executorEnygmaClientMock
	integrationClient *ExecutorDvpIntegrationClientMock
	commitmentCalc    *executorCommitmentCalculatorMock
}

const withdrawalTestIntegrationAddress = "0xintegration5678"

func withdrawalTestRFactor() *big.Int { return big.NewInt(456) }

func newWithdrawalTestDeps() *withdrawalTestDeps {
	return &withdrawalTestDeps{
		batcher: &executorEnygmaBatcherMock{
			CreateBatchesWithAnonimityFunc: func(
				context.Context, string, *big.Int, map[string][]*types.EnygmaTransferBatchTx,
			) ([]*types.EnygmaTransferBatch, error) {
				return []*types.EnygmaTransferBatch{
					{ToChainID: executorTestPnChainId()},
					{ToChainID: big.NewInt(2)},
				}, nil
			},
		},
		proofGen: &executorProofGeneratorMock{
			GenerateWithdrawProofFunc: func(
				context.Context, enygma.WithdrawProofParams,
			) (*types.EnygmaProofResponse, []*types.Point, []*big.Int, []*big.Int, error) {
				rValues := []*big.Int{withdrawalTestRFactor(), big.NewInt(789)}
				return &types.EnygmaProofResponse{}, []*types.Point{}, rValues, []*big.Int{}, nil
			},
		},
		repository: &executorEnygmaHistoryRepositoryMock{
			InsertEnygmaHistoryFunc: func(context.Context, types.EnygmaHistory) error {
				return nil
			},
		},
		keysClient: successKeysClient(),
		enygmaClient: &executorEnygmaClientMock{
			GetDvpIntegrationContractAddressFunc: func(context.Context, common.Address) (common.Address, error) {
				return common.HexToAddress(withdrawalTestIntegrationAddress), nil
			},
		},
		integrationClient: &ExecutorDvpIntegrationClientMock{
			WithdrawFunc: func(context.Context, contractclient.DvpIntegrationTxRequest, *dvp.ProofReceipt) error {
				return nil
			},
		},
		commitmentCalc: executorTestPaymentCommitmentCalculator(),
	}
}

func (d *withdrawalTestDeps) executor() *service.EnygmaExecutor {
	return service.NewEnygmaExecutor(
		executorTestConfig(),
		&testutils.MockTracer{},
		d.batcher,
		d.proofGen,
		d.repository,
		d.keysClient,
		d.enygmaClient,
		d.integrationClient,
		d.commitmentCalc,
		executorTestPnChainId(),
	)
}

func TestEnygmaExecutor_ExecuteEnygmaWithdrawal(t *testing.T) {
	t.Parallel()

	deps := newWithdrawalTestDeps()

	err := deps.executor().ExecuteEnygmaWithdrawal(context.Background(), executorTestWithdrawalRequest())

	require.NoError(t, err)
	assert.Len(t, deps.batcher.CreateBatchesWithAnonimityCalls(), 1)
	assert.Len(t, deps.keysClient.GetPaymentSpendKeyCalls(), 1)
	assert.Len(t, deps.commitmentCalc.CalculatePaymentCommitmentCalls(), 1)

	require.Len(t, deps.proofGen.GenerateWithdrawProofCalls(), 1)
	params := deps.proofGen.GenerateWithdrawProofCalls()[0].Params
	blockNumber := new(big.Int).SetUint64(executorTestBlockNumber())
	assert.Equal(t, big.NewInt(250), params.PaymentCommitment)
	assert.Equal(t, big.NewInt(1), params.PaymentSalt)
	assert.NotNil(t, params.PaymentSecretKey)
	assert.Len(t, params.Batches, 2)
	assert.Equal(t, executorTestResourceId(), params.ResourceId)
	assert.Equal(t, executorTestAmount(), params.SenderAmount)
	assert.Equal(t, blockNumber, params.BlockNumber)
	assert.Equal(t, executorTestEnygmaAddress(), params.TokenAddress)

	require.Len(t, deps.integrationClient.WithdrawCalls(), 1)
	assert.Equal(t,
		common.HexToAddress(withdrawalTestIntegrationAddress),
		deps.integrationClient.WithdrawCalls()[0].Req.DvpIntegrationAddress,
	)

	require.Len(t, deps.repository.InsertEnygmaHistoryCalls(), 1)
	history := deps.repository.InsertEnygmaHistoryCalls()[0].History
	assert.Equal(t, types.EnygmaWithdrawFromDvp, history.EventType)
	assert.Equal(t, executorTestPnChainId(), history.FromChainId)
	assert.Equal(t, withdrawalTestRFactor(), history.RFactor)
	assert.Equal(t, executorTestAmount(), history.BalanceChange)
	assert.Equal(t, blockNumber, history.BlockNumberPrivateHub)
}

func TestEnygmaExecutor_ExecuteEnygmaWithdrawal_Errors(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name          string
		breakDeps     func(d *withdrawalTestDeps)
		wantErr       string
		wantNoHistory bool
		// assertSkipped checks that the steps after the failing one never ran.
		assertSkipped func(t *testing.T, d *withdrawalTestDeps)
	}{
		{
			name: "keys client fails",
			breakDeps: func(d *withdrawalTestDeps) {
				d.keysClient.GetPaymentSpendKeyFunc = func(
					context.Context, *keyspb.GetPaymentSpendKeyRequest, ...grpc.CallOption,
				) (*keyspb.PaymentSpendKeyResponse, error) {
					return nil, errors.New("failed to get key pair")
				}
			},
			wantErr: "failed to get key pair",
			assertSkipped: func(t *testing.T, d *withdrawalTestDeps) {
				assert.Empty(t, d.commitmentCalc.CalculatePaymentCommitmentCalls())
				assert.Empty(t, d.batcher.CreateBatchesWithAnonimityCalls())
			},
		},
		{
			name: "commitment calculation fails",
			breakDeps: func(d *withdrawalTestDeps) {
				d.commitmentCalc.CalculatePaymentCommitmentFunc = func(_, _, _ *big.Int, _ string) (*big.Int, error) {
					return nil, errors.New("commitment calculation failed")
				}
			},
			wantErr: "commitment calculation failed",
			assertSkipped: func(t *testing.T, d *withdrawalTestDeps) {
				assert.Empty(t, d.batcher.CreateBatchesWithAnonimityCalls())
				assert.Empty(t, d.proofGen.GenerateWithdrawProofCalls())
			},
		},
		{
			name: "batcher fails",
			breakDeps: func(d *withdrawalTestDeps) {
				d.batcher.CreateBatchesWithAnonimityFunc = func(
					context.Context, string, *big.Int, map[string][]*types.EnygmaTransferBatchTx,
				) ([]*types.EnygmaTransferBatch, error) {
					return nil, errors.New("batching failed")
				}
			},
			wantErr: "batching failed",
			assertSkipped: func(t *testing.T, d *withdrawalTestDeps) {
				assert.Empty(t, d.proofGen.GenerateWithdrawProofCalls())
			},
		},
		{
			name: "proof generation fails",
			breakDeps: func(d *withdrawalTestDeps) {
				d.proofGen.GenerateWithdrawProofFunc = func(
					context.Context, enygma.WithdrawProofParams,
				) (*types.EnygmaProofResponse, []*types.Point, []*big.Int, []*big.Int, error) {
					return nil, nil, nil, nil, errors.New("proof generation failed")
				}
			},
			wantErr: "proof generation failed",
			assertSkipped: func(t *testing.T, d *withdrawalTestDeps) {
				assert.Empty(t, d.integrationClient.WithdrawCalls())
			},
		},
		{
			name: "getting integration address fails",
			breakDeps: func(d *withdrawalTestDeps) {
				d.enygmaClient.GetDvpIntegrationContractAddressFunc = func(
					context.Context, common.Address,
				) (common.Address, error) {
					return common.Address{}, errors.New("failed to get integration address")
				}
			},
			wantErr: "failed to get integration address",
			assertSkipped: func(t *testing.T, d *withdrawalTestDeps) {
				assert.Empty(t, d.integrationClient.WithdrawCalls())
			},
		},
		{
			name: "Withdraw fails",
			breakDeps: func(d *withdrawalTestDeps) {
				d.integrationClient.WithdrawFunc = func(context.Context, contractclient.DvpIntegrationTxRequest, *dvp.ProofReceipt) error {
					return errors.New("withdrawal failed")
				}
			},
			wantErr:       "withdrawal failed",
			wantNoHistory: true,
		},
		{
			name: "repository insertion fails",
			breakDeps: func(d *withdrawalTestDeps) {
				d.repository.InsertEnygmaHistoryFunc = func(context.Context, types.EnygmaHistory) error {
					return errors.New("database error")
				}
			},
			wantErr: "database error",
		},
	}
	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			t.Parallel()
			deps := newWithdrawalTestDeps()
			tc.breakDeps(deps)

			err := deps.executor().ExecuteEnygmaWithdrawal(context.Background(), executorTestWithdrawalRequest())

			require.Error(t, err)
			assert.Contains(t, err.Error(), tc.wantErr)
			if tc.wantNoHistory {
				assert.Empty(t, deps.repository.InsertEnygmaHistoryCalls())
			}
			if tc.assertSkipped != nil {
				tc.assertSkipped(t, deps)
			}
		})
	}
}

func TestEnygmaExecutor_ExecuteEnygmaWithdrawal_MissingRequestFields(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name    string
		mutate  func(req *service.EnygmaWithdrawalRequest)
		wantErr string
	}{
		{
			name:    "nil amount",
			mutate:  func(req *service.EnygmaWithdrawalRequest) { req.Amount = nil },
			wantErr: "withdrawal request is missing its amount",
		},
		{
			name:    "nil payment salt",
			mutate:  func(req *service.EnygmaWithdrawalRequest) { req.PaymentSalt = nil },
			wantErr: "withdrawal request is missing its payment salt",
		},
		{
			name:    "nil join-split receipt",
			mutate:  func(req *service.EnygmaWithdrawalRequest) { req.JSProof = nil },
			wantErr: "withdrawal request is missing its join-split receipt",
		},
	}
	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			t.Parallel()
			deps := newWithdrawalTestDeps()
			req := executorTestWithdrawalRequest()
			tc.mutate(&req)

			err := deps.executor().ExecuteEnygmaWithdrawal(context.Background(), req)

			require.Error(t, err)
			assert.EqualError(t, err, tc.wantErr)
			assert.Empty(t, deps.keysClient.GetPaymentSpendKeyCalls())
			assert.Empty(t, deps.commitmentCalc.CalculatePaymentCommitmentCalls())
			assert.Empty(t, deps.proofGen.GenerateWithdrawProofCalls())
		})
	}
}

func TestEnygmaExecutor_ExecuteEnygmaWithdrawal_PaymentOutput(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name          string
		receipt       *dvp.ProofReceipt
		nilCommitment bool
		wantErr       string
	}{
		{
			name:          "calculator returns a nil payment commitment",
			receipt:       &dvp.ProofReceipt{Commitments: []*big.Int{big.NewInt(250), big.NewInt(0)}},
			nilCommitment: true,
			wantErr:       "calculated withdraw payment commitment is nil",
		},
		{
			name:    "receipt payment output differs from the withdrawn amount's commitment",
			receipt: &dvp.ProofReceipt{Commitments: []*big.Int{big.NewInt(251), big.NewInt(0)}},
			wantErr: "does not match withdraw payment commitment",
		},
		{
			name:    "change output in place of the payment output",
			receipt: &dvp.ProofReceipt{Commitments: []*big.Int{big.NewInt(0), big.NewInt(250)}},
			wantErr: "does not match withdraw payment commitment",
		},
		{
			name:    "receipt without outputs",
			receipt: &dvp.ProofReceipt{},
			wantErr: "join-split receipt has no payment output",
		},
		{
			name:    "receipt with nil payment output",
			receipt: &dvp.ProofReceipt{Commitments: []*big.Int{nil}},
			wantErr: "join-split receipt has no payment output",
		},
	}
	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			t.Parallel()
			deps := newWithdrawalTestDeps()
			if tc.nilCommitment {
				deps.commitmentCalc.CalculatePaymentCommitmentFunc = func(_, _, _ *big.Int, _ string) (*big.Int, error) {
					return nil, nil
				}
			}
			req := executorTestWithdrawalRequest()
			req.JSProof = tc.receipt

			err := deps.executor().ExecuteEnygmaWithdrawal(context.Background(), req)

			require.Error(t, err)
			assert.Contains(t, err.Error(), tc.wantErr)
			// Fails before batching or proving.
			assert.Empty(t, deps.batcher.CreateBatchesWithAnonimityCalls())
			assert.Empty(t, deps.proofGen.GenerateWithdrawProofCalls())
		})
	}
}

// A payment-output mismatch (e.g. the spend key rotated after the join-split
// was built) cannot heal at a later block, so RetryOperation must surface it
// at once instead of burning every retry; the initiator then reverts the
// deposits to Unspent so the withdrawal can be re-driven.
func TestEnygmaExecutor_ExecuteEnygmaWithdrawal_MismatchIsNotRetried(t *testing.T) {
	t.Parallel()

	deps := newWithdrawalTestDeps()
	deps.commitmentCalc.CalculatePaymentCommitmentFunc = func(_, _, _ *big.Int, _ string) (*big.Int, error) {
		return big.NewInt(999), nil
	}
	blockWaiter := &MockRetryBlockWaiter{
		WaitForBlockFunc: func(_ context.Context, target uint64) (uint64, error) { return target + 1, nil },
	}
	retry := service.NewRetryService(&testutils.MockTracer{}, blockWaiter)
	executor := deps.executor()

	_, err := retry.RetryOperation(context.Background(), "withdrawal", 30, executorTestBlockNumber(),
		func(ctx context.Context, nextBlockNumber uint64) error {
			req := executorTestWithdrawalRequest()
			req.BlockNumber = nextBlockNumber
			return executor.ExecuteEnygmaWithdrawal(ctx, req)
		},
	)

	require.ErrorContains(t, err, "non-retryable error encountered")
	assert.ErrorContains(t, err, "does not match withdraw payment commitment")
	assert.Len(t, deps.commitmentCalc.CalculatePaymentCommitmentCalls(), 1)
	assert.Empty(t, blockWaiter.WaitForBlockCalls.Calls)
}
