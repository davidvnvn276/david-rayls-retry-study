'use strict';
// Optional artwork export. Uses sharp if installed locally or in the authoring runtime.
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const assert = require('node:assert/strict');
const root = path.resolve(__dirname, '..');
let sharp;
try { sharp = require('sharp'); }
catch {
  if (!process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES)
    throw Error('Optional image export requires sharp. It is not needed for evidence verification.');
  sharp = require(path.join(process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES, 'sharp'));
}
async function main() {
  const specs = JSON.parse(fs.readFileSync(path.join(root, 'figures/figure-data.json')));
  for (const f of specs.figures) {
    const destination = path.join(root, 'figures', f.file);
    const temp = path.join(root, 'figures', '.render-' + crypto.randomUUID() + '.png');
    try {
      await sharp(fs.readFileSync(path.join(root, 'figures', f.svg)), { density: 144 }).png().toFile(temp);
      const image = sharp(temp);
      const meta = await image.metadata();
      assert.equal(meta.width, f.png_size[0]);
      assert.equal(meta.height, f.png_size[1]);
      await image.raw().toBuffer();
      fs.renameSync(temp, destination);
      const preview = path.join(root, 'figures', f.file.replace('.png', '-preview.png'));
      await sharp(destination).resize({ width: 800 }).png().toFile(preview);
    } finally { if (fs.existsSync(temp)) fs.unlinkSync(temp); }
  }
  console.log('PASS three high-resolution PNGs fully decoded before final placement.');
}
main().catch(e => { console.error(e); process.exitCode = 1; });
