"""Create exact DAVID evidence SVGs; PNG export is handled by render_figures.cjs.

Uses the unchanged supplied Rayls symbol and values checked against both an
original run and the fresh review execution. These are diagrams, not screenshots.
"""
from pathlib import Path
from html import escape
from PIL import ImageFont
import base64
import hashlib
import json

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'figures'
INK, PAPER, PURPLE, LILAC, LIME = '#121118', '#F0F1F6', '#7651EC', '#B69BFF', '#EEFF30'
MUTED, SOFT, WHITE = '#666475', '#E9E3FA', '#FFFFFF'
FONTS = Path('/usr/share/fonts/opentype/urw-base35')
SANS = FONTS / 'NimbusSans-Regular.otf'
BOLD = FONTS / 'NimbusSans-Bold.otf'
MONO = FONTS / 'NimbusMonoPS-Regular.otf'
MONOBOLD = FONTS / 'NimbusMonoPS-Bold.otf'
logo = (OUT / 'assets/rayls-symbol.png').read_bytes()
assert hashlib.sha256(logo).hexdigest() == '75e95e00b76d284facc82f1bd67f9abe344df454349d39d9a3a111293a7041b1'
brand = 'data:image/png;base64,' + base64.b64encode(logo).decode()

def case(run, key):
    return json.loads((ROOT / run / 'focused' / (key + '.json')).read_text())

keys = ['F01', 'F02', 'F04', 'F05', 'F06', 'F08', 'F09', 'F11', 'F12', 'F13', 'F15']
data = {key: case('evidence/run-01', key) for key in keys}
for key in keys:
    other = case('review-evidence/run-04', key)
    assert data[key]['before'] == other['before']
    assert data[key]['after'] == other['after']
assert data['F01']['after']['targets']['A']['total'] == '7'
assert data['F02']['after']['targets']['A']['total'] == '7'
assert data['F04']['after']['targets']['A']['total'] == '14'
assert data['F06']['after']['targets']['B']['total'] == '13'
assert data['F08']['after']['targets']['B']['total'] == '30'
assert data['F09']['after']['targets']['B']['total'] == '30'
M1 = next(iter(data['F01']['after']['executed']))
M2 = next(k for k in data['F04']['after']['executed'] if k != M1)
M5 = next(iter(data['F06']['after']['executed']))
assert M1 != M2
assert not data['F06']['after']['executed'][M5]
assert data['F08']['after']['executed'][M5]
assert data['F05']['detail']['source_nonces'] == ['3', '4']
assert data['F05']['after']['nonces']['10101'] == '0'
assert data['F12']['after']['nonces']['10101'] == '1'
assert data['F13']['after']['nonces']['10101'] == '1'
assert data['F15']['after']['nonces']['10101'] == '3'

class Figure:
    def __init__(self, width, height, name):
        self.w, self.h, self.name = width, height, name
        self.parts, self.labels = [], []
        self.parts.append('<defs><pattern id="grid" width="28" height="28" patternUnits="userSpaceOnUse"><path d="M28 0H0V28" fill="none" stroke="#DDE0EB" stroke-width="0.6"/></pattern><marker id="arrow" viewBox="0 0 12 12" refX="10" refY="6" markerWidth="7" markerHeight="7" orient="auto-start-reverse"><path d="M0 0L12 6L0 12Z" fill="#121118"/></marker></defs>')
        self.rect(0, 0, width, height, PAPER)
        self.parts.append(f'<rect width="{width}" height="{height}" fill="url(#grid)"/>')

    def rect(self, x, y, w, h, fill, stroke=None, sw=1.5):
        self.parts.append(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" fill="{fill}"' + (f' stroke="{stroke}" stroke-width="{sw}"' if stroke else '') + '/>')

    def poly(self, points, fill, stroke=None):
        self.parts.append(f'<polygon points="{points}" fill="{fill}"' + (f' stroke="{stroke}" stroke-width="1.5"' if stroke else '') + '/>')

    def panel(self, x, y, w, h, fill, cut=18, stroke=None):
        self.poly(f'{x},{y} {x+w-cut},{y} {x+w},{y+cut} {x+w},{y+h} {x},{y+h}', fill, stroke)

    def text(self, x, y, value, size=26, fill=INK, bold=False, mono=False, maxw=None):
        value = str(value)
        file = MONOBOLD if mono and bold else MONO if mono else BOLD if bold else SANS
        font = ImageFont.truetype(str(file), size)
        if maxw is not None:
            assert font.getlength(value) <= maxw, f'{self.name}: {value} exceeds {maxw}'
        box = font.getbbox(value, anchor='ls')
        bounds = [x+box[0], y+box[1], x+box[2], y+box[3]]
        assert 0 <= bounds[0] <= bounds[2] <= self.w, (value, bounds)
        assert 0 <= bounds[1] <= bounds[3] <= self.h, (value, bounds)
        family = 'Nimbus Mono PS' if mono else 'Nimbus Sans'
        self.parts.append(f'<text x="{x}" y="{y}" fill="{fill}" font-family="{family}" font-size="{size}" font-weight="{700 if bold else 400}">{escape(value)}</text>')
        self.labels.append({'text': value, 'bounds': bounds, 'font_size': size})

    def arrow(self, x1, y1, x2, y2):
        self.parts.append(f'<path d="M{x1} {y1}L{x2} {y2}" fill="none" stroke="{INK}" stroke-width="3" marker-end="url(#arrow)"/>')

    def mark(self, x, y, size):
        self.panel(x-8, y-8, size+16, size+16, INK, cut=18)
        self.parts.append(f'<image x="{x}" y="{y}" width="{size}" height="{size}" href="{brand}" preserveAspectRatio="xMidYMid meet"/>')

    def save(self):
        conflicts = []
        for i, a in enumerate(self.labels):
            for b in self.labels[i+1:]:
                A, B = a['bounds'], b['bounds']
                if min(A[2], B[2]) > max(A[0], B[0]) + 1 and min(A[3], B[3]) > max(A[1], B[1]) + 1:
                    conflicts.append([a['text'], b['text']])
        assert not conflicts, (self.name, conflicts)
        svg = f'<svg xmlns="http://www.w3.org/2000/svg" width="{self.w}" height="{self.h}" viewBox="0 0 {self.w} {self.h}">' + ''.join(self.parts) + '</svg>'
        (OUT / (self.name + '.svg')).write_text(svg)
        return {'file': self.name+'.png', 'svg': self.name+'.svg', 'logical_size': [self.w,self.h], 'png_size':[self.w*2,self.h*2], 'text_bounds': self.labels, 'text_overlap_pairs': conflicts}

specs = []
f = Figure(1600, 640, '01-retry-banner')
f.poly('1210,0 1600,0 1600,208 1418,208 1210,58', LILAC)
f.poly('0,510 190,510 320,640 0,640', LIME)
f.rect(0,0,660,5,PURPLE); f.rect(660,0,245,5,LIME)
f.text(52,49,'LOCAL CONTRACT STUDY',22,PURPLE,mono=True)
f.text(52,129,'Retry the message.',66,bold=True,maxw=745)
f.text(52,203,'Or create a new one?',66,bold=True,maxw=745)
f.text(54,251,'Testing the execution boundary in Rayls code.',25,maxw=730)
f.panel(52,292,690,201,INK,cut=24)
f.text(78,334,'SAME APPLICATION PAYLOAD',22,LILAC,mono=True,maxw=635)
f.text(78,399,'applyEffect(7)',47,LIME,bold=True,mono=True,maxw=635)
f.text(78,451,'The source submission determines the message ID.',23,WHITE,maxw=635)
f.mark(1430,28,118)
f.panel(804,208,744,130,WHITE,stroke=PURPLE)
f.rect(804,208,10,130,PURPLE)
f.text(833,241,'REDELIVER SUCCESSFUL M1',22,PURPLE,mono=True,maxw=680)
f.text(833,291,'Replay rejected',34,bold=True,maxw=335)
f.text(1190,291,'A.total: 7 → 7',25,mono=True,maxw=330)
f.panel(804,365,744,130,LIME,stroke=INK)
f.text(833,399,'SUBMIT AGAIN AT SOURCE → NEW ID M2',22,mono=True,maxw=680)
f.text(833,449,'New message executes',30,bold=True,maxw=350)
f.text(1212,449,'A.total: 7 → 14',24,mono=True,maxw=310)
f.panel(52,535,1496,53,INK,cut=24)
f.text(72,571,'A retry and a new source submission are different operations.',29,WHITE,bold=True,maxw=1430)
f.text(54,621,'One local EVM · Synthetic counters · Manual message delivery · Source ed8863885c8e',20,MUTED,maxw=1480)
specs.append(f.save())

f = Figure(1600,900,'02-measured-outcomes')
f.poly('1300,0 1600,0 1600,205 1430,205 1300,75',LILAC)
f.poly('0,758 170,758 312,900 0,900',LIME)
f.text(52,47,'RECEIPT, STATE AND APPLICATION EFFECT',21,PURPLE,mono=True,maxw=1250)
f.text(52,115,'A reverted attempt can be retried.',54,bold=True,maxw=1280)
f.text(54,163,'Selected observations from one controlled local sequence.',25,maxw=1300)
f.mark(1435,28,107)
f.rect(52,202,1496,59,INK)
headers=[(74,'CASE'),(193,'OPERATION'),(744,'ID'),(853,'RECEIPT'),(1038,'COUNTER TOTAL'),(1320,'EXECUTED')]
for x,label in headers:f.text(x,240,label,20,WHITE,bold=True,mono=True)
rows=[
 ['F01','First delivery','M1','1','A: 7','true'],
 ['F02','Replay after success','M1','0','A: 7','true'],
 ['F04','New source submission','M2','1','A: 14','true'],
 ['F06','Controlled target failure','M5','0','B: 13','false'],
 ['F08','Retry after target recovery','M5','1','B: 30','true'],
 ['F09','Replay recovered message','M5','0','B: 30','true']
]
for i,row in enumerate(rows):
    y=261+i*68
    f.rect(52,y,1496,68,WHITE if i%2==0 else SOFT,stroke='#CEC5E6',sw=1)
    for j,(x,value) in enumerate(zip([74,193,744,883,1060,1340],row)):
        f.text(x,y+43,value,25 if j==1 else 27,PURPLE if j in [0,3] else INK,bold=j!=1,mono=j!=1,maxw=[100,505,80,100,220,165][j])
f.text(54,710,'A and B are separate synthetic counters. B already held 13 units before F06.',23,maxw=1470)
f.panel(52,747,1496,71,INK,cut=24)
f.text(75,792,'F06 → F08',25,LILAC,bold=True,mono=True)
f.text(330,792,'B.total: 13 → 30',31,LIME,bold=True,mono=True,maxw=540)
f.text(925,790,'executed: false → true',26,WHITE,mono=True,maxw=580)
f.text(54,852,'Receipt 0 = deliberately reverted local call. Counter units are not assets or money.',22,MUTED,maxw=1470)
f.text(54,886,'M1, M2 and M5 label full recorded IDs. Evidence and aliases: figure-data.json.',19,MUTED,mono=True,maxw=1470)
specs.append(f.save())

f = Figure(1600,900,'03-ordering-policy')
f.poly('1270,0 1600,0 1600,205 1410,205 1270,66',LILAC)
f.poly('0,730 150,730 320,900 0,900',LIME)
f.text(52,47,'DUPLICATE PROTECTION AND ORDERING',21,PURPLE,mono=True,maxw=1250)
f.text(52,116,'A nonce field alone does not enforce order.',50,bold=True,maxw=1310)
f.text(54,164,'Source-emitted messages and strict-mode controls were tested separately.',25,maxw=1340)
f.mark(1435,28,107)
f.panel(52,209,722,486,WHITE,stroke=PURPLE)
f.panel(826,209,722,486,WHITE,stroke=PURPLE)
f.rect(52,209,702,56,PURPLE)
f.text(75,246,'ACTUAL SENDER OUTPUT',24,WHITE,bold=True,mono=True,maxw=650)
f.rect(826,209,702,56,LIME)
f.text(851,246,'CONTROL INPUTS',24,bold=True,mono=True,maxw=650)
f.text(76,317,'ignoresNonce = true',30,PURPLE,bold=True,mono=True,maxw=650)
f.text(850,317,'ignoresNonce = false',30,PURPLE,bold=True,mono=True,maxw=650)
f.text(77,366,'Delivered in this order:',26,maxw=650)
f.panel(78,392,178,117,INK,cut=16)
f.text(130,474,'4',74,LIME,bold=True,mono=True)
f.arrow(286,451,420,451)
f.panel(448,392,178,117,INK,cut=16)
f.text(502,474,'3',74,LIME,bold=True,mono=True)
f.text(78,558,'Both messages executed',33,bold=True,maxw=655)
f.text(78,608,'inboundNonce[10101]: 0 → 0',25,PURPLE,mono=True,maxw=655)
f.text(78,658,'Both message IDs became consumed.',25,maxw=655)
steps=[('1 succeeds','counter becomes 1'),('2 fails','counter stays 1'),('3 rejected','expected nonce 2'),('Recover; retry 2, then 3','counter becomes 3')]
for i,(title,detail) in enumerate(steps):
    y=366+i*74
    f.text(851,y,title,26,bold=True,maxw=650)
    f.text(851,y+31,detail,23,PURPLE,mono=True,maxw=650)
f.text(54,741,'False-flag inputs were assembled by the study; they were not emitted by the pinned senders.',24,maxw=1480)
f.panel(52,776,1496,67,INK,cut=25)
f.text(75,821,'Duplicate rejection and ordered execution are separate mechanisms.',30,WHITE,bold=True,maxw=1435)
f.text(54,883,'One local EVM · Manual delivery · Evidence: F05 and F11–F16 · Source ed8863885c8e',20,MUTED,maxw=1480)
specs.append(f.save())

report = {
 'source_run':'evidence/run-01', 'crosschecked_run':'review-evidence/run-04',
 'source_commit':'ed8863885c8ed5d5d317d47a34c063907192687a',
 'logo_file':'assets/rayls-symbol.png', 'logo_sha256':hashlib.sha256(logo).hexdigest(),
 'message_aliases':{'M1':M1,'M2':M2,'M5':M5},
 'measured_rows':rows,'source_delivery_order':[4,3],
 'scope':'Exact local-experiment evidence diagrams. One EVM, synthetic counters and manually delivered messages; not transport, production or financial-asset evidence.',
 'figures':specs
}
(OUT/'figure-data.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print('PASS three DAVID SVGs; exact data assertions, text bounds and no text overlaps.')
