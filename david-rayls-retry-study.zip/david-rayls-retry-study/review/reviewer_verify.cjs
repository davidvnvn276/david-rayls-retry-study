'use strict';
// Additional record binding checks. No provider, EVM execution or network access.
// Usage: node review/reviewer_verify.cjs evidence/run-01
const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');
const { ethers } = require('ethers');
const { ROOT, FILES, write, sha256 } = require('../scripts/common.cjs');
const args = process.argv.slice(2);
assert.equal(args.length, 1, 'Specify one supplied or reproduced run directory');
const dir = path.resolve(ROOT, args[0]);
const read = name => JSON.parse(fs.readFileSync(path.join(dir, name), 'utf8'));
const contracts = read('compiled-contracts.json');
const input = read('solc-input.json');
let sourceBindings = 0;
for (const [name, source] of Object.entries(input.sources)) {
  const candidates = [path.resolve(ROOT, name), path.resolve(ROOT, 'node_modules', name)];
  const local = candidates.find(p => p.startsWith(ROOT + path.sep) && fs.existsSync(p));
  assert.ok(local, 'Missing actual source: ' + name);
  assert.equal(fs.readFileSync(local, 'utf8'), source.content, 'Saved compiler source differs from current source: ' + name);
  sourceBindings++;
}
const abi = (file, name) => new ethers.Interface(contracts[file][name].abi);
const interfaces = {
  target: abi(FILES.fixtures, 'RecordingTarget'),
  receiver: abi(FILES.receiver, 'MessageReceiver'),
  executor: abi(FILES.executor, 'RaylsMessageExecutorV1'),
  sender: abi(FILES.sender, 'MessageSender'),
  batch: abi(FILES.batchSender, 'BatchMessageSender'),
  endpoint: abi(FILES.endpoint, 'EndpointV1')
};
const observed = new Map();
const records = new Map();
const journals = {};
let receiptBindings = 0;
let revertBindings = 0;
for (const phase of ['experiment', 'restart']) {
  const rows = fs.readFileSync(path.join(dir, 'rpc-' + phase + '.jsonl'), 'utf8')
    .trim().split('\n').map(line => JSON.parse(line));
  journals[phase] = rows;
  let height = null;
  for (const row of rows) {
    if (row.method === 'eth_getTransactionReceipt' && row.result) height = BigInt(row.result.blockNumber).toString();
    if (row.method === 'eth_getBlockByNumber' && row.params[0] === 'latest' && row.result) height = BigInt(row.result.number).toString();
    if (row.method === 'eth_call' && !row.error && row.params[1] === 'latest') {
      assert.ok(height !== null, 'Getter read without a known local block');
      const call = row.params[0];
      const key = [height, call.to.toLowerCase(), call.data.toLowerCase()].join(':');
      if (observed.has(key)) assert.equal(observed.get(key), row.result, 'Conflicting same-block getter replies');
      observed.set(key, row.result);
    }
  }
  for (const entry of read('transaction-index-' + phase + '.json')) {
    const record = read(entry.file);
    const hash = record.receipt.transactionHash;
    assert.equal(hash, entry.hash);
    assert.ok(!records.has(hash), 'Duplicate transaction across phases');
    records.set(hash, record);
    const sent = rows.find(x => x.method === 'eth_sendTransaction' && x.result === hash);
    const receipt = rows.find(x => x.method === 'eth_getTransactionReceipt' && x.params[0] === hash);
    const mined = rows.find(x => x.method === 'eth_getTransactionByHash' && x.params[0] === hash);
    assert.ok(sent && receipt && mined, 'Missing raw RPC binding for ' + entry.label);
    assert.deepEqual(sent.params, [record.input], 'Submitted input differs from raw journal');
    assert.deepEqual(receipt.result, record.receipt, 'Receipt differs from raw journal');
    assert.deepEqual(mined.result, record.mined, 'Mined transaction differs from raw journal');
    receiptBindings++;
    if (record.receipt.status === '0x0') {
      const parent = ethers.toQuantity(BigInt(record.receipt.blockNumber) - 1n);
      const match = rows.find(x => x.method === 'eth_call' && x.params[1] === parent && x.error
        && JSON.stringify(x.params[0]) === JSON.stringify(record.input)
        && (typeof x.error.data === 'string' ? x.error.data : x.error.data?.result) === record.revert.raw);
      assert.ok(match, 'No exact caller/value/gas/input/parent-state revert binding: ' + entry.label);
      revertBindings++;
    }
  }
}
let stateSnapshots = 0;
let getterBindings = 0;
function getter(height, address, kind, fn, values = []) {
  const iface = interfaces[kind];
  const data = iface.encodeFunctionData(fn, values).toLowerCase();
  const key = [BigInt(height).toString(), address.toLowerCase(), data].join(':');
  assert.ok(observed.has(key), 'No same-block raw getter for ' + fn + ' at ' + height);
  getterBindings++;
  return iface.decodeFunctionResult(fn, observed.get(key))[0];
}
function state(f, state, height) {
  for (const key of ['A', 'B']) {
    const address = f[key.toLowerCase()].address;
    for (const fn of ['total', 'calls']) assert.equal(getter(height, address, 'target', fn).toString(), state.targets[key][fn]);
    assert.equal(getter(height, address, 'target', 'fails'), state.targets[key].fails);
  }
  for (const [source, value] of Object.entries(state.nonces))
    assert.equal(getter(height, f.receiver.address, 'receiver', 'getInboundNonce', [source]).toString(), value);
  for (const [id, value] of Object.entries(state.executed))
    assert.equal(getter(height, f.executor.address, 'executor', 'executed', [id]), value);
  assert.equal(getter(height, f.sender.address, 'sender', 'getOutboundNonce', [20202]).toString(), state.outbound.single);
  assert.equal(getter(height, f.batchSender.address, 'batch', 'outboundNonce', [20202]).toString(), state.outbound.dispatch_batch);
  stateSnapshots++;
}
const summary = read('run-summary.json');
const focusedFixture = summary.experiment.focused_fixture;
for (const entry of read('focused-index.json')) {
  const c = read(entry.file);
  const transactions = c.transactions.map(t => read(t.file));
  assert.ok(transactions.length > 0);
  state(focusedFixture, c.before, BigInt(transactions[0].receipt.blockNumber) - 1n);
  state(focusedFixture, c.after, transactions.at(-1).receipt.blockNumber);
}
for (const item of summary.experiment.seeded) {
  const folder = 'seeded/seed-' + item.seed;
  const s = read(folder + '/summary.json');
  for (let i = 1; i <= 60; i++) {
    const step = read(folder + '/S' + item.seed + '-' + String(i).padStart(3, '0') + '.json');
    const tx = read(step.transactions.at(-1).file);
    state(s.fixture, step.state, tx.receipt.blockNumber);
  }
}
for (const name of ['before-process-restart.json', 'after-process-restart.json']) {
  const capture = read(name);
  state(focusedFixture, capture.state, capture.block_number);
}
const effectTopic = ethers.id('EffectApplied(bytes32,uint256,address,uint256,uint256,uint256,address)');
const executedTopic = ethers.id('MessageIdExecuted(uint256,bytes32)');
let effectExecutionBindings = 0;
for (const record of records.values()) {
  const emitted = new Set(record.receipt.logs.filter(x => x.topics[0] === executedTopic)
    .map(x => x.address.toLowerCase() + ':' + x.topics[2]));
  for (const log of record.receipt.logs.filter(x => x.topics[0] === effectTopic)) {
    const parsed = interfaces.target.parseLog(log);
    assert.ok(emitted.has(parsed.args.immediateCaller.toLowerCase() + ':' + parsed.args.messageId),
      'Application effect without matching same-transaction executor ID');
    let call;
    try { call = interfaces.endpoint.parseTransaction({ data: record.input.data }); } catch {}
    if (call?.name === 'receivePayload') {
      assert.equal(parsed.args.messageId, call.args[4]);
      assert.equal(parsed.args.sourceChainId, call.args[0]);
      assert.equal(parsed.args.sourceSender.toLowerCase(), call.args[1].toLowerCase());
    } else {
      const direct = interfaces.executor.parseTransaction({ data: record.input.data });
      assert.ok(['executeMessage', 'executeMessageBatch'].includes(direct?.name));
      const offset = direct.name === 'executeMessage' ? 2 : 1;
      assert.equal(parsed.args.messageId, direct.args[offset]);
      assert.equal(parsed.args.sourceChainId, direct.args[offset + 1]);
      assert.equal(parsed.args.sourceSender.toLowerCase(), direct.args[offset + 2].toLowerCase());
    }
    effectExecutionBindings++;
  }
}
const report = {
  status: 'passed', run: args[0], source_files_bound_to_actual_bytes: sourceBindings,
  transactions_bound_to_rpc_requests_receipts_and_mined_inputs: receiptBindings,
  exact_parent_call_revert_bindings: revertBindings,
  focused_and_seeded_state_snapshots_bound_to_same_block_raw_getters: stateSnapshots,
  individual_getter_bindings: getterBindings,
  application_effects_bound_to_same_transaction_executor_ids_and_call_context: effectExecutionBindings,
  verifier_sha256: sha256(fs.readFileSync(__filename)),
  scope: 'Additional saved-record consistency checks; not new EVM experiments or independent authentication of production consensus or transport.'
};
const name = path.basename(dir).replace(/[^a-zA-Z0-9-]/g, '-');
write(path.join(ROOT, 'review', 'reviewer-audit-' + name + '.json'), report);
console.log('PASS reviewer RPC bindings, actual compiler sources, before/after state reads and per-transaction execution context.');
console.log(JSON.stringify(report));
