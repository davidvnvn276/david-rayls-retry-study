# Review of DAVID's Rayls message retry study

## Outcome

The supplied records support the main implementation findings. A new complete local execution reproduced the 33 focused cases, three 60-operation sequences, separate-process database reopening and three opcode traces. The independent saved-record checks found no numerical discrepancy in the selected counter results, message IDs, nonce outcomes or transaction/event counts. This is a bounded review, not a claim of perfect protocol correctness or a promise of a quest score.

The revised publication studies expected message-execution semantics in pinned public code. It does not report a customer incident, transfer real assets, authenticate a current deployment or test a live transport path.

## Source and build identity

- Input ZIP SHA-256: `4726ad37df0d39c27cae05026194dbec9c55d42b9fa10efeb61c9d59d81e65f6`.
- The original 2,925-entry SHA-256 manifest passed before changes.
- A new GitHub tree retrieval at `ed8863885c8ed5d5d317d47a34c063907192687a` bound all 383 vendored files to their published Git blob identities. Six critical files were additionally fetched and matched byte-for-byte, including upstream package metadata `2.6.3-nightly.2`.
- The separately pinned relayer transaction-generator file also matched freshly retrieved bytes. Only that source was inspected; the relayer was not executed.
- Fresh compilation using solc-js 0.8.24 reproduced 66 contract artifacts. The preserved expanded compilation closure contains 66 source files, including fixtures and OpenZeppelin dependencies.
- Every creation input, linked-library address and fixed runtime region matched all 67 recorded deployments per run. Compiler-declared immutable runtime ranges are handled separately; constructor bytes are checked in full.

These are source/build consistency checks using the same compiler implementation. They do not map this source to production runtime or independently audit the compiler.

## Execution and raw-record checks

Three original recorded runs were checked. A fourth complete study was actually run after a new `npm ci --ignore-scripts --no-audit --no-fund` installation and on a fresh, unforked Ganache database. All four matched on comparable focused states, deterministic action sequences, final states and derived results.

Each complete run contains:

| Observation | Count |
|---|---:|
| Focused cases | 33 |
| Seeded sequences | 3 |
| Operations per sequence | 60 |
| Local transactions, including setup and planned reverts | 579 |
| Successful transactions | 476 |
| Intentionally reverted transactions | 103 |
| Raw application-effect events | 114 |
| Source-emitted messages | 107 |
| Unique committed IDs across that run's fixture executors | 113 |
| Local deployments | 67 |

A new reviewer program additionally bound all 579 saved transactions to raw RPC submission/receipt/mined-input records; all 103 failed calls to exact caller, gas, value, input and parent-block simulations; 248 focused, seeded and restart snapshots using 5,636 comparisons against same-block getter replies; and all 114 application effects to their same-transaction executor IDs and source context. It also matched the compiler's 66 preserved source texts to actual local files. These are consistency checks, not 5,636 distinct raw replies or independent experiments.

The existing verifier's negative controls were rerun: removing a predecoded event summary still passed, while mutations to raw effects, storage words, case totals and revert selectors were rejected. The added reviewer also rejected copied raw journals with a changed getter result or a changed parent-call sender. These were copies intentionally altered to test the checkers, not chain observations.

## Findings and their exact boundaries

1. **Replay after success:** F01 recorded A.total 7 and a consumed M1; F02 rejected that same ID and left A.total at 7.
2. **New source submission:** F04 carried the same application payload but a different source nonce and ID M2, raising A.total from 7 to 14. The synthetic application deliberately lacks business-request deduplication. This is not evidence of duplicate customer payments.
3. **Failure and recovery:** F06 left B.total at 13 and M5 unconsumed after a controlled target revert. Removing the fixture's failure allowed F08 to apply the same 17-unit message, bringing B.total to 30. The subsequent replay was rejected. Opcode traces distinguish a tentative marker write from committed storage.
4. **Ordering:** the pinned senders emit `ignoresNonce=true`; unchanged source-emitted nonce 4 and then 3 executed, with inboundNonce[10101] remaining zero. Strict false-flag tests were assembled by the study; they demonstrate the receiver's other branch, not a default live transport policy.
5. **Batch scope:** a direct executor batch rolled earlier effects back when its middle call reverted. That is local EVM atomicity, not atomic settlement across separate chains or source dispatch batches.
6. **Persistence:** the consumed-ID result persisted through the tested storage-compatible study upgrade and local database reopening. Neither establishes arbitrary upgrade safety, relayer restart behavior or distributed failover.

The core results did not require an economic or numerical correction. Publication wording was refined to locate the committed-ID boundary at the same executor and to distinguish an existing-message retry from another source submission.

## Publication and graphics changes

- The lead now states measured outcomes directly and links Rayls' documented manual-retry context, while retaining the narrower experimental scope.
- The manuscript, README, claim ledger, result table and GitHub landing README consistently describe three original runs plus the fourth actual review execution.
- The requested output is a written article with file-based evidence. The separate recording guide and its publishing instructions were removed.
- Three quantitative SVG/PNG figures were redesigned in the established DAVID style. The banner is exactly 5:2 at 3200 × 1280; internal figures are 16:9 at 3200 × 1800. Message aliases, case references and all displayed numerical/state values are saved in `figures/figure-data.json`.
- The full-colour supplied Rayls symbol is embedded unchanged, including its original black background. No wordmark, token icon, account watermark or snapshot date is added. The earlier homepage SVG remains an unused reference asset.
- Text bounds, overlaps, PNG integrity and image dimensions were checked. These are authored evidence diagrams, not fabricated explorer screenshots.

Original execution data, pinned source bytes, test fixtures and EVM harness files remain unchanged, as recorded in `input-preservation.json`. The new review execution and additional reviewer files are separate.

## How to reproduce the review

From the extracted package root, use the detailed README. A compact command sequence is:

```bash
node scripts/check_integrity.cjs
npm ci --ignore-scripts --no-audit --no-fund
node scripts/verify.cjs evidence/run-01
node scripts/verify.cjs review-evidence/run-04
node scripts/recompile.cjs evidence/run-01
node scripts/verify_deployments.cjs review-evidence/run-04
node review/reviewer_verify.cjs evidence/run-01
node review/reviewer_verify.cjs review-evidence/run-04
node scripts/run.cjs --output runs/my-review-01
node scripts/verify.cjs runs/my-review-01
node review/reviewer_verify.cjs runs/my-review-01
```

Run the integrity check before commands that deliberately refresh generated reports. Choose a fresh output directory. The local binary database is regenerated by the complete run and omitted from the distribution. Optional artwork authoring dependencies are separate from the EVM toolchain.

## What remains outside the evidence

- No two-chain environment, live relayer, Private Network Hub, consensus/receipt proof verification or encrypted transport was run.
- Membership/token checks were replaced with a permissive fixture. Counter units are not tokens, deposits or money.
- The source is a pinned public nightly snapshot, not an authenticated production deployment.
- The deterministic sequences are repeatability and boundary checks, not exhaustive testing or measurements of production failure rates.
- Native Windows execution was not tested; the supplied commands are instructions, not a Windows validation claim.
- A real new public evidence repository URL must be added before submission. No repository or social post was published by this review.

The effort is demonstrated by executable source, causal controls, source-ID reconstruction, opcode/storage reconciliation, fresh execution and inspectable raw records. The evaluation of those contributions remains with the moderator.
